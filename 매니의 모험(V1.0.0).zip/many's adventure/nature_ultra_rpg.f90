program nature_ultra_rpg
    use game_types
    use game_utils
    use game_graphics
    use game_logic
    implicit none

    type(character_t) :: pc
    integer :: choice, ios
    logical :: loaded

    call random_seed()

    ! ── 1. 인트로 애니메이션 ──
    call draw_intro_animation()

    ! ── 2. 시작 화면 ──
    do
        call clear_screen()
        call draw_adventure_of_many_banner()
        call show_start_menu_box()
        write(*, '("  >> ")', advance='no')
        read(*, *, iostat=ios) choice
        if (ios /= 0) cycle

        if (choice == 1) then
            call create_character(pc)
            call show_opening_story(pc)
            call scene_pet_selection(pc)
            exit
        else if (choice == 2) then
            call load_game(pc, loaded)
            if (loaded) then
                write(*,'(A)')"  [불러오기 완료] 저장 데이터를 불러왔습니다."
                call wait_for_enter()
                exit
            else
                write(*,'(A)')"  [!] 저장 데이터가 없습니다."
                call wait_for_enter()
            end if
        else if (choice == 3) then
            stop
        end if
    end do

    ! ── 3. 메인 루프 ──
    do
        call clear_screen()

        ! 캐릭터 상태창
        call show_main_status_ui(pc)
        print *, ""

        ! 월드 맵
        call draw_modern_world_map(pc)
        print *, ""

        ! 메뉴
        call show_main_command_box()
        write(*, '("  >> ")', advance='no')
        read(*, *, iostat=ios) choice
        if (ios /= 0) cycle

        select case(choice)
        case(1)
            call scene_explore_choice(pc)
        case(2)
            call scene_shop(pc)
        case(3)
            call show_inventory_box(pc)
        case(4)
            call save_game(pc)
            call wait_for_enter()
        case(5)
            call show_dialogue_box("종료", "게임을 종료합니다. 안녕히 가세요!", "")
            call wait_for_enter()
            exit
        case(6)
            call scene_skill_menu(pc)
        end select
    end do

end program nature_ultra_rpg
