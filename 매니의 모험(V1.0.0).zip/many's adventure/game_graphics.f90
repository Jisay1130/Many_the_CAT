module game_graphics
    use game_types
    use game_utils
    implicit none
    contains
    subroutine draw_ruined_castle_hd()
        write(*,'(A)')"                                     |>>>"
        write(*,'(A)')"                                     |"
        write(*,'(A)')"                    _  _  _  _  _  _|_  _  _  _  _  _"
        write(*,'(A)')"                   | |_| |_| |_| |_| |_| |_| |_| |_| |"
        write(*,'(A)')"                   |                                 |"
        write(*,'(A)')"                   |    [ RUINED ANCIENT CASTLE ]    |"
        write(*,'(A)')"                   |_________________________________|"
        write(*,'(A)')"                   |  _   _   _               _   _  |"
        write(*,'(A)')"                   | | |_| | | |             | | |_| |"
        write(*,'(A)')"                   | |_   _| |_|             |_|  _| |"
        write(*,'(A)')"                   |___| |_________________________| |"
    end subroutine draw_ruined_castle_hd

    subroutine draw_character_portrait(job)
        integer, intent(in) :: job; write(*,'(A)') ""
        select case (job)
        case (JOB_MANY);   write(*,'(A)')" (o o) [모험가 매니]"; case (JOB_HOPPANG); write(*,'(A)')" (- -) [방어자 호빵]"
        case (JOB_MILK);   write(*,'(A)')" (@ @) [마법사 우유]"; case (JOB_JJABDAM); write(*,'(A)')" (> <) [그림자 짭담이]"
        case (JOB_JISAY);  write(*,'(A)')" (O O) [지배자 JISAY]"
        end select
    end subroutine draw_character_portrait

    subroutine draw_world_map_hd(pc)
        type(character_t), intent(in) :: pc
        write(*,'(A)')"              [[ NATURE WORLD EXPEDITION MAP ]]"
        write(*,'(A)')"      (Forest)        (Ocean)         (Ruins) "
        write(*,'(A)')"      [ 🌲 01 ] <---> [ 🌊 05 ] <---> [ 🏛️ 09 ] "
        write(*,'(A)')"         ^               ^               ^ "
        write(*,'(A)')"         |               |               | "
        write(*,'(A)')"      [ 🏠 13 ] <---> [ ⚔️ 17 ] <---> [ 🌑 21 ] "
        write(*,'(A)')"       (Town)          (Trial)         (Abyss) "
    end subroutine draw_world_map_hd
    
    subroutine draw_battle_frame(pc, e_name, m_hp, f, a)
        type(character_t), intent(in) :: pc; character(len=*), intent(in) :: e_name; integer, intent(in) :: m_hp, f, a
        call clear_screen()
        write(*,*) "┏━━━━━━━━━━━━━━━━━━━━━ COMBAT ━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '(" ┃ HP: ", I4, "/", I4, " | ATK: ", I3, T51, "┃")') pc%hp, pc%max_hp, pc%base_atk+pc%weapon%atk
        write(*,*) "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
        write(*, '(" ", T30, "[[ ", A15, " HP: ", I4, " ]]")') e_name, m_hp
        if(a==2) write(*,*) " [!] 몬스터의 반격! 💥CRASH!!"
        if(a==1) write(*,*) " [!] 영웅의 공격! 💥BOOM!!"
    end subroutine draw_battle_frame
end module game_graphics
