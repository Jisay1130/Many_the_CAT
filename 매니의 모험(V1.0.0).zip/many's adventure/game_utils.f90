module game_utils
    implicit none
    contains
    subroutine clear_screen()
        write(*, '(A)', advance='no') char(27)//'[H'//char(27)//'[2J'//char(27)//'[3J'
        call flush(6)
    end subroutine clear_screen

    subroutine delay(sec)
        real, intent(in) :: sec; character(len=20) :: cmd; write(cmd, '("sleep ", F4.2)') sec; call execute_command_line(cmd)
    end subroutine delay

    subroutine safe_read(choice)
        integer, intent(out) :: choice; integer :: ios
        do; write(*, '(" 입력: ")', advance='no')
            read(*, *, iostat=ios) choice
            if (ios == 0) exit
            write(*, '(A)') " [!] 올바른 숫자를 입력하세요."
        end do
    end subroutine safe_read

    subroutine wait_for_enter()
        character(len=1) :: temp; print *, " [ Enter를 눌러 계속... ]"; read(*, '(A)') temp
    end subroutine wait_for_enter
end module game_utils
