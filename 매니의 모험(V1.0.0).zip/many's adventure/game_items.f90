module game_items
    use game_types
    implicit none
    contains
    subroutine get_gacha_item(grade, lv, n, t, v, p)
        integer, intent(in) :: grade, lv; character(len=30), intent(out) :: n; integer, intent(out) :: t, v, p
        real :: r; integer :: vi; call random_number(r); vi = int(r*4)+1
        if(r>0.5)then; t=TYPE_WEAPON; else; t=TYPE_ARMOR; endif
        select case(grade)
        case(1); n="낡은 장비"; v=5+lv; p=10
        case(2); n="쓸만한 장비"; v=15+lv*2; p=30
        case(3); n="희귀한 장비"; v=40+lv*4; p=100
        case(4); n="전설의 장비"; v=100+lv*8; p=500
        case(5); n="신화의 장비"; v=300+lv*15; p=2000
        end select
    end subroutine get_gacha_item

    subroutine draw_item_art(n)
        character(len=*), intent(in) :: n
        write(*,*) "      _________________ "
        write(*,*) "     /                 \ "
        write(*,*) "     |      [ITEM]     | "
        write(*,*) "     \_________________/ "
    end subroutine draw_item_art
end module game_items
