module game_types
    implicit none
    integer, parameter :: INV_SIZE = 15
    integer, parameter :: MAX_REGION = 24
    integer, parameter :: JOB_MANY=1, JOB_HOPPANG=2, JOB_MILK=3, JOB_JJABDAM=4, JOB_JISAY=5
    integer, parameter :: TYPE_WEAPON=1, TYPE_ARMOR=2, TYPE_ITEM=3
    integer, parameter :: GRADE_COMMON=1, GRADE_RARE=2, GRADE_EPIC=3, GRADE_LEGENDARY=4, GRADE_MYTHIC=5
    integer, parameter :: ELEM_EARTH=1,ELEM_WATER=2,ELEM_FIRE=3,ELEM_AIR=4,ELEM_ETHER=5
    integer, parameter :: STATUS_NORMAL=0, STATUS_BURN=1, STATUS_POISON=2
    integer, parameter :: STATUS_PARA=3, STATUS_SLEEP=4, STATUS_CONF=5

    type :: weapon_t
        character(len=30) :: name; integer :: atk, grade, price
    end type weapon_t

    type :: armor_t
        character(len=30) :: name; integer :: hp_bonus, def, grade, price
    end type armor_t

    type :: item_t
        character(len=30) :: name; integer :: itype, value, grade, price, count
    end type item_t

    type :: pet_t
        character(len=20) :: name
        integer :: element, level, hp, max_hp, atk, xp, next_xp
        logical :: active
    end type pet_t

    type :: skill_t
        character(len=30) :: name
        integer :: slevel, mp_cost, req_level, element
        real :: dmg_mult
        logical :: unlocked, equipped
    end type skill_t

    type :: character_t
        character(len=20) :: name
        integer :: job, level, xp, next_xp, hp, max_hp, gold, base_atk, evasion, hp_potions
        integer :: element, mp, max_mp, skill_points, mp_potions
        integer :: base_def, speed
        integer :: status, status_turns
        type(weapon_t) :: weapon
        type(armor_t) :: armor
        type(item_t) :: inventory(INV_SIZE)
        integer :: inv_count, current_region, current_stage, unlocked_region, inn_usage
        type(pet_t) :: pet
        type(skill_t) :: skills(6)
        integer :: ng_plus
        integer :: mon_seen(24)
    end type character_t
end module game_types

!=============================================================================
module game_utils
    use game_types
    implicit none
    contains
    subroutine clear_screen()
        write(*, '(A)', advance='no') char(27)//'[H'//char(27)//'[2J'//char(27)//'[3J'
        call flush(6)
    end subroutine clear_screen

    subroutine delay(sec)
        real, intent(in) :: sec; character(len=20) :: cmd
        write(cmd, '("sleep ", F4.2)') sec; call execute_command_line(cmd)
    end subroutine delay

    subroutine wait_for_enter()
        character(len=1) :: temp
        write(*, '(A)', advance='no') "  [ Enter 를 눌러 계속... ]"
        read(*, '(A)') temp
    end subroutine wait_for_enter

    subroutine safe_read(choice)
        integer, intent(out) :: choice; integer :: ios
        do
            write(*, '(" >> ")', advance='no')
            read(*, *, iostat=ios) choice
            if (ios == 0) exit
            write(*, '(A)') "  [!] 올바른 숫자를 입력하세요."
        end do
    end subroutine safe_read

    function grade_name(g) result(n)
        integer, intent(in) :: g; character(len=12) :: n
        select case(g)
        case(1); n = "일반"
        case(2); n = "희귀"
        case(3); n = "에픽"
        case(4); n = "전설"
        case(5); n = "신화"
        case default; n = "???"
        end select
    end function grade_name

    function elem_name(e) result(n)
        integer, intent(in) :: e; character(len=6) :: n
        select case(e)
        case(1); n="흙  "
        case(2); n="물  "
        case(3); n="불  "
        case(4); n="공기"
        case(5); n="에테르"
        case default; n="없음"
        end select
    end function elem_name

    function elem_modifier(atk_e, def_e) result(m)
        integer, intent(in) :: atk_e, def_e; real :: m
        m = 1.0
        if (atk_e == def_e) then; m = 0.8; return; end if
        if (atk_e==ELEM_WATER .and. def_e==ELEM_FIRE)  m = 2.0
        if (atk_e==ELEM_FIRE  .and. def_e==ELEM_WATER) m = 0.5
        if (atk_e==ELEM_EARTH .and. def_e==ELEM_AIR)   m = 2.0
        if (atk_e==ELEM_AIR   .and. def_e==ELEM_EARTH) m = 0.5
        if (atk_e==ELEM_FIRE  .and. def_e==ELEM_AIR)   m = 1.5
        if (atk_e==ELEM_AIR   .and. def_e==ELEM_FIRE)  m = 0.8
        if (atk_e==ELEM_ETHER .and. def_e/=ELEM_ETHER) m = 1.2
        if (atk_e/=ELEM_ETHER .and. def_e==ELEM_ETHER) m = 0.9
    end function elem_modifier

    function status_name(s) result(n)
        integer, intent(in) :: s; character(len=8) :: n
        select case(s)
        case(0); n="정상    "
        case(1); n="화상    "
        case(2); n="독      "
        case(3); n="마비    "
        case(4); n="수면    "
        case(5); n="혼란    "
        case default; n="??      "
        end select
    end function status_name

end module game_utils
!=============================================================================
module game_items
    use game_types
    implicit none
    contains

    subroutine get_weapon_by_idx(idx, name, atk, grade, price)
        integer, intent(in)  :: idx
        character(len=30), intent(out) :: name
        integer, intent(out) :: atk, grade, price
        select case(idx)
        case(1);  name="낡은 단검";         atk=5;   grade=1; price=15
        case(2);  name="철 단검";           atk=9;   grade=1; price=25
        case(3);  name="강철 검";           atk=17;  grade=2; price=80
        case(4);  name="롱소드";            atk=24;  grade=2; price=120
        case(5);  name="마법의 지팡이";     atk=39;  grade=3; price=300
        case(6);  name="저주받은 검";       atk=48;  grade=3; price=450
        case(7);  name="드래곤 슬레이어";   atk=78;  grade=4; price=1200
        case(8);  name="천상의 검";         atk=96;  grade=4; price=1800
        case(9);  name="신화의 대검";       atk=150; grade=5; price=4000
        case(10); name="창세의 검";         atk=210; grade=5; price=8000
        case(21); name="독침 단검";         atk=11;  grade=2; price=45
        case(22); name="뇌전의 검";         atk=30;  grade=2; price=110
        case(23); name="흑마술 지팡이";     atk=52;  grade=3; price=280
        case(24); name="태양의 검";         atk=72;  grade=3; price=420
        case(25); name="달빛 활";           atk=100; grade=4; price=1100
        case(26); name="폭풍의 삼지창";     atk=118; grade=4; price=1600
        case(27); name="지옥불 검";         atk=144; grade=4; price=1900
        case(28); name="빙하 대검";         atk=180; grade=5; price=3800
        case(29); name="천공의 창";         atk=220; grade=5; price=5500
        case(30); name="카오스 블레이드";   atk=270; grade=5; price=7000
        case(11); name="폭풍 지팡이";       atk=45;  grade=3; price=380
        case(12); name="얼음 창";           atk=54;  grade=3; price=500
        case(13); name="불꽃 도끼";         atk=66;  grade=3; price=620
        case(14); name="번개 채찍";         atk=84;  grade=4; price=1400
        case(15); name="용암 쌍검";         atk=96;  grade=4; price=1750
        case(16); name="폭풍왕 지팡이";     atk=114; grade=4; price=2300
        case(17); name="정령의 활";         atk=138; grade=5; price=4600
        case(18); name="신성한 해머";       atk=174; grade=5; price=6200
        case(19); name="심연의 낫";         atk=198; grade=5; price=7800
        case(20); name="창세 지팡이";       atk=246; grade=5; price=10500
        case default; name="낡은 단검";     atk=5;   grade=1; price=15
        end select
    end subroutine get_weapon_by_idx

    subroutine get_armor_by_idx(idx, name, hp_bonus, def, grade, price)
        integer, intent(in)  :: idx
        character(len=30), intent(out) :: name
        integer, intent(out) :: hp_bonus, def, grade, price
        select case(idx)
        case(1);  name="낡은 천 옷";        hp_bonus=8;   def=2;   grade=1; price=12
        case(2);  name="가죽 갑옷";         hp_bonus=15;  def=4;   grade=1; price=22
        case(3);  name="쇠사슬 갑옷";       hp_bonus=35;  def=9;   grade=2; price=90
        case(4);  name="판금 갑옷";         hp_bonus=50;  def=13;  grade=2; price=130
        case(5);  name="마법사의 로브";      hp_bonus=75;  def=18;  grade=3; price=320
        case(6);  name="강철 흉갑";         hp_bonus=100; def=24;  grade=3; price=480
        case(7);  name="미스릴 갑옷";       hp_bonus=155; def=35;  grade=4; price=1300
        case(8);  name="드래곤 비늘 갑옷";  hp_bonus=200; def=48;  grade=4; price=2000
        case(9);  name="신성한 갑옷";       hp_bonus=310; def=70;  grade=5; price=4500
        case(10); name="창세의 갑옷";       hp_bonus=460; def=105; grade=5; price=9000
        case(21); name="독가죽 갑옷";      hp_bonus=22;  def=6;   grade=2; price=50
        case(22); name="전류 갑주";        hp_bonus=58;  def=15;  grade=2; price=120
        case(23); name="어둠의 로브";      hp_bonus=90;  def=22;  grade=3; price=350
        case(24); name="화염 방패";        hp_bonus=130; def=30;  grade=3; price=500
        case(25); name="결정 갑옷";        hp_bonus=165; def=38;  grade=4; price=1150
        case(26); name="황금 흉갑";        hp_bonus=210; def=52;  grade=4; price=1650
        case(27); name="서리 외투";        hp_bonus=255; def=63;  grade=4; price=2100
        case(28); name="심판의 갑주";      hp_bonus=340; def=88;  grade=5; price=4200
        case(29); name="천사의 날개 갑옷"; hp_bonus=420; def=108; grade=5; price=6000
        case(30); name="허공의 갑주";      hp_bonus=520; def=135; grade=5; price=8500
        case(11); name="정령 조끼";         hp_bonus=120; def=28;  grade=3; price=410
        case(12); name="바람 망토";         hp_bonus=145; def=32;  grade=3; price=530
        case(13); name="화염 갑옷";         hp_bonus=175; def=40;  grade=4; price=1550
        case(14); name="빙결 방패";         hp_bonus=220; def=55;  grade=4; price=1950
        case(15); name="번개 갑주";         hp_bonus=250; def=65;  grade=4; price=2350
        case(16); name="용심장갑";          hp_bonus=298; def=80;  grade=4; price=2900
        case(17); name="정령왕 외투";       hp_bonus=355; def=95;  grade=5; price=5100
        case(18); name="천상의 갑주";       hp_bonus=430; def=115; grade=5; price=7200
        case(19); name="심연의 로브";       hp_bonus=510; def=130; grade=5; price=8800
        case(20); name="창세의 갑주";       hp_bonus=630; def=160; grade=5; price=11500
        case default; name="낡은 천 옷";    hp_bonus=8;   def=2;   grade=1; price=12
        end select
    end subroutine get_armor_by_idx

    subroutine draw_weapon_art(idx)
        integer, intent(in) :: idx
        select case(idx)
        case(1,2)
            write(*,'(A)')"          .=."
            write(*,'(A)')"         / | \"
            write(*,'(A)')"         \ | /"
            write(*,'(A)')"          \|/"
            write(*,'(A)')"           |"
            write(*,'(A)')"          /|\"
            write(*,'(A)')"         / | \"
        case(3,4)
            write(*,'(A)')"            /\"
            write(*,'(A)')"           /  \"
            write(*,'(A)')"          / /\ \"
            write(*,'(A)')"          | || |"
            write(*,'(A)')"          | || |"
            write(*,'(A)')"     _____| || |_____"
            write(*,'(A)')"    |_______|  |_____|"
            write(*,'(A)')"          |    |"
            write(*,'(A)')"          |____|"
        case(5,6)
            write(*,'(A)')"            *"
            write(*,'(A)')"           /|\"
            write(*,'(A)')"          * | *"
            write(*,'(A)')"            |"
            write(*,'(A)')"            |"
            write(*,'(A)')"            |"
            write(*,'(A)')"           ===  "
        case(7,8)
            write(*,'(A)')"          /\"
            write(*,'(A)')"         /##\"
            write(*,'(A)')"        /####\"
            write(*,'(A)')"       /######\"
            write(*,'(A)')"       |######|"
            write(*,'(A)')"  _____|######|_____"
            write(*,'(A)')"  |___|########|___|"
            write(*,'(A)')"       |######|"
            write(*,'(A)')"       |######|"
            write(*,'(A)')"        \####/"
            write(*,'(A)')"         \##/"
            write(*,'(A)')"          \/"
        case(9,10,19,20,29,30)
            write(*,'(A)')"         +  /\  +"
            write(*,'(A)')"        /  /##\  \"
            write(*,'(A)')"       +  /####\  +"
            write(*,'(A)')"      *  /######\  *"
            write(*,'(A)')"         |######|"
            write(*,'(A)')"  ###### |######| ######"
            write(*,'(A)')"  ######|########|######"
            write(*,'(A)')"         |######|"
            write(*,'(A)')"        /  \##/  \"
            write(*,'(A)')"       /    \/    \"
        case(11,12,21,22)
            write(*,'(A)')"           *"
            write(*,'(A)')"          /|\"
            write(*,'(A)')"         * | *"
            write(*,'(A)')"        /  |  \"
            write(*,'(A)')"            |"
            write(*,'(A)')"           ===  "
        case(13,14,23,24)
            write(*,'(A)')"            /\"
            write(*,'(A)')"           /~~\"
            write(*,'(A)')"          /~~~~\"
            write(*,'(A)')"       ___|~~~~|___"
            write(*,'(A)')"      |___| || |___|"
            write(*,'(A)')"           |  |"
            write(*,'(A)')"           |__|"
        case(15,16,25,26)
            write(*,'(A)')"        ===O==="
            write(*,'(A)')"       / )|(  \"
            write(*,'(A)')"      /  )|( * \"
            write(*,'(A)')"         )|(   "
            write(*,'(A)')"         )|(   "
            write(*,'(A)')"         )|(   "
        case(17,18,27,28)
            write(*,'(A)')"          /\"
            write(*,'(A)')"         /!!"
            write(*,'(A)')"        /####\"
            write(*,'(A)')"       /######\"
            write(*,'(A)')"       |MYTHIC|"
            write(*,'(A)')"  ===**|######|**==="
            write(*,'(A)')"  ===**|######|**==="
            write(*,'(A)')"       |######|"
            write(*,'(A)')"        \####/"
            write(*,'(A)')"         \##/ "
            write(*,'(A)')"     ~~~~\/ ~~~~"
        case default
            write(*,'(A)')"       **  /\  **"
            write(*,'(A)')"      *   /##\   *"
            write(*,'(A)')"     *   /####\   *"
            write(*,'(A)')"    *   /######\   *"
            write(*,'(A)')"        |######|"
            write(*,'(A)')"  ===== |######| ====="
            write(*,'(A)')"  =====|########|====="
            write(*,'(A)')"        |######|"
            write(*,'(A)')"        |######|"
            write(*,'(A)')"         \####/"
            write(*,'(A)')"          \##/"
            write(*,'(A)')"      ~~~~\/ ~~~~"
        end select
    end subroutine draw_weapon_art

    subroutine draw_armor_art(idx)
        integer, intent(in) :: idx
        select case(idx)
        case(1,2)
            write(*,'(A)')"          ______"
            write(*,'(A)')"         /      \"
            write(*,'(A)')"        |  (  )  |"
            write(*,'(A)')"        |________|"
            write(*,'(A)')"        |        |"
            write(*,'(A)')"        |        |"
            write(*,'(A)')"        |________|"
        case(3,4)
            write(*,'(A)')"         ________"
            write(*,'(A)')"        /########\"
            write(*,'(A)')"       |##########|"
            write(*,'(A)')"       |##########|"
            write(*,'(A)')"       |##########|"
            write(*,'(A)')"        \########/"
            write(*,'(A)')"         \######/"
        case(5,6)
            write(*,'(A)')"       *  ______  *"
            write(*,'(A)')"         /::::::\"
            write(*,'(A)')"        |::[  ]::|"
            write(*,'(A)')"        |::::::::|"
            write(*,'(A)')"        |::[  ]::|"
            write(*,'(A)')"         \::::::/"
            write(*,'(A)')"          \~~~~~/"
        case(7,8)
            write(*,'(A)')"     **  ________  **"
            write(*,'(A)')"        /########\"
            write(*,'(A)')"       |##[  ]  ##|"
            write(*,'(A)')"       |## [  ] ##|"
            write(*,'(A)')"       |##########|"
            write(*,'(A)')"        \########/"
            write(*,'(A)')"     **  \######/  **"
        case(9,10,19,20,29,30)
            write(*,'(A)')"   *** ___________  ***"
            write(*,'(A)')"      /###########\"
            write(*,'(A)')"     |###[ *** ]###|"
            write(*,'(A)')"     |###[ *** ]###|"
            write(*,'(A)')"     |###[ *** ]###|"
            write(*,'(A)')"      \###########/"
            write(*,'(A)')"   ***  \########/  ***"
            write(*,'(A)')"        **~**~**~**"
        case(11,12,21,22)
            write(*,'(A)')"       *  ______  *"
            write(*,'(A)')"         /------\"
            write(*,'(A)')"        |--[  ]--|"
            write(*,'(A)')"        |--------|"
            write(*,'(A)')"        |--[  ]--|"
            write(*,'(A)')"         \------/"
            write(*,'(A)')"          \~~~~/"
        case(13,14,23,24)
            write(*,'(A)')"      ** ________  **"
            write(*,'(A)')"        /++++++++\"
            write(*,'(A)')"       |++++++++++|"
            write(*,'(A)')"       |+[    ]+  |"
            write(*,'(A)')"       |++++++++++|"
            write(*,'(A)')"        \++++++++/"
            write(*,'(A)')"      **  \++++++/  **"
        case(15,16,25,26)
            write(*,'(A)')"     **  ________  **"
            write(*,'(A)')"        /@@@@@@@@\"
            write(*,'(A)')"       |@@[    ]@@|"
            write(*,'(A)')"       |@@ [  ] @@|"
            write(*,'(A)')"       |@@@@@@@@@@|"
            write(*,'(A)')"        \@@@@@@@@/"
            write(*,'(A)')"     **  \@@@@@@/  **"
        case(17,18,27,28)
            write(*,'(A)')"   ***** __________  *****"
            write(*,'(A)')"         /%%%%%%%%%%\"
            write(*,'(A)')"        |%%[ *** ]%%%|"
            write(*,'(A)')"        |%%[     ]%%%|"
            write(*,'(A)')"        |%%[ *** ]%%%|"
            write(*,'(A)')"         \%%%%%%%%%%/"
            write(*,'(A)')"   *****  \%%%%%%%%/  *****"
            write(*,'(A)')"          **%**%**%**"
        case default
            write(*,'(A)')"   *** ___________  ***"
            write(*,'(A)')"      /###########\"
            write(*,'(A)')"     |###[ *** ]###|"
            write(*,'(A)')"     |###[     ]###|"
            write(*,'(A)')"     |###[ *** ]###|"
            write(*,'(A)')"      \###########/"
            write(*,'(A)')"   ***  \########/  ***"
            write(*,'(A)')"        *~*~*~*~*"
        end select
    end subroutine draw_armor_art
end module game_items
!=============================================================================
module game_graphics
    use game_types
    use game_utils
    implicit none
    contains

    subroutine draw_gemini_cli_banner()
        write(*,'(A)')"  ▄████ ▓█████  ███▄ ▄███▓ ██▓ ███▄    █  ██▓               "
        write(*,'(A)')" ██▒ ▀█▒▓█   ▀ ▓██▒▀█▀ ██▒▓██▒ ██ ▀█   █ ▓██▒               "
        write(*,'(A)')"▒██░▄▄▄░▒███   ▓██    ▓██░▒██▒▓██  ▀█ ██▒▒██▒               "
        write(*,'(A)')"░▓█  ██▓▒▓█  ▄ ▒██    ▒██ ░██░▓██▒  ▐▌██▒░██░               "
        write(*,'(A)')"░▒▓███▀▒░▒████▒▒██▒   ░██▒░██░▒██░   ▓██░░██░               "
        write(*,'(A)')" ░▒   ▒ ░░ ▒░ ░░ ▒░   ░  ░░▓  ░ ▒░   ▒ ▒ ░▓                 "
        write(*,'(A)')"  ░   ░  ░ ░  ░░  ░      ░ ▒ ░░ ░░   ░ ▒░ ▒ ░               "
        write(*,'(A)')"░ ░   ░    ░   ░      ░    ▒ ░   ░   ░ ░  ▒ ░               "
        write(*,'(A)')"      ░    ░  ░       ░    ░           ░  ░                 "
        write(*,'(A)')"                                                            "
        write(*,'(A)')"                                        ▄████▄   ██▓     ██▓"
        write(*,'(A)')"                                       ▒██▀ ▀█  ▓██▒    ▓██▒"
        write(*,'(A)')"                                       ▒▓█    ▄ ▒██░    ▒██▒"
        write(*,'(A)')"                                       ▒▓▓▄ ▄██▒▒██░    ░██░"
        write(*,'(A)')"                                       ▒ ▓███▀ ░░██████▒░██░"
        write(*,'(A)')"                                       ░ ░▒ ▒  ░░ ▒░▓  ░░▓  "
        write(*,'(A)')"                                         ░  ▒   ░ ░ ▒  ░ ▒ ░"
        write(*,'(A)')"                                       ░          ░ ░    ▒ ░"
        write(*,'(A)')"                                       ░ ░          ░  ░ ░  "
        write(*,'(A)')"                                       ░                    "
    end subroutine draw_gemini_cli_banner

    subroutine draw_jisay_banner()
        write(*,'(A)')" ▄▄▄██▀▀▀    ██▓     ██████     ▄▄▄         ▓██   ██▓"
        write(*,'(A)')"   ▒██      ▓██▒   ▒██    ▒    ▒████▄        ▒██  ██▒"
        write(*,'(A)')"   ░██      ▒██▒   ░ ▓██▄      ▒██  ▀█▄       ▒██ ██░"
        write(*,'(A)')"▓██▄██▓     ░██░     ▒   ██▒   ░██▄▄▄▄██      ░ ▐██▓░"
        write(*,'(A)')" ▓███▒      ░██░   ▒██████▒▒    ▓█   ▓██▒     ░ ██▒▓░"
        write(*,'(A)')" ▒▓▒▒░      ░▓     ▒ ▒▓▒ ▒ ░    ▒▒   ▓▒█░      ██▒▒▒ "
        write(*,'(A)')" ▒ ░▒░       ▒ ░   ░ ░▒  ░ ░     ▒   ▒▒ ░    ▓██ ░▒░ "
        write(*,'(A)')" ░ ░ ░       ▒ ░   ░  ░  ░       ░   ▒       ▒ ▒ ░░  "
        write(*,'(A)')" ░   ░       ░           ░           ░  ░    ░ ░     "
        write(*,'(A)')"                                             ░ ░     "
    end subroutine draw_jisay_banner

    subroutine draw_claude_banner()
        write(*,'(A)')" ▄████▄      ██▓        ▄▄▄          █    ██    ▓█████▄    ▓█████ "
        write(*,'(A)')"▒██▀ ▀█     ▓██▒       ▒████▄        ██  ▓██▒   ▒██▀ ██▌   ▓█   ▀ "
        write(*,'(A)')"▒▓█    ▄    ▒██░       ▒██  ▀█▄     ▓██  ▒██░   ░██   █▌   ▒███   "
        write(*,'(A)')"▒▓▓▄ ▄██▒   ▒██░       ░██▄▄▄▄██    ▓▓█  ░██░   ░▓█▄   ▌   ▒▓█  ▄ "
        write(*,'(A)')"▒ ▓███▀ ░   ░██████▒    ▓█   ▓██▒   ▒▒█████▓    ░▒████▓    ░▒████▒"
        write(*,'(A)')"░ ░▒ ▒  ░   ░ ▒░▓  ░    ▒▒   ▓▒█░   ░▒▓▒ ▒ ▒     ▒▒▓  ▒    ░░ ▒░ ░"
        write(*,'(A)')"  ░  ▒      ░ ░ ▒  ░     ▒   ▒▒ ░   ░░▒░ ░ ░     ░ ▒  ▒     ░ ░  ░"
        write(*,'(A)')"░             ░ ░        ░   ▒       ░░░ ░ ░     ░ ░  ░       ░   "
        write(*,'(A)')"░ ░             ░  ░         ░  ░      ░           ░          ░  ░"
        write(*,'(A)')"░                                                ░                "
    end subroutine draw_claude_banner

    subroutine draw_intro_animation()
        ! ── GEMINI CLI 배너 2번 깜빡임 ──
        call clear_screen()
        call draw_gemini_cli_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.30)
        call draw_gemini_cli_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.50)

        ! ── CLAUDE 배너 2번 깜빡임 ──
        call draw_claude_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.30)
        call draw_claude_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.50)

        ! ── JISAY 배너 2번 깜빡임 ──
        call draw_jisay_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.30)
        call draw_jisay_banner()
        call delay(0.55)
        call clear_screen()
        call delay(0.30)
    end subroutine draw_intro_animation

    subroutine draw_ruined_castle_hd()
        write(*,'(A)')"      *       .     *       .      *       .      *      .  "
        write(*,'(A)')"   .       *       .     *       .      *       .      *    "
        write(*,'(A)')"                                                             "
        write(*,'(A)')"         /\          /\                /\          /\        "
        write(*,'(A)')"        |  |   /\   |  |              |  |   /\   |  |       "
        write(*,'(A)')"     ___|  |__|  |__|  |______________|  |__|  |__|  |___    "
        write(*,'(A)')"    |  _   _   _   _   _   _   _   _   _   _   _   _   _  | "
        write(*,'(A)')"    | |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |"
        write(*,'(A)')"    |                                                       | "
        write(*,'(A)')"    |    ~  R U I N E D   A N C I E N T   C A S T L E ~   | "
        write(*,'(A)')"    |                            *                          | "
        write(*,'(A)')"    |   __    __   ______________________________   __      | "
        write(*,'(A)')"    |  |  |  |  | |                              | |  |     | "
        write(*,'(A)')"    |  |  |  |  | |      [ BROKEN  GATE ]        | |  |     | "
        write(*,'(A)')"    |  |__|  |__| |______________________________| |__|     | "
        write(*,'(A)')"    |___/\___/\___/\____________________________/\___/\_____|"
        write(*,'(A)')"       /    \/    \/  \/                        \/    \/    \ "
        write(*,'(A)')"      /      \   rubble  .    *    .   rubble    .     \    \ "
        write(*,'(A)')"     /________\_________________________________________\____\ "
    end subroutine draw_ruined_castle_hd

    subroutine draw_adventure_of_many_banner()
        write(*,'(A)')"▄▄▄      ▓█████▄  ██▒   █▓▓█████  ███▄    █ ▄▄▄█████▓ █    ██  ██▀███  ▓█████ "
        write(*,'(A)')"▒████▄    ▒██▀ ██▌▓██░   █▒▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒ ██  ▓██▒▓██ ▒ ██▒▓█   ▀ "
        write(*,'(A)')"▒██  ▀█▄  ░██   █▌ ▓██  █▒░▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░▓██  ▒██░▓██ ░▄█ ▒▒███   "
        write(*,'(A)')"░██▄▄▄▄██ ░▓█▄   ▌  ▒██ █░░▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░ ▓▓█  ░██░▒██▀▀█▄  ▒▓█  ▄ "
        write(*,'(A)')" ▓█   ▓██▒░▒████▓    ▒▀█░  ░▒████▒▒██░   ▓██░  ▒██▒ ░ ▒▒█████▓ ░██▓ ▒██▒░▒████▒"
        write(*,'(A)')" ▒▒   ▓▒█░ ▒▒▓  ▒    ░ ▐░  ░░ ▒░ ░░ ▒░   ▒ ▒   ▒ ░░   ░▒▓▒ ▒ ▒ ░ ▒▓ ░▒▓░░░ ▒░ ░"
        write(*,'(A)')"  ▒   ▒▒ ░ ░ ▒  ▒    ░ ░░   ░ ░  ░░ ░░   ░ ▒░    ░    ░░▒░ ░ ░   ░▒ ░ ▒░ ░ ░  ░"
        write(*,'(A)')"  ░   ▒    ░ ░  ░      ░░     ░      ░   ░ ░   ░       ░░░ ░ ░   ░░   ░    ░   "
        write(*,'(A)')"      ░  ░   ░          ░     ░  ░         ░             ░        ░        ░  ░"
        write(*,'(A)')"           ░           ░                                                       "
        write(*,'(A)')"                      ▒█████    █████▒                                         "
        write(*,'(A)')"                     ▒██▒  ██▒▓██   ▒                                          "
        write(*,'(A)')"                     ▒██░  ██▒▒████ ░                                          "
        write(*,'(A)')"                     ▒██   ██░░▓█▒  ░                                          "
        write(*,'(A)')"                     ░ ████▓▒░░▒█░                                             "
        write(*,'(A)')"                     ░ ▒░▒░▒░  ▒ ░                                             "
        write(*,'(A)')"                       ░ ▒ ▒░  ░                                               "
        write(*,'(A)')"                     ░ ░ ░ ▒   ░ ░                                             "
        write(*,'(A)')"                         ░ ░                                                   "
        write(*,'(A)')"                                                                               "
        write(*,'(A)')"                               ███▄ ▄███▓ ▄▄▄       ███▄    █▓██   ██▓         "
        write(*,'(A)')"                              ▓██▒▀█▀ ██▒▒████▄     ██ ▀█   █ ▒██  ██▒         "
        write(*,'(A)')"                              ▓██    ▓██░▒██  ▀█▄  ▓██  ▀█ ██▒ ▒██ ██░         "
        write(*,'(A)')"                              ▒██    ▒██ ░██▄▄▄▄██ ▓██▒  ▐▌██▒ ░ ▐██▓░         "
        write(*,'(A)')"                              ▒██▒   ░██▒ ▓█   ▓██▒▒██░   ▓██░ ░ ██▒▓░         "
        write(*,'(A)')"                              ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒░   ▒ ▒   ██▒▒▒          "
        write(*,'(A)')"                              ░  ░      ░  ▒   ▒▒ ░░ ░░   ░ ▒░▓██ ░▒░          "
        write(*,'(A)')"                              ░      ░     ░   ▒      ░   ░ ░ ▒ ▒ ░░           "
        write(*,'(A)')"                                     ░         ░  ░         ░ ░ ░              "
        write(*,'(A)')"                                                              ░ ░              "
    end subroutine draw_adventure_of_many_banner

    subroutine draw_character_portrait(job)
        integer, intent(in) :: job
        select case(job)
        case(JOB_MANY)
            write(*,'(A)')"            /########\"
            write(*,'(A)')"           |  ^    ^  |"
            write(*,'(A)')"           |    --    |"
            write(*,'(A)')"          /|  [MANY]  |\"
            write(*,'(A)')"         / |__________| \"
            write(*,'(A)')"        /  /  ======   \  \"
            write(*,'(A)')"       |__/    |    |    \__|"
        case(JOB_HOPPANG)
            write(*,'(A)')"          ____________ "
            write(*,'(A)')"         /  ________  \"
            write(*,'(A)')"        |  | o    o |  |"
            write(*,'(A)')"        |  |   __   |  |"
            write(*,'(A)')"      [###|__________|###]"
            write(*,'(A)')"      [###|  HOPPANG |###]"
            write(*,'(A)')"      [###|___________|###]"
        case(JOB_MILK)
            write(*,'(A)')"             /    \"
            write(*,'(A)')"            ( @  @ )"
            write(*,'(A)')"           /  \--/  \"
            write(*,'(A)')"          /   /  \   \"
            write(*,'(A)')"         / [ MILK  ] \"
            write(*,'(A)')"        /      ||      \"
            write(*,'(A)')"       /_______________\"
        case(JOB_JJABDAM)
            write(*,'(A)')"           __________"
            write(*,'(A)')"          |  >    <  |"
            write(*,'(A)')"          |____  ____|"
            write(*,'(A)')"         /      \/    \"
            write(*,'(A)')"        /   [SHADOW]   \"
            write(*,'(A)')"       /_______________\"
            write(*,'(A)')"      // ''         '' \\"
        case(JOB_JISAY)
            write(*,'(A)')"            _*_*_"
            write(*,'(A)')"           ( === )"
            write(*,'(A)')"          /   *   \"
            write(*,'(A)')"         |  O   O  |"
            write(*,'(A)')"         |    --    |"
            write(*,'(A)')"        /|  [JISAY] |\"
            write(*,'(A)')"       /_|___________|_\"
        end select
    end subroutine draw_character_portrait

    subroutine draw_modern_world_map(pc)
        type(character_t), intent(in) :: pc
        integer :: r
        r = pc%current_region
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║           ≋  N A T U R E   W O R L D   M A P  ≋         ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║  N                                                       ║"
        if (r == 1 .or. r == 2 .or. r == 3 .or. r == 4) then
        write(*,'(A)')"  ║  ↑  ★[햇살 숲]──[가시덤불]──[속삭임숲]──[고대소나무]   ║"
        else
        write(*,'(A)')"  ║  ↑   [햇살 숲]──[가시덤불]──[속삭임숲]──[고대소나무]   ║"
        end if
        write(*,'(A)')"  ║  |      │                                    │           ║"
        if (r == 5 .or. r == 6 .or. r == 7 .or. r == 8) then
        write(*,'(A)')"  ║ W+E ★[산호해변]──[난파선]───[늪지대]───[북쪽호수]       ║"
        else
        write(*,'(A)')"  ║ W+E  [산호해변]──[난파선]───[늪지대]───[북쪽호수]       ║"
        end if
        write(*,'(A)')"  ║  |      │                                    │           ║"
        if (r == 9 .or. r == 10 .or. r == 11 .or. r == 12) then
        write(*,'(A)')"  ║  ↓  ★[고대탑]───[모래사막]──[화산산길]──[하늘섬]       ║"
        else
        write(*,'(A)')"  ║  ↓   [고대탑]───[모래사막]──[화산산길]──[하늘섬]       ║"
        end if
        write(*,'(A)')"  ║         │                                    │           ║"
        if (r == 13 .or. r == 14 .or. r == 15 .or. r == 16) then
        write(*,'(A)')"  ║       ★[요정마을]──[연금술사]──[정령샘터]──[용병야영] ║"
        else
        write(*,'(A)')"  ║        [요정마을]──[연금술사]──[정령샘터]──[용병야영] ║"
        end if
        write(*,'(A)')"  ║         │                                    │           ║"
        if (r == 17 .or. r == 18 .or. r == 19 .or. r == 20) then
        write(*,'(A)')"  ║       ★[거인절벽]──[영혼계곡]──[공허틈새]──[보스화산] ║"
        else
        write(*,'(A)')"  ║        [거인절벽]──[영혼계곡]──[공허틈새]──[보스화산] ║"
        end if
        write(*,'(A)')"  ║         │                                    │           ║"
        if (r == 21 .or. r == 22 .or. r == 23 .or. r == 24) then
        write(*,'(A)')"  ║       ★[심연동굴]──[얼음툰드라]─[드래곤둥지]─[신비정원]║"
        else
        write(*,'(A)')"  ║        [심연동굴]──[얼음툰드라]─[드래곤둥지]─[신비정원]║"
        end if
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════╣"
        write(*, '("  ║  ★ 현재 위치: 지역 ", I2, " / 스테이지 ", I2, T63, "║")') &
            pc%current_region, pc%current_stage
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════════╝"
    end subroutine draw_modern_world_map

    subroutine draw_battle_frame(pc, e_name, m_hp, f, a)
        type(character_t), intent(in) :: pc
        character(len=*), intent(in) :: e_name
        integer, intent(in) :: m_hp, f, a
        call clear_screen()
        write(*,'(A)')"  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━ C O M B A T ━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '("  ┃  HP: ", I4, "/", I4, " | ATK: ", I3, " | GOLD: ", I5, " | 포션: ", I2, T71, "┃")') &
            pc%hp, pc%max_hp, pc%base_atk+pc%weapon%atk, pc%gold, pc%hp_potions
        write(*,'(A)')"  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
        write(*, '("                    ", T35, "[[ ", A15, " HP: ", I5, " ]]")') e_name, m_hp
        if (a == 2) write(*,'(A)')"  [!] 몬스터의 반격! !! CRASH !!"
        if (a == 1) write(*,'(A)')"  [!] 영웅의 공격! !! SLASH !!"
    end subroutine draw_battle_frame
end module game_graphics
!=============================================================================
module game_logic
    use game_types
    use game_utils
    use game_graphics
    use game_items
    implicit none
    contains

    subroutine show_start_menu_box()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║   ≋  무너진 고대 성에 오신 것을 환영합니다.  ≋                   ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║                                                                  ║"
        write(*,'(A)')"  ║      [ 1 ]  새 게임 시작                                         ║"
        write(*,'(A)')"  ║      [ 2 ]  불러오기                                             ║"
        write(*,'(A)')"  ║      [ 3 ]  나가기                                               ║"
        write(*,'(A)')"  ║                                                                  ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
    end subroutine show_start_menu_box

    subroutine show_main_command_box()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║          ◈   M A I N   C O M M A N D   M E N U   ◈              ║"
        write(*,'(A)')"  ╠═══════════════╦══════════════╦════════════════╦══════════════════╣"
        write(*,'(A)')"  ║   [ 1 ] 탐험  ║  [ 2 ] 상점  ║ [ 3 ] 인벤토리║ [ 4 ] 저장       ║"
        write(*,'(A)')"  ╠═══════════════╩══════════════╩════════════════╩══════════════════╣"
        write(*,'(A)')"  ║      [ 5 ] 게임 종료          [ 6 ] 스킬 관리                    ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
    end subroutine show_main_command_box

    subroutine show_dialogue_box(s, m, o)
        character(len=*), intent(in) :: s, m
        character(len=*), intent(in), optional :: o
        write(*,'(A)')"  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '("  ┃  [ ", A20, " ]", T69, "┃")') trim(s)
        write(*,'(A)')"  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫"
        write(*, '("  ┃  ", A62, "  ┃")') trim(m)
        if (present(o)) then
            write(*,'(A)')"  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫"
            write(*, '("  ┃  ", A62, "  ┃")') trim(o)
        end if
        write(*,'(A)')"  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
    end subroutine show_dialogue_box

    ! D1: init_character_skills
    subroutine init_character_skills(pc)
        type(character_t), intent(inout) :: pc
        select case(pc%job)
        case(JOB_MANY)
            pc%skills(1) = skill_t("대지 강타",    1,15,  1, ELEM_EARTH, 1.4, .true.,  .true.)
            pc%skills(2) = skill_t("황금 소나기",  1,25,  5, ELEM_EARTH, 1.8, .false., .false.)
            pc%skills(3) = skill_t("대지 분쇄",    1,40, 10, ELEM_EARTH, 2.5, .false., .false.)
            pc%skills(4) = skill_t("대지의 왕",    1,60, 15, ELEM_EARTH, 3.5, .false., .false.)
            pc%skills(5) = skill_t("황금 폭풍",    1,80, 20, ELEM_EARTH, 4.5, .false., .false.)
            pc%skills(6) = skill_t("창세 대지",    1,100,25, ELEM_EARTH, 6.0, .false., .false.)
        case(JOB_HOPPANG)
            pc%skills(1) = skill_t("파도 강타",    1,15,  1, ELEM_WATER, 1.4, .true.,  .true.)
            pc%skills(2) = skill_t("물결 폭발",    1,25,  5, ELEM_WATER, 1.8, .false., .false.)
            pc%skills(3) = skill_t("해일",         1,40, 10, ELEM_WATER, 2.5, .false., .false.)
            pc%skills(4) = skill_t("대홍수",       1,60, 15, ELEM_WATER, 3.5, .false., .false.)
            pc%skills(5) = skill_t("심해 압축",    1,80, 20, ELEM_WATER, 4.5, .false., .false.)
            pc%skills(6) = skill_t("창세 홍수",    1,100,25, ELEM_WATER, 6.0, .false., .false.)
        case(JOB_MILK)
            pc%skills(1) = skill_t("화염구",       1,20,  1, ELEM_FIRE,  1.6, .true.,  .true.)
            pc%skills(2) = skill_t("업화 폭발",    1,35,  5, ELEM_FIRE,  2.2, .false., .false.)
            pc%skills(3) = skill_t("용암 분화",    1,50, 10, ELEM_FIRE,  3.0, .false., .false.)
            pc%skills(4) = skill_t("태양 붕괴",    1,70, 15, ELEM_FIRE,  4.0, .false., .false.)
            pc%skills(5) = skill_t("별의 폭발",    1,90, 20, ELEM_FIRE,  5.0, .false., .false.)
            pc%skills(6) = skill_t("창세 화염",    1,120,25, ELEM_FIRE,  7.0, .false., .false.)
        case(JOB_JJABDAM)
            pc%skills(1) = skill_t("바람 베기",    1,12,  1, ELEM_AIR,   1.5, .true.,  .true.)
            pc%skills(2) = skill_t("질풍 연격",    1,22,  5, ELEM_AIR,   2.0, .false., .false.)
            pc%skills(3) = skill_t("폭풍 난무",    1,38, 10, ELEM_AIR,   2.8, .false., .false.)
            pc%skills(4) = skill_t("허리케인",     1,55, 15, ELEM_AIR,   3.8, .false., .false.)
            pc%skills(5) = skill_t("태풍의 눈",    1,75, 20, ELEM_AIR,   4.8, .false., .false.)
            pc%skills(6) = skill_t("창세 폭풍",    1,100,25, ELEM_AIR,   6.5, .false., .false.)
        case(JOB_JISAY)
            pc%skills(1) = skill_t("지배의 오라",  1,25,  1, ELEM_ETHER, 2.0, .true.,  .true.)
            pc%skills(2) = skill_t("에테르 충격",  1,40,  5, ELEM_ETHER, 2.8, .false., .false.)
            pc%skills(3) = skill_t("현실 붕괴",    1,60, 10, ELEM_ETHER, 3.5, .false., .false.)
            pc%skills(4) = skill_t("창세의 심판",  1,100,15, ELEM_ETHER, 5.0, .false., .false.)
            pc%skills(5) = skill_t("절대 지배",    1,140,20, ELEM_ETHER, 7.0, .false., .false.)
            pc%skills(6) = skill_t("무한의 힘",    1,180,25, ELEM_ETHER,10.0, .false., .false.)
        end select
    end subroutine init_character_skills

    ! D4: show_opening_story
    subroutine show_opening_story(pc)
        type(character_t), intent(in) :: pc
        character(len=70) :: line4

        call clear_screen()
        write(*,'(A)')"        *    .    *    .    *    .    *"
        write(*,'(A)')"   .   *    .   *    .    *    .    *"
        write(*,'(A)')"          /\   /\         /\   /\"
        write(*,'(A)')"         |  | |  |       |  | |  |"
        write(*,'(A)')"    _____|  |_|  |_______|  |_|  |_____"
        write(*,'(A)')"   |  CRACK IN THE WORLD TREE          |"
        write(*,'(A)')"   |  * . * . * . * . * . * . * . * . |"
        write(*,'(A)')"   |  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|"
        write(*,'(A)')"   |______________________________________|"
        print *, ""
        call show_dialogue_box("세계수", "세계수가 갈라지기 시작했다... 다섯 속성의 균형이 무너져가고 있어.", "")
        call wait_for_enter()
        call show_dialogue_box("세계수", "각 속성의 수호자들이 하나둘씩 타락해가고, 세상은 혼돈에 빠져들고 있다.", "")
        call wait_for_enter()
        call show_dialogue_box("세계수", trim(pc%name)//"... 너만이 이 혼돈을 막을 수 있다. 네 안의 힘을 깨워라.", "")
        call wait_for_enter()
        select case(pc%job)
        case(JOB_MANY)
            line4 = "대지의 힘이 너를 택했다. 흔들리지 않는 대지처럼 앞으로 나아가라."
        case(JOB_HOPPANG)
            line4 = "물의 힘이 너를 감쌌다. 물처럼 어떤 형태로든 적에 맞서라."
        case(JOB_MILK)
            line4 = "불의 힘이 너를 태웠다. 모든 것을 태울 화염을 피워올려라."
        case(JOB_JJABDAM)
            line4 = "바람의 힘이 너를 스쳐갔다. 바람처럼 자유롭게 싸워라."
        case(JOB_JISAY)
            line4 = "에테르의 힘이 너를 지배했다. 현실 그 너머를 보아라."
        end select
        call show_dialogue_box("운명", trim(line4), "")
        call wait_for_enter()
    end subroutine show_opening_story

    ! D3: scene_pet_selection
    subroutine scene_pet_selection(pc)
        type(character_t), intent(inout) :: pc
        integer :: choice

        do
            call clear_screen()
            write(*,'(A)')"  ╔════════════════════════════ 펫 선택 ════════════════════════════╗"
            write(*,'(A)')"  ║  동반자를 선택하세요.                                          ║"
            write(*,'(A)')"  ╠════════════════════════════════════════════════════════════════╣"
            write(*,'(A)')"  ║  (1) 앉아있는작은새 [공기] ATK:15 HP:50  특기: 회피 보조      ║"
            write(*,'(A)')"     .~."
            write(*,'(A)')"    (o o)"
            write(*,'(A)')"   /|=W=|\"
            write(*,'(A)')"     | |"
            write(*,'(A)')"     W W"
            write(*,'(A)')"  ║  (2) 새헤이만       [공기] ATK:25 HP:40  특기: 빠른 2회 공격  ║"
            write(*,'(A)')"     >>="
            write(*,'(A)')"    (^.^)>>"
            write(*,'(A)')"   /-|W|-\"
            write(*,'(A)')"     | |"
            write(*,'(A)')"    / \"
            write(*,'(A)')"  ║  (3) 윤현식         [흙]  ATK:20 HP:80  특기: 방어 보조       ║"
            write(*,'(A)')"   (=====)"
            write(*,'(A)')"  ( o   o )"
            write(*,'(A)')"  | EARTH |"
            write(*,'(A)')"   \=====/"
            write(*,'(A)')"   _|| ||_"
            write(*,'(A)')"  ║  (4) 닭헤이만       [불]  ATK:30 HP:45  특기: 화염 속성 공격  ║"
            write(*,'(A)')"   *~*~*"
            write(*,'(A)')"  (@ . @)"
            write(*,'(A)')"  |CLUCK|"
            write(*,'(A)')"   \===/"
            write(*,'(A)')"   /| |\"
            write(*,'(A)')"  ║  (5) 전틍           [에테르] ATK:35 HP:60 특기: 무작위 강공격 ║"
            write(*,'(A)')"  **_**"
            write(*,'(A)')" *(O O)*"
            write(*,'(A)')" *|TANG|*"
            write(*,'(A)')" *\==/*"
            write(*,'(A)')"  *||*"
            write(*,'(A)')"  ╚════════════════════════════════════════════════════════════════╝"
            call safe_read(choice)
            if (choice >= 1 .and. choice <= 5) exit
        end do

        select case(choice)
        case(1)
            pc%pet%name    = "앉아있는작은새"
            pc%pet%element = ELEM_AIR
            pc%pet%atk     = 15
            pc%pet%max_hp  = 50
        case(2)
            pc%pet%name    = "새헤이만"
            pc%pet%element = ELEM_AIR
            pc%pet%atk     = 25
            pc%pet%max_hp  = 40
        case(3)
            pc%pet%name    = "윤현식"
            pc%pet%element = ELEM_EARTH
            pc%pet%atk     = 20
            pc%pet%max_hp  = 80
        case(4)
            pc%pet%name    = "닭헤이만"
            pc%pet%element = ELEM_FIRE
            pc%pet%atk     = 30
            pc%pet%max_hp  = 45
        case(5)
            pc%pet%name    = "전틍"
            pc%pet%element = ELEM_ETHER
            pc%pet%atk     = 35
            pc%pet%max_hp  = 60
        end select
        pc%pet%hp      = pc%pet%max_hp
        pc%pet%level   = 1
        pc%pet%xp      = 0
        pc%pet%next_xp = 50
        pc%pet%active  = .true.
        call show_dialogue_box("펫 선택", trim(pc%pet%name)//"이(가) 당신의 동반자가 되었습니다!", "")
        call wait_for_enter()
    end subroutine scene_pet_selection

    ! D2: scene_skill_menu
    subroutine scene_skill_menu(pc)
        type(character_t), intent(inout) :: pc
        integer :: i, choice, sub_choice
        character(len=5) :: lock_str
        character(len=6) :: eq_str

        do
            call clear_screen()
            write(*,'(A)')"  ╔═══════════════════════════════ 스 킬 관 리 ═════════════════════════════╗"
            write(*, '("  ║ 스킬 포인트: ", I3, "   현재 MP: ", I4, "/", I4, T75, "║")') &
                pc%skill_points, pc%mp, pc%max_mp
            write(*,'(A)')"  ╠══╦══════════════════╦═══╦════╦══════╦══════╣"
            write(*,'(A)')"  ║# ║ 스킬명           ║Lv ║ MP ║ 배율 ║ 장착 ║"
            write(*,'(A)')"  ╠══╬══════════════════╬═══╬════╬══════╬══════╣"
            do i = 1, 6
                if (pc%skills(i)%unlocked) then
                    lock_str = "    "
                    if (pc%skills(i)%equipped) then
                        eq_str = " [O] "
                    else
                        eq_str = " [X] "
                    end if
                    write(*, '("  ║", I1, " ║ ", A16, " ║", I3, " ║", I4, " ║ x", F3.1, " ║", A5, " ║")') &
                        i, trim(pc%skills(i)%name), pc%skills(i)%slevel, &
                        pc%skills(i)%mp_cost, pc%skills(i)%dmg_mult, trim(eq_str)
                else
                    write(*, '("  ║", I1, " ║ ", A16, " ║ - ║", I4, " ║ x", F3.1, " ║ [잠] ║")') &
                        i, trim(pc%skills(i)%name), pc%skills(i)%mp_cost, pc%skills(i)%dmg_mult
                end if
            end do
            write(*,'(A)')"  ╚══╩══════════════════╩═══╩════╩══════╩══════╝"
            write(*,'(A)')"  선택 번호 입력 (0=나가기):"
            call safe_read(choice)
            if (choice == 0) exit
            if (choice < 1 .or. choice > 6) cycle
            if (.not. pc%skills(choice)%unlocked) then
                write(*, '("  [!] 레벨 ", I2, " 이상 필요합니다.")') pc%skills(choice)%req_level
                call wait_for_enter()
                cycle
            end if
            write(*,'(A)')"  (U) 레벨업 (-1 스킬포인트)  (E) 장착/해제  (0) 취소"
            call safe_read(sub_choice)
            if (sub_choice == 0) cycle  ! U=85, E=69 as ascii but we use integer menu
            ! sub_choice: 1=LevelUp, 2=Equip/Unequip
            if (sub_choice == 1) then
                if (pc%skill_points < 1) then
                    write(*,'(A)')"  [!] 스킬 포인트가 부족합니다."
                    call wait_for_enter()
                else
                    pc%skill_points = pc%skill_points - 1
                    pc%skills(choice)%slevel   = pc%skills(choice)%slevel + 1
                    pc%skills(choice)%dmg_mult = pc%skills(choice)%dmg_mult + 0.2
                    pc%skills(choice)%mp_cost  = pc%skills(choice)%mp_cost  + 5
                    write(*,'(A)')"  [+] 스킬 레벨업 완료!"
                    call wait_for_enter()
                end if
            else if (sub_choice == 2) then
                pc%skills(choice)%equipped = .not. pc%skills(choice)%equipped
                if (pc%skills(choice)%equipped) then
                    write(*,'(A)')"  [+] 스킬 장착 완료!"
                else
                    write(*,'(A)')"  [-] 스킬 해제 완료!"
                end if
                call wait_for_enter()
            end if
        end do
    end subroutine scene_skill_menu

    ! D8: draw_text_map
    subroutine draw_text_map(pc)
        type(character_t), intent(in) :: pc
        integer :: r
        character(len=7) :: c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12
        r = pc%current_region

        if (r==1) then; c1="[★ 1 ]"; else; c1="[  1  ]"; end if
        if (r==2) then; c2="[★ 2 ]"; else; c2="[  2  ]"; end if
        if (r==3) then; c3="[★ 3 ]"; else; c3="[  3  ]"; end if
        if (r==4) then; c4="[★ 4 ]"; else; c4="[  4  ]"; end if
        if (r==5) then; c5="[★ 5 ]"; else; c5="[  5  ]"; end if
        if (r==6) then; c6="[★ 6 ]"; else; c6="[  6  ]"; end if
        if (r==7) then; c7="[★ 7 ]"; else; c7="[  7  ]"; end if
        if (r==8) then; c8="[★ 8 ]"; else; c8="[  8  ]"; end if
        if (r==9) then; c9="[★ 9 ]"; else; c9="[  9  ]"; end if
        if (r==10) then; c10="[★10 ]"; else; c10="[ 10  ]"; end if
        if (r==11) then; c11="[★11 ]"; else; c11="[ 11  ]"; end if
        if (r==12) then; c12="[★12 ]"; else; c12="[ 12  ]"; end if

        write(*,'(A)')"  ╔══════════ 현재 위치 ══════════╗"
        write(*, '("  ║  지역: ", I2, "  스테이지: ", I2, T35, "║")') r, pc%current_stage
        write(*,'(A)')"  ╠═══════════════════════════════╣"
        write(*,'(A)')"  ║                               ║"
        write(*, '("  ║  ", A7, "--", A7, "--", A7, "  ║")') c1, c2, c3
        write(*, '("  ║     |                    |     ║")')
        write(*, '("  ║  ", A7, "--", A7, "--", A7, "  ║")') c5, c6, c7
        write(*, '("  ║     |                    |     ║")')
        write(*, '("  ║  ", A7, "--", A7, "--", A7, "  ║")') c9, c10, c11
        write(*,'(A)')"  ║                               ║"
        write(*,'(A)')"  ╚═══════════════════════════════╝"
        write(*,'(A)')"  ★=현재, [숫자]=지역ID"
    end subroutine draw_text_map

    subroutine create_character(pc)
        type(character_t), intent(out) :: pc
        integer :: choice, confirm, ios, i
        character(len=80) :: desc, traits

        do
            do
                call clear_screen()
                write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
                write(*,'(A)')"  ║              ✦  영웅 선택  ✦   HERO SELECTION                    ║"
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
                write(*,'(A)')"  ║  (1) 매니     │ HP: 100  ATK: 20  회피: 5%  │ 골드 획득 특화    ║"
                write(*,'(A)')"  ║  (2) 호빵     │ HP: 150  ATK: 14  회피: 3%  │ 자동 체력 회복    ║"
                write(*,'(A)')"  ║  (3) 우유     │ HP:  80  ATK: 35  회피: 8%  │ 파괴적 공격력     ║"
                write(*,'(A)')"  ║  (4) 짭담이   │ HP:  90  ATK: 22  회피:20%  │ 높은 회피율       ║"
                write(*,'(A)')"  ║  (5) JISAY    │ HP: 200  ATK: 60  회피:15%  │ 모든 스탯 초월    ║"
                write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
                call safe_read(choice)
                if (choice >= 1 .and. choice <= 5) exit
            end do

            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
            write(*,'(A)')"  ║                   캐릭터 확인                                    ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
            print *, ""
            call draw_character_portrait(choice)
            print *, ""

            select case(choice)
            case(1)
                desc   = "[ 매니 ] - 탐험가 · 모험가"
                traits = "골드 획득량 +50% | 상인과의 거래 우대 | 기본 체력 안정적"
            case(2)
                desc   = "[ 호빵 ] - 방어 전사 · 수호자"
                traits = "매 전투 후 HP 10 자동 회복 | 높은 체력 | 강인한 갑옷 친화"
            case(3)
                desc   = "[ 우유 ] - 마법사 · 파괴자"
                traits = "레벨업시 ATK +30% 추가 | 낮은 HP 주의 | 마법 계열 아이템 효율"
            case(4)
                desc   = "[ 짭담이 ] - 어쌔신 · 그림자"
                traits = "기본 회피율 20% | 치명타 확률 보너스 | 빠른 연속 공격"
            case(5)
                desc   = "[ JISAY ] - 지배자 · 절대자"
                traits = "모든 스탯 최상위 | 특수 스킬 보유 | 비밀 이벤트 해금 가능"
            end select

            call show_dialogue_box("INFO", desc, traits)
            write(*,'(A)')"  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
            write(*,'(A)')"  ┃            (1) 확인  이 영웅으로 시작합니다                        ┃"
            write(*,'(A)')"  ┃            (2) 재설정  다른 영웅을 선택합니다                      ┃"
            write(*,'(A)')"  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
            call safe_read(confirm)
            if (confirm == 1) exit
        end do

        write(*, '("  이름을 입력하세요: ")', advance='no')
        read(*, '(A)') pc%name
        pc%name = trim(pc%name)

        pc%job = choice; pc%level = 1; pc%xp = 0; pc%next_xp = 100
        pc%gold = 200
        pc%current_region = 1; pc%current_stage = 1
        pc%unlocked_region = 1; pc%inn_usage = 0
        pc%inv_count = 0
        pc%skill_points = 0
        pc%mp_potions = 2
        pc%status = STATUS_NORMAL
        pc%status_turns = 0

        select case(pc%job)
        case(JOB_MANY)
            pc%max_hp=100; pc%base_atk=20; pc%evasion=5
            pc%element=ELEM_EARTH; pc%max_mp=80; pc%hp_potions=3
            pc%base_def=5; pc%speed=12
        case(JOB_HOPPANG)
            pc%max_hp=150; pc%base_atk=14; pc%evasion=3
            pc%element=ELEM_WATER; pc%max_mp=60; pc%hp_potions=3
            pc%base_def=10; pc%speed=8
        case(JOB_MILK)
            pc%max_hp=80; pc%base_atk=35; pc%evasion=8
            pc%element=ELEM_FIRE; pc%max_mp=150; pc%hp_potions=3
            pc%base_def=3; pc%speed=14
        case(JOB_JJABDAM)
            pc%max_hp=90; pc%base_atk=22; pc%evasion=20
            pc%element=ELEM_AIR; pc%max_mp=100; pc%hp_potions=3
            pc%base_def=5; pc%speed=20
        case(JOB_JISAY)
            pc%max_hp=200; pc%base_atk=60; pc%evasion=15
            pc%element=ELEM_ETHER; pc%max_mp=200; pc%hp_potions=3
            pc%base_def=15; pc%speed=15
        end select
        pc%hp = pc%max_hp
        pc%mp = pc%max_mp

        do i = 1, INV_SIZE
            pc%inventory(i)%name  = "---"
            pc%inventory(i)%itype = 0
            pc%inventory(i)%value = 0
            pc%inventory(i)%grade = 0
            pc%inventory(i)%price = 0
            pc%inventory(i)%count = 0
        end do

        pc%weapon = weapon_t("낡은 단검", 5, 1, 15)
        pc%armor  = armor_t("낡은 천 옷", 8, 2, 1, 12)

        pc%pet%name    = ""
        pc%pet%element = 1
        pc%pet%level   = 1
        pc%pet%hp      = 0
        pc%pet%max_hp  = 0
        pc%pet%atk     = 0
        pc%pet%xp      = 0
        pc%pet%next_xp = 50
        pc%pet%active  = .false.

        pc%ng_plus  = 0
        pc%mon_seen = 0
        call init_character_skills(pc)
    end subroutine create_character

    subroutine show_main_status_ui(pc)
        type(character_t), intent(in) :: pc
        character(len=10) :: job_name
        character(len=6)  :: ename
        integer :: sb_atk, sb_def, sb_hp
        select case(pc%job)
        case(JOB_MANY);    job_name = "MANY"
        case(JOB_HOPPANG); job_name = "HOPPANG"
        case(JOB_MILK);    job_name = "MILK"
        case(JOB_JJABDAM); job_name = "JJABDAM"
        case(JOB_JISAY);   job_name = "JISAY"
        case default;      job_name = "???"
        end select
        ename = elem_name(pc%element)
        call get_set_bonus(pc, sb_atk, sb_def, sb_hp)

        write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║              ✦   C H A R A C T E R   S T A T S   ✦              ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
        write(*, '("  ║ Name:", A15, " Job:", A8, " Elem:", A6, "      ║")') &
            trim(pc%name), trim(job_name), trim(ename)
        write(*, '("  ║ Lv:", I3, " EXP:", I6, "/", I6, "                              ║")') &
            pc%level, pc%xp, pc%next_xp
        write(*, '("  ║ HP :", I5, "/", I5, "  MP :", I5, "/", I5, "                   ║")') &
            pc%hp, pc%max_hp, pc%mp, pc%max_mp
        write(*, '("  ║ ATK:", I5, "  DEF:", I5, "  SPD:", I3, "  EVA:", I3, "%         ║")') &
            pc%base_atk+pc%weapon%atk, pc%base_def+pc%armor%def, pc%speed, pc%evasion
        write(*, '("  ║ Gold:", I8, "G  SkillPT:", I3, "  Status:", A8, "  ║")') &
            pc%gold, pc%skill_points, trim(status_name(pc%status))
        if (pc%weapon%grade == pc%armor%grade) then
            write(*, '("  ║ SET BONUS: ATK+", I3, " DEF+", I3, " HP+", I4, "              ║")') &
                sb_atk, sb_def, sb_hp
        end if
        if (pc%ng_plus > 0) then
            write(*, '("  ║ NG+", I1, " 모드 (몬스터 ", I3, "% 강화)                         ║")') &
                pc%ng_plus, 20*pc%ng_plus
        end if
        select case(pc%job)
        case(JOB_MANY)
            write(*, '("  ║ PASSIVE[상인의직감]: 상점 ", I2, "% 할인              ║")') &
                min(40, (pc%skill_points / 5) * 10)
        case(JOB_HOPPANG)
            write(*, '("  ║ PASSIVE[철벽]: DEF +", I3, "                          ║")') &
                (pc%skill_points / 3) * 2
        case(JOB_MILK)
            write(*, '("  ║ PASSIVE[마력증폭]: MP 기본치 +", I3, "                ║")') &
                (pc%skill_points / 3) * 15
        case(JOB_JJABDAM)
            write(*, '("  ║ PASSIVE[그림자발걸음]: 급소율 +", I2, "%              ║")') &
                min(20, (pc%skill_points / 3))
        case(JOB_JISAY)
            write(*, '("  ║ PASSIVE[지배의기운]: 데미지 +", I2, "%               ║")') &
                min(30, (pc%skill_points / 5) * 3)
        end select
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
        write(*, '("  ║ Weapon :", A22, "  Armor:", A18, " ║")') &
            trim(pc%weapon%name), trim(pc%armor%name)
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
        if (pc%pet%active) then
            write(*, '("  ║ Pet:", A15, " HP:", I3, "/", I3, " Lv:", I2, " ATK:", I3, "      ║")') &
                trim(pc%pet%name), pc%pet%hp, pc%pet%max_hp, pc%pet%level, pc%pet%atk
        else
            write(*,'(A)')"  ║ Pet: (none)                                                    ║"
        end if
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
    end subroutine show_main_status_ui

    subroutine add_to_inventory(pc, iname, ival, itype, igrade, iprice)
        type(character_t), intent(inout) :: pc
        character(len=*), intent(in) :: iname
        integer, intent(in) :: ival, itype, igrade, iprice
        integer :: i
        do i = 1, INV_SIZE
            if (trim(pc%inventory(i)%name) == "---") then
                pc%inventory(i)%name  = iname
                pc%inventory(i)%value = ival
                pc%inventory(i)%itype = itype
                pc%inventory(i)%grade = igrade
                pc%inventory(i)%price = iprice
                pc%inventory(i)%count = 1
                pc%inv_count = pc%inv_count + 1
                return
            end if
        end do
        write(*,'(A)')"  [!] 인벤토리가 가득 찼습니다!"
    end subroutine add_to_inventory

    subroutine scene_shop(pc)
        type(character_t), intent(inout) :: pc
        integer :: choice, i, ig, widx, aidx, sell_idx, pot_choice
        integer :: shop_discount
        real :: rr
        character(len=30) :: iname
        integer :: ival, igrade, iprice, itype, idef

        do
            ! Compute MANY passive shop discount
            shop_discount = 0
            if (pc%job == JOB_MANY) shop_discount = min(40, (pc%skill_points / 5) * 10)

            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
            write(*,'(A)')"  ║        ⚔   V I L L A G E   S H O P   ⚔                          ║"
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
            write(*, '("  ║  보유 골드: ", I8, "G", T67, "║")') pc%gold
            if (shop_discount > 0) then
                write(*, '("  ║  상인의 직감: ", I2, "% 할인 적용 중", T67, "║")') shop_discount
            end if
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
            write(*,'(A)')"  ║                                                                  ║"
            write(*,'(A)')"  ║   (1) 아이템 뽑기   [ 100G ]  랜덤 등급 아이템 획득             ║"
            write(*,'(A)')"  ║   (2) 아이템 판매              보유 아이템을 골드로 환전         ║"
            write(*,'(A)')"  ║   (3) 아이템 강화   [ 200G ]  아이템 수치 강화                  ║"
            write(*,'(A)')"  ║   (4) 아이템 도감              모든 아이템 정보 열람             ║"
            write(*,'(A)')"  ║   (5) 나가기                                                     ║"
            write(*,'(A)')"  ║   (6) 포션 구매                                                  ║"
            write(*,'(A)')"  ║   (7) 아이템 합성  [ 같은 등급 2개 -> 상위 등급 1개 ]           ║"
            write(*,'(A)')"  ║   (8) 특별 재고   [ 지역 기반 한정 아이템 ]                     ║"
            write(*,'(A)')"  ║                                                                  ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
            call safe_read(choice)
            if (choice == 5) exit

            select case(choice)
            case(1)
                ! Apply MANY shop discount to gacha
                i = int(100.0 * (1.0 - real(shop_discount) / 100.0))
                if (i < 10) i = 10
                if (pc%gold < i) then
                    call show_dialogue_box("상점", "골드가 부족합니다.", "")
                    call wait_for_enter()
                    cycle
                end if
                pc%gold = pc%gold - i
                ! Determine grade
                call random_number(rr)
                if      (rr < 0.02) then; ig = GRADE_MYTHIC
                else if (rr < 0.10) then; ig = GRADE_LEGENDARY
                else if (rr < 0.25) then; ig = GRADE_EPIC
                else if (rr < 0.55) then; ig = GRADE_RARE
                else;                     ig = GRADE_COMMON
                end if
                ! Determine weapon or armor and index (30 items each)
                call random_number(rr)
                if (rr > 0.5) then
                    itype = TYPE_WEAPON
                    widx = (ig-1)*6 + 1
                    call random_number(rr)
                    widx = widx + mod(int(rr*100), 6)
                    if (widx > 30) widx = 30
                    call get_weapon_by_idx(widx, iname, ival, igrade, iprice)
                else
                    itype = TYPE_ARMOR
                    aidx = (ig-1)*6 + 1
                    call random_number(rr)
                    aidx = aidx + mod(int(rr*100), 6)
                    if (aidx > 30) aidx = 30
                    call get_armor_by_idx(aidx, iname, ival, idef, igrade, iprice)
                end if
                ! Gacha animation
                call clear_screen()
                write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
                write(*,'(A)')"  ║           ✦  아이템 뽑기  ✦                          ║"
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║   [ 운명의 뽑기함이 회전하고 있습니다... ]           ║"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║               ?????                                  ║"
                write(*,'(A)')"  ║             /       \                                ║"
                write(*,'(A)')"  ║            | [ ??? ] |                               ║"
                write(*,'(A)')"  ║             \_______/                                ║"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
                call delay(0.7)
                call clear_screen()
                write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
                write(*,'(A)')"  ║           ✦  아이템 뽑기  ✦                          ║"
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║        두 근 - 두 근 - 두 근 - 두 근...              ║"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║               #####                                  ║"
                write(*,'(A)')"  ║             / # # # \                                ║"
                write(*,'(A)')"  ║            | [#####] |                               ║"
                write(*,'(A)')"  ║             \_______/                                ║"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
                call delay(0.7)
                call clear_screen()
                write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
                write(*,'(A)')"  ║           ✦  아이템 뽑기  ✦                          ║"
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║           !!! 등 급 결 정 중 !!!                     ║"
                write(*,'(A)')"  ║                                                      ║"
                write(*,'(A)')"  ║          ~~~ * ~~~ * ~~~ * ~~~ * ~~~                ║"
                write(*,'(A)')"  ║         *                             *              ║"
                write(*,'(A)')"  ║         *       [ GRADE... ]          *              ║"
                write(*,'(A)')"  ║         *                             *              ║"
                write(*,'(A)')"  ║          ~~~ * ~~~ * ~~~ * ~~~ * ~~~                ║"
                write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
                call delay(0.8)
                ! Grade reveal
                call clear_screen()
                write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
                select case(ig)
                case(GRADE_MYTHIC)
                    write(*,'(A)')"  ║  !!! S S S R !!!  신 화 !!!  운명이 선택했다!!!     ║"
                    write(*,'(A)')"  ║  * * * MYTHIC GRADE * * *                          ║"
                case(GRADE_LEGENDARY)
                    write(*,'(A)')"  ║  !! 전 설 등 급 !!  LEGENDARY !!                   ║"
                    write(*,'(A)')"  ║  ** 전설이 깨어났다! 강력한 힘이 느껴진다! **      ║"
                case(GRADE_EPIC)
                    write(*,'(A)')"  ║  에 픽 등 급  EPIC !                                ║"
                    write(*,'(A)')"  ║  희귀한 힘이 담긴 아이템을 획득했다!               ║"
                case(GRADE_RARE)
                    write(*,'(A)')"  ║  희 귀 등 급  RARE                                  ║"
                    write(*,'(A)')"  ║  어느 정도 가치 있는 아이템이다.                    ║"
                case default
                    write(*,'(A)')"  ║  일 반 등 급  COMMON                                ║"
                    write(*,'(A)')"  ║  평범한 아이템이지만 쓸모가 있을 것이다.            ║"
                end select
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                write(*,'(A)')"  ║                                                      ║"
                call delay(0.6)
                if (itype == TYPE_WEAPON) then
                    call draw_weapon_art(widx)
                else
                    call draw_armor_art(aidx)
                end if
                write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                write(*, '("  아이템 이름  : ", A)') trim(iname)
                write(*, '("  등급         : ", A)') trim(grade_name(igrade))
                if (itype == TYPE_WEAPON) then
                    write(*, '("  종류: 무기  공격력 +", I4)') ival
                else
                    write(*, '("  종류: 방어구  HP +", I4)') ival
                end if
                write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
                call add_to_inventory(pc, iname, ival, itype, igrade, iprice)
                call wait_for_enter()

            case(2)
                call show_inventory_box(pc)
                if (pc%inv_count == 0) cycle
                call show_dialogue_box("판매", "판매할 아이템 번호를 입력하세요. (0: 취소)", "")
                call safe_read(sell_idx)
                if (sell_idx == 0) cycle
                if (sell_idx >= 1 .and. sell_idx <= INV_SIZE) then
                    if (trim(pc%inventory(sell_idx)%name) /= "---") then
                        pc%gold = pc%gold + pc%inventory(sell_idx)%price / 2
                        write(*, '("  [+] ", A, " 판매 완료! +", I5, "G")') &
                            trim(pc%inventory(sell_idx)%name), pc%inventory(sell_idx)%price / 2
                        pc%inventory(sell_idx)%name  = "---"
                        pc%inventory(sell_idx)%itype = 0
                        pc%inventory(sell_idx)%value = 0
                        pc%inventory(sell_idx)%grade = 0
                        pc%inventory(sell_idx)%price = 0
                        pc%inv_count = pc%inv_count - 1
                        call wait_for_enter()
                    end if
                end if

            case(3)
                if (pc%gold < 200) then
                    call show_dialogue_box("강화", "골드가 부족합니다. (필요: 200G)", "")
                    call wait_for_enter()
                    cycle
                end if
                call show_inventory_box(pc)
                if (pc%inv_count == 0) cycle
                call show_dialogue_box("강화", "강화할 아이템 번호를 입력하세요. (0: 취소)", "")
                call safe_read(sell_idx)
                if (sell_idx == 0) cycle
                if (sell_idx >= 1 .and. sell_idx <= INV_SIZE) then
                    if (trim(pc%inventory(sell_idx)%name) /= "---") then
                        pc%gold = pc%gold - 200
                        pc%inventory(sell_idx)%value = pc%inventory(sell_idx)%value + 10
                        write(*, '("  [+] ", A, " 강화 완료! 수치 +10")') &
                            trim(pc%inventory(sell_idx)%name)
                        call wait_for_enter()
                    end if
                end if

            case(4)
                call scene_encyclopedia(pc)

            case(6)
                do
                    call clear_screen()
                    ! Compute discounted prices for potions
                    ig = int(50.0 * (1.0 - real(shop_discount) / 100.0))
                    if (ig < 5) ig = 5
                    idef = int(40.0 * (1.0 - real(shop_discount) / 100.0))
                    if (idef < 4) idef = 4
                    ival = int(30.0 * (1.0 - real(shop_discount) / 100.0))
                    if (ival < 3) ival = 3
                    write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
                    write(*,'(A)')"  ║              포션 구매                               ║"
                    write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
                    write(*, '("  ║  보유 골드: ", I8, "G", T55, "║")') pc%gold
                    write(*, '("  ║  (1) HP 포션  ", I3, "G - HP +80   현재: ", I3, "개", T55, "║")') ig, pc%hp_potions
                    write(*, '("  ║  (2) MP 포션  ", I3, "G - MP +60   현재: ", I3, "개", T55, "║")') idef, pc%mp_potions
                    write(*, '("  ║  (3) 펫 포션  ", I3, "G - 펫HP+40 (즉시 적용)", T55, "║")') ival
                    write(*,'(A)')"  ║  (4) 해독제      50G  (독 상태 치료)                ║"
                    write(*,'(A)')"  ║  (5) 각성제      50G  (수면 상태 치료)              ║"
                    write(*,'(A)')"  ║  (6) 화상치료제  50G  (화상 상태 치료)              ║"
                    write(*,'(A)')"  ║  (7) 만능치료제 150G  (모든 상태이상 치료)          ║"
                    write(*,'(A)')"  ║  (0) 나가기                                          ║"
                    write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
                    call safe_read(pot_choice)
                    if (pot_choice == 0) exit
                    select case(pot_choice)
                    case(1)
                        if (pc%gold >= ig) then
                            pc%gold = pc%gold - ig
                            pc%hp_potions = pc%hp_potions + 1
                            write(*,'(A)')"  [+] HP 포션 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(2)
                        if (pc%gold >= idef) then
                            pc%gold = pc%gold - idef
                            pc%mp_potions = pc%mp_potions + 1
                            write(*,'(A)')"  [+] MP 포션 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(3)
                        if (pc%gold >= ival) then
                            pc%gold = pc%gold - ival
                            if (pc%pet%active) then
                                pc%pet%hp = min(pc%pet%hp + 40, pc%pet%max_hp)
                                write(*,'(A)')"  [+] 펫 HP 회복!"
                            else
                                write(*,'(A)')"  [!] 활성화된 펫이 없습니다."
                            end if
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(4)
                        if (pc%gold >= 50) then
                            pc%gold = pc%gold - 50
                            call add_to_inventory(pc, "해독제", 1, TYPE_ITEM, GRADE_COMMON, 50)
                            write(*,'(A)')"  [+] 해독제 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(5)
                        if (pc%gold >= 50) then
                            pc%gold = pc%gold - 50
                            call add_to_inventory(pc, "각성제", 1, TYPE_ITEM, GRADE_COMMON, 50)
                            write(*,'(A)')"  [+] 각성제 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(6)
                        if (pc%gold >= 50) then
                            pc%gold = pc%gold - 50
                            call add_to_inventory(pc, "화상치료제", 1, TYPE_ITEM, GRADE_COMMON, 50)
                            write(*,'(A)')"  [+] 화상치료제 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    case(7)
                        if (pc%gold >= 150) then
                            pc%gold = pc%gold - 150
                            call add_to_inventory(pc, "만능치료제", 1, TYPE_ITEM, GRADE_RARE, 150)
                            write(*,'(A)')"  [+] 만능치료제 구매!"
                            call wait_for_enter()
                        else
                            write(*,'(A)')"  [!] 골드 부족!"
                            call wait_for_enter()
                        end if
                    end select
                end do
            case(7)
                call scene_crafting(pc)
            case(8)
                call scene_special_stock(pc)
            end select
        end do
    end subroutine scene_shop

    subroutine scene_encyclopedia(pc)
        type(character_t), intent(inout) :: pc
        integer :: i, ival, ig, ip, idef, choice
        character(len=30) :: iname

        do
            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
            write(*,'(A)')"  ║                  ✦  아이템  도감  ✦                               ║"
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
            write(*, '("  ║  몬스터 처치 진행: ", I2, "/24", T67, "║")') sum(pc%mon_seen)
            write(*,'(A)')"  ║  (1) 무기 도감   (2) 방어구 도감   (3) 나가기                    ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
            call safe_read(choice)
            if (choice == 3) exit

            if (choice == 1 .or. choice == 2) then
                do i = 1, 10
                    call clear_screen()
                    if (choice == 1) then
                        call get_weapon_by_idx(i, iname, ival, ig, ip)
                        write(*,'(A)')"  ╔══════════════════════════════════════════════════╗"
                        write(*, '("  ║   [무기 도감] ", I2, "/10", T51, "║")') i
                        write(*,'(A)')"  ╠══════════════════════════════════════════════════╣"
                        write(*, '("  ║  이름  : ", A30, T51, "║")') trim(iname)
                        write(*, '("  ║  공격력: +", I4, T51, "║")') ival
                        write(*, '("  ║  등급  : ", A10, T51, "║")') trim(grade_name(ig))
                        write(*, '("  ║  가격  : ", I6, "G", T51, "║")') ip
                        write(*,'(A)')"  ╠══════════════════════════════════════════════════╣"
                        print *, ""
                        call draw_weapon_art(i)
                        print *, ""
                        write(*,'(A)')"  ╚══════════════════════════════════════════════════╝"
                    else
                        call get_armor_by_idx(i, iname, ival, idef, ig, ip)
                        write(*,'(A)')"  ╔══════════════════════════════════════════════════╗"
                        write(*, '("  ║   [방어구 도감] ", I2, "/10", T51, "║")') i
                        write(*,'(A)')"  ╠══════════════════════════════════════════════════╣"
                        write(*, '("  ║  이름  : ", A30, T51, "║")') trim(iname)
                        write(*, '("  ║  HP보너스: +", I4, T51, "║")') ival
                        write(*, '("  ║  방어력: +", I4, T51, "║")') idef
                        write(*, '("  ║  등급  : ", A10, T51, "║")') trim(grade_name(ig))
                        write(*, '("  ║  가격  : ", I6, "G", T51, "║")') ip
                        write(*,'(A)')"  ╠══════════════════════════════════════════════════╣"
                        print *, ""
                        call draw_armor_art(i)
                        print *, ""
                        write(*,'(A)')"  ╚══════════════════════════════════════════════════╝"
                    end if
                    call wait_for_enter()
                end do
            end if
        end do
    end subroutine scene_encyclopedia

    subroutine show_inventory_box(pc)
        type(character_t), intent(inout) :: pc
        integer :: i, slot_choice, eq_choice, filter_choice
        character(len=8) :: tname
        ! temp storage for swap
        character(len=30) :: tmp_name
        integer :: tmp_itype, tmp_value, tmp_grade, tmp_price
        logical :: show_item

        filter_choice = 3  ! default: show all

        do
            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
            write(*,'(A)')"  ║                ✦   I N V E N T O R Y   ✦                         ║"
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
            write(*,'(A)')"  ║  필터: (1) 무기만   (2) 방어구만   (3) 전체보기   (0) 나가기    ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
            call safe_read(filter_choice)
            if (filter_choice == 0) return
            if (filter_choice < 1 .or. filter_choice > 3) filter_choice = 3

            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
            if (filter_choice == 1) then
                write(*,'(A)')"  ║                ✦  INVENTORY  [ 무기 ]  ✦                         ║"
            else if (filter_choice == 2) then
                write(*,'(A)')"  ║                ✦  INVENTORY  [ 방어구 ]  ✦                        ║"
            else
                write(*,'(A)')"  ║                ✦   I N V E N T O R Y   ✦                         ║"
            end if
            write(*,'(A)')"  ╠══╦══════════════════════════╦═══════╦═════════╦══════╦══════════╣"
            write(*,'(A)')"  ║# ║ 이름                     ║ 종류  ║  등급   ║  수치║   가격   ║"
            write(*,'(A)')"  ╠══╬══════════════════════════╬═══════╬═════════╬══════╬══════════╣"
            do i = 1, INV_SIZE
                if (trim(pc%inventory(i)%name) == "---") then
                    if (filter_choice == 3) then
                        write(*, '("  ║", I2, "║ ( 비어 있음 )", T27, "║       ║         ║      ║          ║")') i
                    end if
                else
                    show_item = .false.
                    if (filter_choice == 3) show_item = .true.
                    if (filter_choice == 1 .and. pc%inventory(i)%itype == TYPE_WEAPON) show_item = .true.
                    if (filter_choice == 2 .and. pc%inventory(i)%itype == TYPE_ARMOR)  show_item = .true.
                    if (show_item) then
                        if (pc%inventory(i)%itype == TYPE_WEAPON) then
                            tname = "무기"
                        else if (pc%inventory(i)%itype == TYPE_ARMOR) then
                            tname = "방어구"
                        else
                            tname = "기타"
                        end if
                        write(*, '("  ║", I2, "║ ", A24, " ║ ", A5, " ║ ", A7, " ║", I4, "  ║", I6, "G   ║")') &
                            i, trim(pc%inventory(i)%name), trim(tname), &
                            trim(grade_name(pc%inventory(i)%grade)), &
                            pc%inventory(i)%value, pc%inventory(i)%price
                    end if
                end if
            end do
            write(*,'(A)')"  ╠══╩══════════════════════════╩═══════╩═════════╩══════╩══════════╣"
            write(*, '("  ║  장착 무기 : ", A20)') trim(pc%weapon%name)
            write(*, '("  ║  장착 방어구: ", A20)') trim(pc%armor%name)
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
            write(*,'(A)')"  ║  (번호) 아이템 장착    (0) 필터 변경                            ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
            call safe_read(slot_choice)
            if (slot_choice == 0) cycle  ! go back to filter selection
            if (slot_choice < 1 .or. slot_choice > INV_SIZE) cycle
            if (trim(pc%inventory(slot_choice)%name) == "---") then
                write(*,'(A)')"  [!] 비어 있는 슬롯입니다."
                call wait_for_enter()
                cycle
            end if

            if (pc%inventory(slot_choice)%itype == TYPE_WEAPON) then
                write(*,'(A)')"  장착하시겠습니까? (1) 예  (2) 아니오"
                call safe_read(eq_choice)
                if (eq_choice == 1) then
                    ! Save inventory item info first
                    tmp_name  = pc%inventory(slot_choice)%name
                    tmp_value = pc%inventory(slot_choice)%value
                    tmp_grade = pc%inventory(slot_choice)%grade
                    tmp_price = pc%inventory(slot_choice)%price
                    ! Put old weapon into that slot
                    pc%inventory(slot_choice)%name  = pc%weapon%name
                    pc%inventory(slot_choice)%itype = TYPE_WEAPON
                    pc%inventory(slot_choice)%value = pc%weapon%atk
                    pc%inventory(slot_choice)%grade = pc%weapon%grade
                    pc%inventory(slot_choice)%price = pc%weapon%price
                    pc%inventory(slot_choice)%count = 1
                    ! Equip new weapon
                    pc%weapon%name  = tmp_name
                    pc%weapon%atk   = tmp_value
                    pc%weapon%grade = tmp_grade
                    pc%weapon%price = tmp_price
                    write(*,'(A)')"  [+] 무기 장착 완료!"
                    call wait_for_enter()
                end if

            else if (pc%inventory(slot_choice)%itype == TYPE_ARMOR) then
                write(*,'(A)')"  장착하시겠습니까? (1) 예  (2) 아니오"
                call safe_read(eq_choice)
                if (eq_choice == 1) then
                    ! Save inventory item info first
                    tmp_name  = pc%inventory(slot_choice)%name
                    tmp_value = pc%inventory(slot_choice)%value  ! hp_bonus
                    tmp_grade = pc%inventory(slot_choice)%grade
                    tmp_price = pc%inventory(slot_choice)%price
                    ! Remove old armor hp_bonus
                    pc%max_hp = pc%max_hp - pc%armor%hp_bonus
                    ! Put old armor into slot
                    pc%inventory(slot_choice)%name  = pc%armor%name
                    pc%inventory(slot_choice)%itype = TYPE_ARMOR
                    pc%inventory(slot_choice)%value = pc%armor%hp_bonus
                    pc%inventory(slot_choice)%grade = pc%armor%grade
                    pc%inventory(slot_choice)%price = pc%armor%price
                    pc%inventory(slot_choice)%count = 1
                    ! Equip new armor: def = value/3 estimate
                    pc%armor%name     = tmp_name
                    pc%armor%hp_bonus = tmp_value
                    pc%armor%def      = tmp_value / 3
                    pc%armor%grade    = tmp_grade
                    pc%armor%price    = tmp_price
                    ! Add new armor hp_bonus
                    pc%max_hp = pc%max_hp + pc%armor%hp_bonus
                    pc%hp = min(pc%hp, pc%max_hp)
                    write(*,'(A)')"  [+] 방어구 장착 완료!"
                    call wait_for_enter()
                end if

            else
                write(*,'(A)')"  [!] 장착할 수 없는 아이템입니다."
                call wait_for_enter()
            end if
        end do
    end subroutine show_inventory_box

    subroutine save_game(pc)
        type(character_t), intent(in) :: pc
        integer :: i
        open(10, file="save_data.txt", status='replace')
        write(10, '(A)') trim(pc%name)
        write(10, *) pc%job, pc%level, pc%xp, pc%next_xp
        write(10, *) pc%hp, pc%max_hp, pc%gold, pc%base_atk, pc%evasion, pc%hp_potions
        write(10, *) pc%current_region, pc%current_stage, pc%unlocked_region, pc%inn_usage
        write(10, '(A)') trim(pc%weapon%name)
        write(10, *) pc%weapon%atk, pc%weapon%grade, pc%weapon%price
        write(10, '(A)') trim(pc%armor%name)
        write(10, *) pc%armor%hp_bonus, pc%armor%def, pc%armor%grade, pc%armor%price
        write(10, *) pc%inv_count
        do i = 1, INV_SIZE
            write(10, '(A)') trim(pc%inventory(i)%name)
            write(10, *) pc%inventory(i)%itype, pc%inventory(i)%value, &
                         pc%inventory(i)%grade, pc%inventory(i)%price, pc%inventory(i)%count
        end do
        write(10, *) pc%element, pc%mp, pc%max_mp, pc%skill_points, pc%mp_potions
        write(10, '(A)') trim(pc%pet%name)
        write(10, *) pc%pet%element, pc%pet%level, pc%pet%hp, pc%pet%max_hp, &
                     pc%pet%atk, pc%pet%xp, pc%pet%next_xp
        write(10, *) pc%pet%active
        do i = 1, 6
            write(10, '(A)') trim(pc%skills(i)%name)
            write(10, *) pc%skills(i)%slevel, pc%skills(i)%mp_cost, pc%skills(i)%req_level, &
                         pc%skills(i)%element, pc%skills(i)%dmg_mult
            write(10, *) pc%skills(i)%unlocked, pc%skills(i)%equipped
        end do
        write(10, *) pc%base_def, pc%speed, pc%status, pc%status_turns
        write(10, *) pc%ng_plus
        write(10, *) pc%mon_seen
        close(10)
        write(*,'(A)')"  [저장 완료] 게임이 저장되었습니다."
    end subroutine save_game

    subroutine load_game(pc, success)
        type(character_t), intent(out) :: pc
        logical, intent(out) :: success
        logical :: exists
        integer :: i, ios
        inquire(file="save_data.txt", exist=exists)
        if (.not. exists) then
            success = .false.; return
        end if
        open(10, file="save_data.txt", iostat=ios)
        if (ios /= 0) then; success = .false.; return; end if
        read(10, '(A)') pc%name
        read(10, *) pc%job, pc%level, pc%xp, pc%next_xp
        read(10, *) pc%hp, pc%max_hp, pc%gold, pc%base_atk, pc%evasion, pc%hp_potions
        read(10, *) pc%current_region, pc%current_stage, pc%unlocked_region, pc%inn_usage
        read(10, '(A)') pc%weapon%name
        read(10, *) pc%weapon%atk, pc%weapon%grade, pc%weapon%price
        read(10, '(A)') pc%armor%name
        read(10, *) pc%armor%hp_bonus, pc%armor%def, pc%armor%grade, pc%armor%price
        read(10, *) pc%inv_count
        do i = 1, INV_SIZE
            read(10, '(A)') pc%inventory(i)%name
            read(10, *) pc%inventory(i)%itype, pc%inventory(i)%value, &
                        pc%inventory(i)%grade, pc%inventory(i)%price, pc%inventory(i)%count
        end do
        read(10, *) pc%element, pc%mp, pc%max_mp, pc%skill_points, pc%mp_potions
        read(10, '(A)') pc%pet%name
        read(10, *) pc%pet%element, pc%pet%level, pc%pet%hp, pc%pet%max_hp, &
                    pc%pet%atk, pc%pet%xp, pc%pet%next_xp
        read(10, *) pc%pet%active
        do i = 1, 6
            read(10, '(A)') pc%skills(i)%name
            read(10, *) pc%skills(i)%slevel, pc%skills(i)%mp_cost, pc%skills(i)%req_level, &
                        pc%skills(i)%element, pc%skills(i)%dmg_mult
            read(10, *) pc%skills(i)%unlocked, pc%skills(i)%equipped
        end do
        read(10, *, iostat=ios) pc%base_def, pc%speed, pc%status, pc%status_turns
        if (ios /= 0) then
            pc%base_def = 5; pc%speed = 10
            pc%status = STATUS_NORMAL; pc%status_turns = 0
        end if
        read(10, *, iostat=ios) pc%ng_plus
        if (ios /= 0) pc%ng_plus = 0
        read(10, *, iostat=ios) pc%mon_seen
        if (ios /= 0) pc%mon_seen = 0
        close(10)
        success = .true.
    end subroutine load_game

    subroutine check_level_up(pc)
        type(character_t), intent(inout) :: pc
        do while (pc%xp >= pc%next_xp)
            pc%level    = pc%level + 1
            pc%xp       = pc%xp - pc%next_xp
            pc%next_xp  = int(pc%next_xp * 1.3) + 80
            select case(pc%job)
            case(JOB_MANY)
                pc%base_atk=pc%base_atk+6;  pc%max_hp=pc%max_hp+18
                pc%base_def=pc%base_def+3;  pc%speed=pc%speed+2
            case(JOB_HOPPANG)
                pc%base_atk=pc%base_atk+4;  pc%max_hp=pc%max_hp+30
                pc%base_def=pc%base_def+5;  pc%speed=pc%speed+1
            case(JOB_MILK)
                pc%base_atk=pc%base_atk+10; pc%max_hp=pc%max_hp+10
                pc%base_def=pc%base_def+1;  pc%speed=pc%speed+3
            case(JOB_JJABDAM)
                pc%base_atk=pc%base_atk+7;  pc%max_hp=pc%max_hp+12
                pc%evasion=min(45, pc%evasion+1)
                pc%base_def=pc%base_def+2;  pc%speed=pc%speed+5
            case(JOB_JISAY)
                pc%base_atk=pc%base_atk+12; pc%max_hp=pc%max_hp+35
                pc%base_def=pc%base_def+6;  pc%speed=pc%speed+3
            end select
            pc%hp = pc%max_hp
            pc%skill_points = pc%skill_points + 1
            if (pc%level == 5)  pc%skills(2)%unlocked = .true.
            if (pc%level == 10) pc%skills(3)%unlocked = .true.
            if (pc%level == 15) pc%skills(4)%unlocked = .true.
            if (pc%level == 20) pc%skills(5)%unlocked = .true.
            if (pc%level == 25) pc%skills(6)%unlocked = .true.
            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
            write(*,'(A)')"  ║       ★  L E V E L   U P !  ★                       ║"
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
            write(*, '("  ║  레벨 ", I3, " -> ", I3, T54, "║")') pc%level-1, pc%level
            write(*, '("  ║  ATK/DEF/SPD/MaxHP 성장  HP 전부 회복!         ║")')
            write(*, '("  ║  DEF: ", I3, "  SPD: ", I3, "  스킬PT:", I3, T54, "║")') &
                pc%base_def+pc%armor%def, pc%speed, pc%skill_points
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
            call wait_for_enter()
        end do
    end subroutine check_level_up

    subroutine hp_bar(hp, max_hp, bar)
        integer, intent(in) :: hp, max_hp
        character(len=20), intent(out) :: bar
        integer :: filled, i
        bar = "                    "
        if (max_hp <= 0) return
        filled = max(0, min(20, (hp * 20) / max_hp))
        do i = 1, 20
            if (i <= filled) then; bar(i:i) = '#'
            else;                  bar(i:i) = '-'
            end if
        end do
    end subroutine hp_bar

    subroutine get_monster_data(region, stage, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, ng_plus)
        integer, intent(in)  :: region, stage
        character(len=30), intent(out) :: e_name
        integer, intent(out) :: m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed
        logical, intent(out) :: is_boss
        integer, intent(in), optional :: ng_plus
        integer :: tier, var
        tier = (region - 1) / 4 + 1
        var  = mod(stage, 3)
        is_boss = (mod(stage, 5) == 0)

        if (is_boss) then
            mon_id = tier * 4
            select case(tier)
            case(1); e_name = "그롬울프 왕"; mon_element = ELEM_EARTH
            case(2); e_name = "네레우스"; mon_element = ELEM_WATER
            case(3); e_name = "모르타넥"; mon_element = ELEM_FIRE
            case(4); e_name = "젠파이어"; mon_element = ELEM_AIR
            case(5); e_name = "말가론"; mon_element = ELEM_ETHER
            case default; e_name = "카오스군주"; mon_id = 24; mon_element = ELEM_ETHER
            end select
            m_max_hp = 80 + tier*40 + stage*8
            m_atk    = 12 + tier*6 + stage*2
            m_xp     = 80 + tier*30 + stage*5
            m_gold   = 100 + tier*40 + stage*8
            m_def    = 3 + tier*5
            mon_speed= 6 + tier*3
        else
            select case(tier)
            case(1)
                mon_element = ELEM_EARTH
                if(var==1) then; e_name="그롬울프";    mon_id=1
                else if(var==2) then; e_name="트리링"; mon_id=2
                else;                 e_name="스핀도적"; mon_id=3
                end if
            case(2)
                mon_element = ELEM_WATER
                if(var==1) then; e_name="크랩토스";     mon_id=5
                else if(var==2) then; e_name="레이브해적"; mon_id=6
                else;                 e_name="하이드라새끼"; mon_id=7
                end if
            case(3)
                mon_element = ELEM_FIRE
                if(var==1) then; e_name="스켈레탄";    mon_id=9
                else if(var==2) then; e_name="스콜피온"; mon_id=10
                else;                 e_name="반시";    mon_id=11
                end if
            case(4)
                mon_element = ELEM_AIR
                if(var==1) then; e_name="픽시블레이드"; mon_id=13
                else if(var==2) then; e_name="아이언골렘"; mon_id=14
                else;                 e_name="실프전사";  mon_id=15
                end if
            case(5)
                mon_element = ELEM_ETHER
                if(var==1) then; e_name="그림나이트";  mon_id=17
                else if(var==2) then; e_name="레이스";  mon_id=18
                else;                 e_name="보이드데몬"; mon_id=19
                end if
            case default
                mon_element = ELEM_ETHER
                if(var==1) then; e_name="심연가디언";    mon_id=21
                else if(var==2) then; e_name="드라고닉"; mon_id=22
                else;                 e_name="미스틱스피릿"; mon_id=23
                end if
            end select
            m_max_hp = 25 + tier*15 + stage*5
            m_atk    = 4 + tier*3 + stage
            m_xp     = 20 + tier*10 + stage*3
            m_gold   = 15 + tier*8 + stage*2
            m_def    = 1 + tier*3
            mon_speed= 4 + tier*2
        end if
        ! Apply NG+ modifier
        if (present(ng_plus) .and. ng_plus > 0) then
            m_max_hp = int(m_max_hp * (1.0 + 0.2 * ng_plus))
            m_atk    = int(m_atk    * (1.0 + 0.2 * ng_plus))
            m_xp     = int(m_xp     * (1.0 + 0.1 * ng_plus))
            m_gold   = int(m_gold   * (1.0 + 0.1 * ng_plus))
        end if
    end subroutine get_monster_data

    subroutine get_player_art_equipped(wg, ag, anim, L)
        integer, intent(in) :: wg, ag, anim
        character(len=30), intent(out) :: L(7)
        ! ag: 1=천, 2=가죽, 3=사슬, 4=전설, 5=신화
        ! anim=0 대기
        if (anim == 0) then
            select case(ag)
            case(1) ! cloth
                L(1)="      (o) (o)          "
                L(2)="     /~~~~~\           "
                L(3)="     | clth|           "
                L(4)="     \~~~~~/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(2) ! leather
                L(1)="      (o) (o)          "
                L(2)="     /[---]\           "
                L(3)="     |LTHR |           "
                L(4)="     \[---]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(3) ! chain
                L(1)="      (o) (o)          "
                L(2)="     /[###]\           "
                L(3)="     |CHAIN|           "
                L(4)="     \[###]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(4) ! legendary
                L(1)="    **(o) (o)**        "
                L(2)="     /[***]\           "
                L(3)="     |LGND |           "
                L(4)="     \[***]/           "
                L(5)="      *|   |*          "
                L(6)="     *_|   |_*         "
                L(7)="                       "
            case default ! mythic ag>=5
                L(1)="  ****(o) (o)****      "
                L(2)="     /[###]\           "
                L(3)="     |MYTH |           "
                L(4)="     \[###]/           "
                L(5)="    **|   |**          "
                L(6)="   **_|   |_**         "
                L(7)="                       "
            end select
        ! anim=1 공격
        else if (anim == 1) then
            select case(ag)
            case(1)
                L(1)="      (O) (O)>>        "
                select case(wg)
                case(1); L(2)="     /~~~~~\--->      "
                case(2); L(2)="     /~~~~~\===>      "
                case(3); L(2)="     /~~~~~\===>>     "
                case(4); L(2)="     /~~~~~\***>>     "
                case default; L(2)="     /~~~~~\###>>>   "
                end select
                L(3)="     |SLASH|           "
                L(4)="     \~~~~~/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(2)
                L(1)="      (O) (O)>>        "
                select case(wg)
                case(1); L(2)="     /[---]\--->      "
                case(2); L(2)="     /[---]\===>      "
                case(3); L(2)="     /[---]\===>>     "
                case(4); L(2)="     /[---]\***>>     "
                case default; L(2)="     /[---]\###>>>   "
                end select
                L(3)="     |SLASH|           "
                L(4)="     \[---]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(3)
                L(1)="      (O) (O)>>        "
                select case(wg)
                case(1); L(2)="     /[###]\--->      "
                case(2); L(2)="     /[###]\===>      "
                case(3); L(2)="     /[###]\===>>     "
                case(4); L(2)="     /[###]\***>>     "
                case default; L(2)="     /[###]\###>>>   "
                end select
                L(3)="     |SLASH|           "
                L(4)="     \[###]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(4)
                L(1)="    **(O) (O)**>>      "
                select case(wg)
                case(1); L(2)="     /[***]\--->      "
                case(2); L(2)="     /[***]\===>      "
                case(3); L(2)="     /[***]\===>>     "
                case(4); L(2)="     /[***]\***>>     "
                case default; L(2)="     /[***]\###>>>   "
                end select
                L(3)="     |LGND!|           "
                L(4)="     \[***]/           "
                L(5)="      *|   |*          "
                L(6)="     *_|   |_*         "
                L(7)="                       "
            case default
                L(1)="  ****(O) (O)****>>    "
                select case(wg)
                case(1); L(2)="     /[###]\--->      "
                case(2); L(2)="     /[###]\===>      "
                case(3); L(2)="     /[###]\===>>     "
                case(4); L(2)="     /[###]\***>>     "
                case default; L(2)="     /[###]\###>>>   "
                end select
                L(3)="     |MYTH!|           "
                L(4)="     \[###]/           "
                L(5)="    **|   |**          "
                L(6)="   **_|   |_**         "
                L(7)="                       "
            end select
        ! anim=2 피격
        else
            select case(ag)
            case(1)
                L(1)="      (*) (*)  !!      "
                L(2)="     /~~~~~\!!         "
                L(3)="     |!!HIT|           "
                L(4)="     \~~~~~/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(2)
                L(1)="      (*) (*)  !!      "
                L(2)="     /[---]\!!         "
                L(3)="     |!!HIT|           "
                L(4)="     \[---]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(3)
                L(1)="      (*) (*)  !!      "
                L(2)="     /[###]\!!         "
                L(3)="     |!!HIT|           "
                L(4)="     \[###]/           "
                L(5)="       |   |           "
                L(6)="      _|   |_          "
                L(7)="                       "
            case(4)
                L(1)="    *(*) (*)!!**       "
                L(2)="     /[***]\!!         "
                L(3)="     |!!HIT|           "
                L(4)="     \[***]/           "
                L(5)="      *|   |*          "
                L(6)="     *_|   |_*         "
                L(7)="                       "
            case default
                L(1)="  ****(*) (*)!!****    "
                L(2)="     /[###]\!!         "
                L(3)="     |!!HIT|           "
                L(4)="     \[###]/           "
                L(5)="    **|   |**          "
                L(6)="   **_|   |_**         "
                L(7)="                       "
            end select
        end if
    end subroutine get_player_art_equipped

    ! ─────────────────────────────────────────────────────────────
    !  몬스터 아트 (mon_id 1~24, anim: 0=대기, 1=피격, 2=공격)
    ! ─────────────────────────────────────────────────────────────
    subroutine get_monster_art_unique(mon_id, anim, L)
        integer, intent(in) :: mon_id, anim
        character(len=26), intent(out) :: L(7)
        select case(mon_id)
        ! ── 1: 숲 늑대 (wolf quadruped) ──
        case(1)
            if (anim == 0) then
                L(1)="   __  __             "
                L(2)="  /  \/  \            "
                L(3)=" |(o)  (o)|  WOLF     "
                L(4)="  \  /\/  /           "
                L(5)="  /\/    \/\          "
                L(6)=" /  LLLLLL  \         "
                L(7)="            "
            else if (anim == 1) then
                L(1)="   __  __             "
                L(2)="  /  \/  \  !!        "
                L(3)=" |(X)  (X)|  HIT!!    "
                L(4)="  \  /\/  /           "
                L(5)="  /\/    \/\          "
                L(6)=" /  LLLLLL  \         "
                L(7)="            "
            else
                L(1)="   __  __             "
                L(2)="  /  \/  \            "
                L(3)=" |(>) (>)| GRRRR!     "
                L(4)="  \  /\/  /  -->      "
                L(5)="  /\/    \/\          "
                L(6)=" /  LLLLLL  \         "
                L(7)="            "
            end if
        ! ── 2: 나무 고블린 (tree goblin) ──
        case(2)
            if (anim == 0) then
                L(1)="     {^}              "
                L(2)="   /{o o}\            "
                L(3)="  | GOBLN |           "
                L(4)="  |  ___  |           "
                L(5)="   \_____/            "
                L(6)="   /| _ |\            "
                L(7)="            "
            else if (anim == 1) then
                L(1)="     {^}   !!         "
                L(2)="   /{X X}\  !!        "
                L(3)="  | !!HIT |           "
                L(4)="  |  ***  |           "
                L(5)="   \_____/            "
                L(6)="   /| _ |\            "
                L(7)="            "
            else
                L(1)="     {^}              "
                L(2)="   /{> <}\            "
                L(3)="  |ATTACK!|  -->      "
                L(4)="  |  _^_  |           "
                L(5)="   \_____/            "
                L(6)="   /| _ |\            "
                L(7)="            "
            end if
        ! ── 3: 가시 도적 (hooded bandit) ──
        case(3)
            if (anim == 0) then
                L(1)="    _____             "
                L(2)="   /o   o\            "
                L(3)="  | BANDIT|           "
                L(4)="  |  ~~~  |           "
                L(5)="   \_____/            "
                L(6)="   /     \            "
                L(7)="            "
            else if (anim == 1) then
                L(1)="    _____  !!         "
                L(2)="   /X   X\  !!        "
                L(3)="  |!!HIT!!|           "
                L(4)="  |  ***  |           "
                L(5)="   \_____/            "
                L(6)="   /     \            "
                L(7)="            "
            else
                L(1)="    _____             "
                L(2)="   /> _ <\            "
                L(3)="  |STAB!! |  -->      "
                L(4)="  |  ~~~  |           "
                L(5)="   \_____/            "
                L(6)="   /     \            "
                L(7)="            "
            end if
        ! ── 4: 숲의 왕 그린워프 (boss giant tree creature) ──
        case(4)
            if (anim == 0) then
                L(1)=" *{@@@@@@@}*          "
                L(2)="  /(O)  (O)\          "
                L(3)=" |  GRNWRP  |         "
                L(4)=" |  [||||]  |         "
                L(5)="  \       /           "
                L(6)="  /\ ___ /\           "
                L(7)=" /  |   |  \          "
            else if (anim == 1) then
                L(1)=" *{@@@@@@@}* !!       "
                L(2)="  /(X)  (X)\  !!      "
                L(3)=" |  !!HIT!!  |        "
                L(4)=" |  [*!!!*]  |        "
                L(5)="  \       /           "
                L(6)="  /\ ___ /\           "
                L(7)=" /  |   |  \          "
            else
                L(1)=" *{@@@@@@@}*          "
                L(2)="  /(>)  (<)\          "
                L(3)="<| ROAARRR! |         "
                L(4)="<| [SMASH!] |         "
                L(5)="  \       /           "
                L(6)="  /\ ___ /\           "
                L(7)=" /  |   |  \          "
            end if
        ! ── 5: 해안 게 (crab) ──
        case(5)
            if (anim == 0) then
                L(1)=" \  _____  /          "
                L(2)="--| (o)(o)|--         "
                L(3)="  |  CRAB |           "
                L(4)="--| [===] |--         "
                L(5)="  \_____/             "
                L(6)="  /| | | |\           "
                L(7)="            "
            else if (anim == 1) then
                L(1)=" \  _____  / !!       "
                L(2)="--| (X)(X)|-- !!      "
                L(3)="  | !!HIT |           "
                L(4)="--| [***] |--         "
                L(5)="  \_____/             "
                L(6)="  /| | | |\           "
                L(7)="            "
            else
                L(1)=" \  _____  /          "
                L(2)="--|(>) (<)|--  -->     "
                L(3)="  |SNIP!! |           "
                L(4)="--| [===] |--         "
                L(5)="  \_____/             "
                L(6)="  /| | | |\           "
                L(7)="            "
            end if
        ! ── 6: 난파선 해적 (pirate) ──
        case(6)
            if (anim == 0) then
                L(1)="    _____             "
                L(2)="   /(@)(@)\           "
                L(3)="  |PIRATE! |          "
                L(4)="  | [===]  |          "
                L(5)="   \_____/            "
                L(6)="   /|   |\            "
                L(7)="            "
            else if (anim == 1) then
                L(1)="    _____  !!         "
                L(2)="   /(X)(X)\  !!       "
                L(3)="  | !!HIT |           "
                L(4)="  | [***]  |          "
                L(5)="   \_____/            "
                L(6)="   /|   |\            "
                L(7)="            "
            else
                L(1)="    _____             "
                L(2)="   /(>)(<)\           "
                L(3)="  |SLASH!!|  -->      "
                L(4)="  | [===]  |          "
                L(5)="   \_____/            "
                L(6)="   /|   |\            "
                L(7)="            "
            end if
        ! ── 7: 늪지 독사 (snake/viper) ──
        case(7)
            if (anim == 0) then
                L(1)="   ___                "
                L(2)="  /o o\  ~SNAKE~      "
                L(3)=" | SSS  |             "
                L(4)="  \___S/              "
                L(5)="    SSS               "
                L(6)="     SS               "
                L(7)="            "
            else if (anim == 1) then
                L(1)="   ___   !!           "
                L(2)="  /X X\   !!  HIT!!   "
                L(3)=" | ***  |             "
                L(4)="  \___S/              "
                L(5)="    SSS               "
                L(6)="     SS               "
                L(7)="            "
            else
                L(1)="   ___                "
                L(2)="  /> <\  HISSS!       "
                L(3)=" |VENOM |  -->        "
                L(4)="  \___S/              "
                L(5)="    SSS               "
                L(6)="     SS               "
                L(7)="            "
            end if
        ! ── 8: 폭풍 해적단장 레드 (boss pirate captain) ──
        case(8)
            if (anim == 0) then
                L(1)=" ~~{RED}~~            "
                L(2)="  /(O) (O)\           "
                L(3)=" | CAPTAIN |          "
                L(4)=" | [SWORD] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /~|     |~\          "
            else if (anim == 1) then
                L(1)=" ~~{RED}~~ !!         "
                L(2)="  /(X) (X)\  !!       "
                L(3)=" | !!HIT!! |          "
                L(4)=" | [*!!!*] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /~|     |~\          "
            else
                L(1)=" ~~{RED}~~            "
                L(2)="  /(>) (<)\           "
                L(3)="<| STOORM! |          "
                L(4)="<| [BLADE] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /~|     |~\          "
            end if
        ! ── 9: 해골 전사 (skeleton) ──
        case(9)
            if (anim == 0) then
                L(1)="    _____             "
                L(2)="   /O   O\            "
                L(3)="  | SKULL |           "
                L(4)="  |  ___  |           "
                L(5)="   \_____/            "
                L(6)="   /| | |\            "
                L(7)="            "
            else if (anim == 1) then
                L(1)="    _____  !!         "
                L(2)="   /X   X\  !!        "
                L(3)="  |!!HIT!!|           "
                L(4)="  |  ***  |           "
                L(5)="   \_____/            "
                L(6)="   /| | |\            "
                L(7)="            "
            else
                L(1)="    _____             "
                L(2)="   /@ _ @\            "
                L(3)="  |RATLLE! |  -->     "
                L(4)="  |  ___  |           "
                L(5)="   \_____/            "
                L(6)="   /| | |\            "
                L(7)="            "
            end if
        ! ── 10: 사막 전갈 (scorpion) ──
        case(10)
            if (anim == 0) then
                L(1)="  /\     /\           "
                L(2)=" |(o)   (o)|          "
                L(3)=" |SCORPION |          "
                L(4)=" |_[===]_  |          "
                L(5)="  \___,_/             "
                L(6)="   |||||              "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  /\     /\ !!        "
                L(2)=" |(X)   (X)| !!       "
                L(3)=" | !!HIT!! |          "
                L(4)=" |_[***]_  |          "
                L(5)="  \___,_/             "
                L(6)="   |||||              "
                L(7)="            "
            else
                L(1)="  /\     /\           "
                L(2)=" |(>)   (<)|  -->     "
                L(3)=" | STING!! |          "
                L(4)=" |_[===]_  |          "
                L(5)="  \___,_/             "
                L(6)="   |||||              "
                L(7)="            "
            end if
        ! ── 11: 고대 유령 (ghost) ──
        case(11)
            if (anim == 0) then
                L(1)="   ~ ~ ~ ~            "
                L(2)=" ~/(o) (o)\~          "
                L(3)="  | GHOST |           "
                L(4)=" ~|  ~~~  |~          "
                L(5)="  \~~~~~~/            "
                L(6)="   ~ ~ ~ ~            "
                L(7)="            "
            else if (anim == 1) then
                L(1)="   ~ ~ ~ ~  !!        "
                L(2)=" ~/(X) (X)\~  !!      "
                L(3)="  |!!HIT!!|           "
                L(4)=" ~|  ***  |~          "
                L(5)="  \~~~~~~/            "
                L(6)="   ~ ~ ~ ~            "
                L(7)="            "
            else
                L(1)="   ~ ~ ~ ~            "
                L(2)=" ~/(>) (<)\~          "
                L(3)="  |WAIL!! |  -->      "
                L(4)=" ~|  ~~~  |~          "
                L(5)="  \~~~~~~/            "
                L(6)="   ~ ~ ~ ~            "
                L(7)="            "
            end if
        ! ── 12: 뼈의 군주 모탈리온 (boss lich) ──
        case(12)
            if (anim == 0) then
                L(1)=" ***_____***          "
                L(2)="  /(O)_(O)\           "
                L(3)=" |MORTALION|          "
                L(4)=" | [STAFF] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /  \   /  \          "
            else if (anim == 1) then
                L(1)=" ***_____*** !!       "
                L(2)="  /(X)_(X)\   !!      "
                L(3)=" | !!HIT!! |          "
                L(4)=" | [*!!!*] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /  \   /  \          "
            else
                L(1)=" ***_____***          "
                L(2)="  /(@)_(@)\           "
                L(3)="<|DARK WAVE|          "
                L(4)="<| [CURSE] |          "
                L(5)="  \_______/           "
                L(6)="  /|     |\           "
                L(7)=" /  \   /  \          "
            end if
        ! ── 13: 요정 자객 (fairy with wings) ──
        case(13)
            if (anim == 0) then
                L(1)="  >>{^}<<             "
                L(2)="  /(*)(*)\            "
                L(3)=" | FAIRY  |           "
                L(4)=" |  ---   |           "
                L(5)="  \_____/             "
                L(6)="  >>{_}<<             "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  >>{^}<< !!          "
                L(2)="  /(X)(X)\  !!        "
                L(3)=" | !!HIT |            "
                L(4)=" |  ***   |           "
                L(5)="  \_____/             "
                L(6)="  >>{_}<<             "
                L(7)="            "
            else
                L(1)="  >>{^}<<             "
                L(2)="  /(>)(<)\            "
                L(3)=" |STAB!! |  -->       "
                L(4)=" |  ---   |           "
                L(5)="  \_____/             "
                L(6)="  >>{_}<<             "
                L(7)="            "
            end if
        ! ── 14: 연금 골렘 (golem with runes) ──
        case(14)
            if (anim == 0) then
                L(1)="  *[#####]*           "
                L(2)="  |(@) (@)|           "
                L(3)="  | GOLEM  |          "
                L(4)="  |[#####] |          "
                L(5)="  |[#####] |          "
                L(6)="  |_|   |_|           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  *[#####]* !!        "
                L(2)="  |(X) (X)|  !!       "
                L(3)="  | !!HIT  |          "
                L(4)="  |[*****] |          "
                L(5)="  |[*****] |          "
                L(6)="  |_|   |_|           "
                L(7)="            "
            else
                L(1)="  *[#####]*           "
                L(2)="  |(>)_(<)|           "
                L(3)="  |SMASH!! |  -->     "
                L(4)="  |[#####] |          "
                L(5)="  |[#####] |          "
                L(6)="  |_|   |_|           "
                L(7)="            "
            end if
        ! ── 15: 정령 전사 (spirit warrior) ──
        case(15)
            if (anim == 0) then
                L(1)="  ~*~*~*~*~           "
                L(2)="  /(^) (^)\           "
                L(3)=" | SPIRIT  |          "
                L(4)=" | [BLADE] |          "
                L(5)="  \_______/           "
                L(6)="  ~*~*~*~*~           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  ~*~*~*~*~ !!        "
                L(2)="  /(X) (X)\  !!       "
                L(3)=" | !!HIT!! |          "
                L(4)=" | [*!!!*] |          "
                L(5)="  \_______/           "
                L(6)="  ~*~*~*~*~           "
                L(7)="            "
            else
                L(1)="  ~*~*~*~*~           "
                L(2)="  /(>) (<)\           "
                L(3)="<| SLASH!! |          "
                L(4)="<| [BLADE] |          "
                L(5)="  \_______/           "
                L(6)="  ~*~*~*~*~           "
                L(7)="            "
            end if
        ! ── 16: 정령의 지배자 에르다 (boss spirit lord) ──
        case(16)
            if (anim == 0) then
                L(1)=" ***{ERDA}***         "
                L(2)="  /(*)  (*)\          "
                L(3)=" | ERDA!!  |          "
                L(4)=" |[SPIRIT] |          "
                L(5)="  \_______/           "
                L(6)=" ***{    }***         "
                L(7)=" *  *    *  *         "
            else if (anim == 1) then
                L(1)=" ***{ERDA}*** !!      "
                L(2)="  /(X)  (X)\   !!     "
                L(3)=" | !!HIT!! |          "
                L(4)=" |[*!!!**] |          "
                L(5)="  \_______/           "
                L(6)=" ***{    }***         "
                L(7)=" *  *    *  *         "
            else
                L(1)=" ***{ERDA}***         "
                L(2)="  /(>)  (<)\          "
                L(3)="<|SPIRIT!! |          "
                L(4)="<|[DOMINATE]|         "
                L(5)="  \_______/           "
                L(6)=" ***{    }***         "
                L(7)=" *  *    *  *         "
            end if
        ! ── 17: 어둠 기사단원 (dark knight armored) ──
        case(17)
            if (anim == 0) then
                L(1)="   #######            "
                L(2)="  #(>)  (<)#          "
                L(3)=" #| DKNIGHT|#         "
                L(4)=" #|[SHIELD]|#         "
                L(5)="  #_______#           "
                L(6)="  #|     |#           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="   ####### !!         "
                L(2)="  #(X)  (X)#  !!      "
                L(3)=" #| !!HIT!!|#         "
                L(4)=" #|[*!!!*] |#         "
                L(5)="  #_______#           "
                L(6)="  #|     |#           "
                L(7)="            "
            else
                L(1)="   #######            "
                L(2)="  #(>>)(<<)#          "
                L(3)="<#|BLADESTM|#         "
                L(4)="<#|[SWORD] |#         "
                L(5)="  #_______#           "
                L(6)="  #|     |#           "
                L(7)="            "
            end if
        ! ── 18: 영혼 망령 (wraith shadowy) ──
        case(18)
            if (anim == 0) then
                L(1)="  . . . . .           "
                L(2)=" . /(o)(o)\ .         "
                L(3)="  | WRAITH |          "
                L(4)=" . | ~~~~ | .         "
                L(5)="  . \____/ .          "
                L(6)="  . . . . .           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  . . . . .  !!       "
                L(2)=" . /(X)(X)\ .  !!     "
                L(3)="  | !!HIT |           "
                L(4)=" . | **** | .         "
                L(5)="  . \____/ .          "
                L(6)="  . . . . .           "
                L(7)="            "
            else
                L(1)="  . . . . .           "
                L(2)=" . /(>)(<)\ .         "
                L(3)="  |HAUNTS! |  -->     "
                L(4)=" . | ~~~~ | .         "
                L(5)="  . \____/ .          "
                L(6)="  . . . . .           "
                L(7)="            "
            end if
        ! ── 19: 공허 마물 (void creature) ──
        case(19)
            if (anim == 0) then
                L(1)="  :::::::::::         "
                L(2)=" ::(o)   (o)::        "
                L(3)="  : VOID  :           "
                L(4)=" ::BEAST ::           "
                L(5)="  :::::::::::         "
                L(6)="  :       :           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  ::::::::::: !!      "
                L(2)=" ::(X)   (X)::  !!    "
                L(3)="  : !!HIT :           "
                L(4)=" ::****  ::           "
                L(5)="  :::::::::::         "
                L(6)="  :       :           "
                L(7)="            "
            else
                L(1)="  :::::::::::         "
                L(2)=" ::(>)   (<)::        "
                L(3)="<: DEVOUR :           "
                L(4)="<:CONSUME ::          "
                L(5)="  :::::::::::         "
                L(6)="  :       :           "
                L(7)="            "
            end if
        ! ── 20: 어둠의 기사 말가론 (boss demon lord) ──
        case(20)
            if (anim == 0) then
                L(1)=" ###{MALGR}###        "
                L(2)="  ##(O)  (O)##        "
                L(3)=" ##|MALGARON|##       "
                L(4)=" ##|[CHAOS] |##       "
                L(5)="  ##_______##         "
                L(6)=" ##|       |##        "
                L(7)="##/         \##       "
            else if (anim == 1) then
                L(1)=" ###{MALGR}### !!     "
                L(2)="  ##(X)  (X)##  !!    "
                L(3)=" ##| !!HIT!! |##      "
                L(4)=" ##|[*!!!*]  |##      "
                L(5)="  ##_______##         "
                L(6)=" ##|       |##        "
                L(7)="##/         \##       "
            else
                L(1)=" ###{MALGR}###        "
                L(2)="  ##(>)  (<)##        "
                L(3)="<##|DARKNESS|##       "
                L(4)="<##|[BLADE] |##       "
                L(5)="  ##_______##         "
                L(6)=" ##|       |##        "
                L(7)="##/         \##       "
            end if
        ! ── 21: 심연 수호자 (abyss guardian huge) ──
        case(21)
            if (anim == 0) then
                L(1)=" ~~((@))((@ ))~~      "
                L(2)="  |  ABYSS   |        "
                L(3)="  | GUARDIAN |        "
                L(4)="  |[#######] |        "
                L(5)="  |_________|         "
                L(6)=" /           \        "
                L(7)="/~~~~~~~~~~~~~\       "
            else if (anim == 1) then
                L(1)=" ~~((X))(( X))~~ !!  "
                L(2)="  | !!HIT!!  |  !!    "
                L(3)="  | GUARDIAN |        "
                L(4)="  |[*!!!!!!] |        "
                L(5)="  |_________|         "
                L(6)=" /           \        "
                L(7)="/~~~~~~~~~~~~~\       "
            else
                L(1)=" ~~((@))((@ ))~~      "
                L(2)="<|  DEVOUR!! |        "
                L(3)="<| GUARDIAN |         "
                L(4)="<|[COLLAPSE] |        "
                L(5)="  |_________|         "
                L(6)=" /           \        "
                L(7)="/~~~~~~~~~~~~~\       "
            end if
        ! ── 22: 드래곤 새끼 (small dragon) ──
        case(22)
            if (anim == 0) then
                L(1)="   /\_____/\          "
                L(2)="  /(o)   (o)\         "
                L(3)=" | DRAGON!! |         "
                L(4)=" |  /~~~\   |         "
                L(5)="  \_______/           "
                L(6)="  / \   / \           "
                L(7)="            "
            else if (anim == 1) then
                L(1)="   /\_____/\ !!       "
                L(2)="  /(X)   (X)\  !!     "
                L(3)=" | !!HIT!!  |         "
                L(4)=" |  /*~*\   |         "
                L(5)="  \_______/           "
                L(6)="  / \   / \           "
                L(7)="            "
            else
                L(1)="   /\_____/\          "
                L(2)="  /(>)   (<)\         "
                L(3)="<| FIRE!! |           "
                L(4)="<|  ROAR!! |          "
                L(5)="  \_______/           "
                L(6)="  / \   / \           "
                L(7)="            "
            end if
        ! ── 23: 신비 정령 (crystal spirit) ──
        case(23)
            if (anim == 0) then
                L(1)="  *<>*<>*<>*          "
                L(2)="  /<*>  <*>\          "
                L(3)=" |CRYSTAL  |          "
                L(4)=" | SPIRIT  |          "
                L(5)="  \*<>*<>*/           "
                L(6)="  *<>*<>*<>*          "
                L(7)="            "
            else if (anim == 1) then
                L(1)="  *<>*<>*<>* !!       "
                L(2)="  /<X>  <X>\   !!     "
                L(3)=" | !!HIT!! |          "
                L(4)=" | *!!!*   |          "
                L(5)="  \*<>*<>*/           "
                L(6)="  *<>*<>*<>*          "
                L(7)="            "
            else
                L(1)="  *<>*<>*<>*          "
                L(2)="  /<*>  <*>\          "
                L(3)="<|CRYSTAL  |          "
                L(4)="<| BLAST!! |          "
                L(5)="  \*<>*<>*/           "
                L(6)="  *<>*<>*<>*          "
                L(7)="            "
            end if
        ! ── 24: 심연의 군주 카오스 (boss ultimate chaos being) ──
        case default
            if (anim == 0) then
                L(1)="***{CHAOS LORD}***    "
                L(2)=" **((@))  ((@))**     "
                L(3)="  |  CHAOS   |        "
                L(4)="  |  LORD!!  |        "
                L(5)="  |[#######] |        "
                L(6)=" **\_______/**        "
                L(7)="***           ***     "
            else if (anim == 1) then
                L(1)="***{CHAOS LORD}*** !! "
                L(2)=" **((X))  ((X))**  !! "
                L(3)="  | !!HIT!!  |        "
                L(4)="  | *BOOM*   |        "
                L(5)="  |[*!!!!!!] |        "
                L(6)=" **\_______/**        "
                L(7)="***           ***     "
            else
                L(1)="***{CHAOS LORD}***    "
                L(2)=" **((@))  ((@))**     "
                L(3)="<<|  CHAOS!! |        "
                L(4)="<<|DESTROY!! |        "
                L(5)="<<|[OBLIVION]|        "
                L(6)=" **\_______/**        "
                L(7)="***           ***     "
            end if
        end select
    end subroutine get_monster_art_unique
    ! ─────────────────────────────────────────────────────────────
    !  펫 아스키 아트
    ! ─────────────────────────────────────────────────────────────
    subroutine get_pet_art(pet_name, anim, L)
        character(len=*), intent(in) :: pet_name
        integer, intent(in) :: anim
        character(len=20), intent(out) :: L(5)
        if (index(pet_name, "작은새") > 0 .or. index(pet_name, "앉아있는") > 0) then
            if (anim == 0) then
                L(1)="   ,--,         "
                L(2)="  ( o o)        "
                L(3)="  |  V  |  BIRD "
                L(4)="   \___/        "
                L(5)="   /   \        "
            else if (anim == 1) then
                L(1)="   ,--,  >>     "
                L(2)="  ( ^ ^) >>     "
                L(3)="  |PECK!|       "
                L(4)="   \___/        "
                L(5)="   /   \        "
            else
                L(1)="   ,--,  !!     "
                L(2)="  ( x x)  !!    "
                L(3)="  | HIT |       "
                L(4)="   \___/        "
                L(5)="   /   \        "
            end if
        else if (index(pet_name, "새헤이만") > 0) then
            if (anim == 0) then
                L(1)="  _{=}_          "
                L(2)=" ( o  o)  HEYMAN"
                L(3)=" |  >>  |       "
                L(4)="  \____/        "
                L(5)=" /| || |\       "
            else if (anim == 1) then
                L(1)="  _{=}_  >>     "
                L(2)=" ( ^  ^)>>      "
                L(3)=" |SLASH!|       "
                L(4)="  \____/        "
                L(5)=" /| || |\       "
            else
                L(1)="  _{=}_ !!      "
                L(2)=" ( x  x) !!     "
                L(3)=" | HIT! |       "
                L(4)="  \____/        "
                L(5)=" /| || |\       "
            end if
        else if (index(pet_name, "윤현식") > 0) then
            if (anim == 0) then
                L(1)="  (^_^)          "
                L(2)=" /|YHS|\  HUMAN "
                L(3)=" | ... |        "
                L(4)="  \___/         "
                L(5)="  /   \         "
            else if (anim == 1) then
                L(1)="  (>_<) >>      "
                L(2)=" /|ATK!|\ >>    "
                L(3)=" | HAI! |       "
                L(4)="  \___/         "
                L(5)="  /   \         "
            else
                L(1)="  (x_x) !!      "
                L(2)=" /| !! |\ !!    "
                L(3)=" | OWW  |       "
                L(4)="  \___/         "
                L(5)="  /   \         "
            end if
        else if (index(pet_name, "닭헤이만") > 0) then
            if (anim == 0) then
                L(1)="   __{o}__       "
                L(2)="  ( o  o ) CHICK"
                L(3)="  | BWOCK |      "
                L(4)="   \_____/       "
                L(5)="   /| | |\       "
            else if (anim == 1) then
                L(1)="   __{o}__ >>    "
                L(2)="  ( > < ) >>     "
                L(3)="  |PECK!! |      "
                L(4)="   \_____/       "
                L(5)="   /| | |\       "
            else
                L(1)="   __{o}__ !!    "
                L(2)="  ( x  x ) !!    "
                L(3)="  | OUCH! |      "
                L(4)="   \_____/       "
                L(5)="   /| | |\       "
            end if
        else
            if (anim == 0) then
                L(1)="  [#####]        "
                L(2)="  (#) (#)  JEONG"
                L(3)="  | ~~~ |       "
                L(4)="  \#####/       "
                L(5)="  /|   |\       "
            else if (anim == 1) then
                L(1)="  [#####] >>     "
                L(2)="  (>) (<) >>     "
                L(3)="  |STRIKE|       "
                L(4)="  \#####/        "
                L(5)="  /|   |\        "
            else
                L(1)="  [#####] !!     "
                L(2)="  (x) (x) !!     "
                L(3)="  | HIT! |       "
                L(4)="  \#####/        "
                L(5)="  /|   |\        "
            end if
        end if
    end subroutine get_pet_art

    ! ─────────────────────────────────────────────────────────────
    !  전투 화면 그리기 (대각선 배치: 플레이어 좌하, 몬스터 우상)
    ! ─────────────────────────────────────────────────────────────
    subroutine draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, p_anim, m_anim, msg, pet_anim)
        type(character_t), intent(in) :: pc
        character(len=*), intent(in) :: e_name, msg
        integer, intent(in) :: m_hp, m_max_hp, mon_id, p_anim, m_anim
        integer, intent(in), optional :: pet_anim
        character(len=20) :: p_bar, m_bar
        character(len=30) :: pl(7)
        character(len=26) :: ml(7)
        character(len=20) :: ptl(5)
        integer :: pa, j
        integer :: i

        call clear_screen()
        call hp_bar(pc%hp, pc%max_hp, p_bar)
        call hp_bar(m_hp,  m_max_hp,   m_bar)
        call get_player_art_equipped(pc%weapon%grade, pc%armor%grade, p_anim, pl)
        call get_monster_art_unique(mon_id, m_anim, ml)

        ! ── 상단 상태창 ──────────────────────────────────────────
        write(*,'(A)')"  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '("  ┃  [",A10,"] HP:[",A20,"]",I4,"/",I4,"  포션:",I2,T69,"┃")') &
            trim(pc%name), p_bar, pc%hp, pc%max_hp, pc%hp_potions
        write(*,'(A)')"  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"

        ! ── 몬스터 (우상단) ──────────────────────────────────────
        print *, ""
        write(*, '(T40, "[ ", A20, " ]")') trim(e_name)
        write(*, '(T40, "HP:[", A20, "]", I4, "/", I4)') m_bar, m_hp, m_max_hp
        do i = 1, 7
            write(*, '(T40, A)') trim(ml(i))
        end do

        ! ── 공격 이펙트 라인 ─────────────────────────────────────
        print *, ""
        if (p_anim == 1) then
            write(*, '("  >>========= SLASH!! ============>>", T70, " ")')
        else if (m_anim == 2) then
            write(*, '("  <<============ ATTACK!! ========<<", T70, " ")')
        else
            write(*, '("  ", T70, " ")')
        end if
        print *, ""

        ! ── 플레이어 (좌하단) ────────────────────────────────────
        do i = 1, 7
            write(*, '("  ", A)') trim(pl(i))
        end do
        write(*, '("  [",A10,"] HP:[",A20,"]",I4,"/",I4)') &
            trim(pc%name), p_bar, pc%hp, pc%max_hp

        ! ── 펫 표시 ──────────────────────────────────────────────
        if (pc%pet%active .and. pc%pet%hp > 0) then
            pa = 0
            if (present(pet_anim)) pa = pet_anim
            call get_pet_art(pc%pet%name, pa, ptl)
            write(*, '("  PET: ", A20, "  HP:", I3, "/", I3, " ATK:", I3)') &
                trim(ptl(1)), pc%pet%hp, pc%pet%max_hp, pc%pet%atk
            do j = 2, 5
                write(*, '("  ", A)') trim(ptl(j))
            end do
            write(*, '("  [", A12, "] Lv:", I2, " [", A6, "]")') &
                trim(pc%pet%name), pc%pet%level, trim(elem_name(pc%pet%element))
        end if

        ! ── 메시지 ───────────────────────────────────────────────
        print *, ""
        if (len_trim(msg) > 0) then
            write(*,'(A)')"  ┌──────────────────────────────────────────────────────────────────┐"
            write(*, '("  │  ", A64, "│")') trim(msg)
            write(*,'(A)')"  └──────────────────────────────────────────────────────────────────┘"
        end if
    end subroutine draw_combat_scene
    ! D6: show_attack_submenu updated with skills
    subroutine show_attack_submenu(pc, atk_choice, atk_dmg_mult, atk_acc)
        type(character_t), intent(in) :: pc
        integer, intent(out) :: atk_choice
        real, intent(out) :: atk_dmg_mult, atk_acc
        integer :: wg, i, ios
        character(len=10) :: mp_str
        wg = pc%weapon%grade

        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║           ⚔  공 격  유  형  선  택  ⚔               ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*, '("  ║  MP: ", I4, "/", I4, T55, "║")') pc%mp, pc%max_mp
        write(*,'(A)')"  ║  (1) 주먹질     - 0MP - 100%명중 - x0.5             ║"
        write(*,'(A)')"  ║  (2) 기본공격   - 0MP -  75%명중 - x1.0             ║"
        ! Show equipped skills as options 3+
        do i = 1, 6
            if (pc%skills(i)%unlocked .and. pc%skills(i)%equipped) then
                if (pc%mp >= pc%skills(i)%mp_cost) then
                    write(*, '("  ║  (", I1, ") ", A16, " - ", I3, "MP - 85%명중 - x", F3.1, T55, "║")') &
                        i+2, trim(pc%skills(i)%name), pc%skills(i)%mp_cost, pc%skills(i)%dmg_mult
                else
                    write(*, '("  ║  (", I1, ") ", A16, " [MP부족:", I3, "/", I3, "]", T55, "║")') &
                        i+2, trim(pc%skills(i)%name), pc%mp, pc%skills(i)%mp_cost
                end if
            end if
        end do
        write(*,'(A)')"  ║  (0) 뒤로 돌아가기                                  ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"

        do
            call safe_read(atk_choice)
            if (atk_choice == 0) then
                atk_dmg_mult = 0.0; atk_acc = 0.0; return
            end if
            if (atk_choice == 1) exit
            if (atk_choice == 2) exit
            ! Check skill choices 3..8 (skill index = atk_choice - 2)
            if (atk_choice >= 3 .and. atk_choice <= 8) then
                i = atk_choice - 2
                if (i >= 1 .and. i <= 6) then
                    if (pc%skills(i)%unlocked .and. pc%skills(i)%equipped) then
                        if (pc%mp >= pc%skills(i)%mp_cost) exit
                        write(*,'(A)')"  [!] MP가 부족합니다."
                    end if
                end if
            end if
            write(*,'(A)')"  [!] 사용할 수 없는 공격입니다."
        end do

        select case(atk_choice)
        case(1); atk_dmg_mult=0.5;  atk_acc=1.00
        case(2); atk_dmg_mult=1.0;  atk_acc=0.75
        case default
            i = atk_choice - 2
            if (i >= 1 .and. i <= 6) then
                atk_dmg_mult = pc%skills(i)%dmg_mult
                atk_acc = 0.85
            else
                atk_dmg_mult = 1.0; atk_acc = 1.0
            end if
        end select
    end subroutine show_attack_submenu
    subroutine show_stage_story(region, stage, is_boss)
        integer, intent(in) :: region, stage
        logical, intent(in) :: is_boss
        integer :: tier
        character(len=70) :: line1, line2
        tier = (region - 1) / 4 + 1

        if (stage == 1 .and. .not. is_boss) then
            select case(tier)
            case(1)
                line1 = "낡고 허름한 오솔길 끝에 울창한 숲이 펼쳐진다."
                line2 = "으르렁거리는 소리가 들린다... 적이 나타났다!"
            case(2)
                line1 = "파도가 거칠게 치는 해안가. 난파선의 잔해가 쌓여있다."
                line2 = "해적 무리가 눈을 번뜩이며 다가온다!"
            case(3)
                line1 = "모래바람이 휘몰아치는 고대 유적. 뼈들이 바닥에 가득하다."
                line2 = "어둠 속에서 해골들이 깨어나기 시작한다!"
            case(4)
                line1 = "신비로운 빛이 가득한 정령의 땅. 공기마저 마법으로 가득하다."
                line2 = "적대적인 정령들이 길을 막아선다!"
            case(5)
                line1 = "어둠이 내려앉은 저주받은 땅. 끝없는 절망이 감돈다."
                line2 = "어둠의 기사들이 칼을 뽑아들며 다가온다!"
            case default
                line1 = "현실과 꿈의 경계가 무너진 심연. 모든 것이 무의미해 보인다."
                line2 = "그 속에서 존재해선 안 될 것들이 깨어난다..."
            end select
            call clear_screen()
            call show_dialogue_box("스토리", line1, line2)
            call wait_for_enter()

        else if (stage == 3 .and. .not. is_boss) then
            select case(tier)
            case(1)
                line1 = "상처 입은 여행자가 나타나 속삭인다:"
                line2 = "이 숲의 왕은 엄청난 힘을 가졌소. 조심하시오..."
            case(2)
                line1 = "해적 하나가 쓰러지며 말한다:"
                line2 = "...단장은... 태풍의 힘을 지배한다... 도망쳐..."
            case(3)
                line1 = "고대 비문에 새겨진 글귀가 눈에 들어온다:"
                line2 = "뼈의 군주에게 진 자는 영원히 이 유적의 포로가 된다..."
            case(4)
                line1 = "작은 정령이 가까이 날아와 경고한다:"
                line2 = "에르다는 이 땅의 모든 정령을 지배하는 자입니다. 조심하세요!"
            case(5)
                line1 = "죽어가는 병사가 마지막 힘으로 외친다:"
                line2 = "말가론... 그는 인간이 아니야... 도망... 쳐..."
            case default
                line1 = "공간이 뒤틀리며 목소리가 들린다:"
                line2 = "카오스는 창세의 힘을 흡수했다. 일반 존재는 이길 수 없다..."
            end select
            call clear_screen()
            call show_dialogue_box("조력자", line1, line2)
            call wait_for_enter()

        else if (is_boss) then
            select case(tier)
            case(1)
                line1 = "그린워프 : '감히 내 숲을 침범하다니!'"
                line2 = "그린워프 : '네 뼈로 이 숲을 장식해 주마!!'"
            case(2)
                line1 = "레드단장 : '하하하! 여기까지 온 용기는 가상하구나!'"
                line2 = "레드단장 : '하지만 여기서 네 여정은 끝이다!!'"
            case(3)
                line1 = "모탈리온 : '크르르... 살아있는 자여... 두려움을 느껴라...'"
                line2 = "모탈리온 : '너의 영혼도 내 군대에 합류하게 될 것이다!!!'"
            case(4)
                line1 = "에르다 : '인간이 여기까지? 대단한 의지로군.'"
                line2 = "에르다 : '하지만 정령의 힘 앞에서는 무력하리라!'"
            case(5)
                line1 = "말가론 : '...오랫동안 기다렸다. 진정한 적수를.'"
                line2 = "말가론 : '하지만 그 끝은 항상 같다. 절망. 그리고 죽음.'"
            case default
                line1 = "카오스 : '...너는 이미 패배했다. 태어나는 순간부터.'"
                line2 = "카오스 : '창세의 힘으로 이 세계를 다시 무(無)로 돌리겠다!!!'"
            end select
            call clear_screen()
            call show_dialogue_box("보스 등장", line1, line2)
            call wait_for_enter()
        end if
    end subroutine show_stage_story

    subroutine show_victory_story(region, stage, is_boss, pc)
        integer, intent(in) :: region, stage
        logical, intent(in) :: is_boss
        type(character_t), intent(in) :: pc
        integer :: tier
        character(len=70) :: line1, line2
        tier = (region - 1) / 4 + 1

        if (is_boss) then
            select case(tier)
            case(1)
                line1 = "그린워프가 쓰러지며 숲이 잠시 조용해진다."
                line2 = "숲의 봉인이 풀리고 새로운 길이 열린다!"
            case(2)
                line1 = "레드 단장이 바다에 쓰러진다. 해적단이 흩어진다."
                line2 = "폭풍이 가라앉고 새로운 항로가 보인다!"
            case(3)
                line1 = "모탈리온이 산산조각 나며 유적에 빛이 스며든다."
                line2 = "고대의 저주가 풀리고 새로운 땅이 열린다!"
            case(4)
                line1 = "에르다가 패배를 인정하며 정령들이 물러난다."
                line2 = "정령의 땅이 축복하며 다음 길을 알려준다!"
            case(5)
                line1 = "말가론의 갑옷이 부서지며 어둠이 걷힌다."
                line2 = "저주받은 땅에 처음으로 빛이 스며든다..."
            case default
                line1 = "카오스가 소멸하며 심연이 안정을 되찾는다."
                line2 = "세계를 구했다. 이 여정은 이제 끝이 났다..."
            end select
            call clear_screen()
            call show_dialogue_box("보스 처치!", line1, line2)
            call wait_for_enter()
        end if
    end subroutine show_victory_story
    subroutine show_talk_menu(e_name, mon_id, pc, talk_result, atk_mult)
        character(len=*), intent(in) :: e_name
        integer, intent(in) :: mon_id
        type(character_t), intent(in) :: pc
        integer, intent(out) :: talk_result
        real, intent(out) :: atk_mult

        integer :: tier_grp, opt, ios
        real :: rr, peace_prob
        character(len=70) :: opt1_line, opt2_line, opt3_line

        ! tier 그룹 결정 (mon_id 기반, 보스포함)
        tier_grp = (mon_id - 1) / 4 + 1
        if (tier_grp > 6) tier_grp = 6

        ! 평화적 접근 성공 확률
        select case(tier_grp)
        case(1); peace_prob = 0.50
        case(2); peace_prob = 0.40
        case(3); peace_prob = 0.30
        case(4); peace_prob = 0.25
        case(5); peace_prob = 0.15
        case default; peace_prob = 0.05
        end select

        talk_result = 0
        atk_mult = 1.0

        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
        write(*, '("  ║  대화 상대: ", A20, T56, "║")') trim(e_name)
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║  (1) 평화적 접근  - 싸우지 말자고 설득한다.        ║"
        write(*,'(A)')"  ║  (2) 협박 / 도발  - 겁을 주거나 자존심을 건드린다. ║"
        write(*,'(A)')"  ║  (3) 골드 제공    - 골드 50 을 건네 위기를 넘긴다. ║"
        write(*,'(A)')"  ║  (0) 취소 (전투로 돌아가기)                         ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
        call safe_read(opt)

        ! 보스는 항상 분노
        if (mod(mon_id, 4) == 0) then
            if (opt == 0) then
                talk_result = 0; return
            end if
            call show_dialogue_box("대화 실패", trim(e_name)//"은(는) 대화를 거부한다!", "오히려 더욱 분노했다!")
            call wait_for_enter()
            talk_result = 2
            atk_mult = 1.4
            return
        end if

        select case(opt)
        case(0)
            talk_result = 0
        case(1) ! 평화적 접근
            call random_number(rr)
            if (rr < peace_prob) then
                call show_dialogue_box("대화 성공!", trim(e_name)//"이(가) 물러났다!", "전투를 피했습니다.")
                call wait_for_enter()
                talk_result = 1
            else
                call show_dialogue_box("대화 실패", trim(e_name)//"이(가) 무시한다.", "전투를 계속합니다.")
                call wait_for_enter()
                talk_result = 0
            end if
        case(2) ! 협박/도발
            call random_number(rr)
            if (rr < 0.10) then
                call show_dialogue_box("협박 성공!", trim(e_name)//"이(가) 겁먹고 물러난다!", "전투를 피했습니다.")
                call wait_for_enter()
                talk_result = 1
            else
                call show_dialogue_box("협박 실패!", trim(e_name)//"이(가) 분노했다!", "공격력이 상승했습니다!")
                call wait_for_enter()
                talk_result = 2
                atk_mult = 1.4
            end if
        case(3) ! 골드 제공
            if (pc%gold >= 50) then
                call show_dialogue_box("골드 제공", "골드 50을 건넸다.", trim(e_name)//"이(가) 물러났다!")
                call wait_for_enter()
                talk_result = 1
            else
                call show_dialogue_box("골드 부족", "골드가 부족합니다.", trim(e_name)//"이(가) 분노했다!")
                call wait_for_enter()
                talk_result = 2
                atk_mult = 1.4
            end if
        case default
            talk_result = 0
        end select
    end subroutine show_talk_menu

    subroutine event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result, is_boss)
        type(character_t), intent(inout) :: pc
        character(len=*), intent(in) :: e_name
        integer, intent(in) :: m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed
        integer, intent(out) :: result
        logical, intent(in), optional :: is_boss

        integer :: m_hp, cmd, atk_sub, p_dmg, m_dmg, pet_dmg, skill_idx
        integer :: cur_m_atk, talk_result
        integer :: m_status, m_status_turns
        integer :: burn_dmg, poison_dmg, conf_dmg, m_burn_dmg, m_poison_dmg
        integer :: p_speed_eff, m_speed_eff, crit_chance
        integer :: set_atk, set_def, set_hp
        real :: rr, acc, dmg_mult, atk_mult, e_mod, pet_mod, rr2, crit_mult, p_atk_mult
        character(len=70) :: msg
        logical :: fled, skip_player, monster_goes_first

        m_hp = m_max_hp
        cur_m_atk = m_atk
        fled = .false.
        result = 0
        m_status = STATUS_NORMAL
        m_status_turns = 0
        call get_set_bonus(pc, set_atk, set_def, set_hp)

        p_speed_eff = pc%speed
        m_speed_eff = mon_speed
        if (pc%status == STATUS_PARA) p_speed_eff = p_speed_eff / 2
        monster_goes_first = (m_speed_eff > p_speed_eff)

        do while (m_hp > 0 .and. pc%hp > 0 .and. .not. fled)

            skip_player = .false.

            ! Show status info
            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "당신의 행동을 선택하세요.")
            if (pc%status /= STATUS_NORMAL) then
                write(*,'("  [플레이어 상태: ", A, "]")') trim(status_name(pc%status))
            end if
            if (m_status /= STATUS_NORMAL) then
                write(*,'("  [몬스터 상태: ", A, "]")') trim(status_name(m_status))
            end if
            write(*, '("  ┌──────────────────────────────────────────────────────┐")')
            write(*, '("  │  (1) 공격  (2) 도망가기  (3) 아이템  (4) 대화하기  │")')
            write(*, '("  │  DEF:", I3, "  SPD:", I3, "  MP:", I4, "/", I4, T55, "│")') &
                pc%base_def+pc%armor%def, pc%speed, pc%mp, pc%max_mp
            write(*, '("  └──────────────────────────────────────────────────────┘")')
            call safe_read(cmd)

            ! If monster goes first on this turn, handle monster turn before player
            if (monster_goes_first) then
                ! monster status
                select case(m_status)
                case(STATUS_BURN)
                    m_burn_dmg = max(1, m_max_hp / 16)
                    m_hp = m_hp - m_burn_dmg
                    write(msg, '(A, " 화상 데미지! -", I3)') trim(e_name), m_burn_dmg
                    call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                    call delay(0.4)
                    if (m_hp <= 0) exit
                case(STATUS_POISON)
                    m_poison_dmg = max(1, m_max_hp / 12)
                    m_hp = m_hp - m_poison_dmg
                    write(msg, '(A, " 독 데미지! -", I3)') trim(e_name), m_poison_dmg
                    call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                    call delay(0.4)
                    if (m_hp <= 0) exit
                case(STATUS_PARA)
                    call random_number(rr)
                    if (rr < 0.25) then
                        write(msg, '(A, " 마비로 행동 불가!")') trim(e_name)
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        goto 200
                    end if
                case(STATUS_SLEEP)
                    if (m_status_turns > 0) then
                        m_status_turns = m_status_turns - 1
                        write(msg, '(A, " 수면 중...")') trim(e_name)
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        goto 200
                    else
                        m_status = STATUS_NORMAL
                    end if
                case(STATUS_CONF)
                    call random_number(rr)
                    if (rr < 0.33) then
                        conf_dmg = max(1, cur_m_atk / 3)
                        m_hp = m_hp - conf_dmg
                        write(msg, '(A, " 혼란으로 자해! -", I3)') trim(e_name), conf_dmg
                        call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        if (m_hp <= 0) exit
                        goto 200
                    end if
                end select

                ! Monster attacks player
                call random_number(rr)
                if (rr * 100 > pc%evasion) then
                    e_mod = elem_modifier(mon_element, pc%element)
                    m_dmg = max(1, int(real(cur_m_atk) * e_mod) - (pc%base_def + pc%armor%def + set_def + (pc%skill_points/3)*2))
                    if (pc%job /= JOB_HOPPANG) m_dmg = max(1, int(real(cur_m_atk) * e_mod) - (pc%base_def + pc%armor%def + set_def))
                    call random_number(rr2)
                    if (pc%pet%active .and. pc%pet%hp > 0 .and. rr2 < 0.5) then
                        pc%pet%hp = pc%pet%hp - m_dmg
                        if (pc%pet%hp < 0) pc%pet%hp = 0
                        write(msg, '("펫이 대신 맞았다! 펫 HP -", I3, " (남은: ", I3, ")")') m_dmg, pc%pet%hp
                        if (pc%pet%hp == 0) then
                            pc%pet%active = .false.
                            write(msg, '(A, " 의 공격! 펫이 쓰러졌다!")') trim(e_name)
                        end if
                    else
                        pc%hp = pc%hp - m_dmg
                        write(msg, '(A, " 의 공격! ", I4, " 데미지!")') trim(e_name), m_dmg
                    end if
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 2, 2, trim(msg), 2)
                    call delay(0.5)
                    if (pc%hp <= 0) exit
                else
                    write(msg, '(A, " 의 공격을 회피했다!")') trim(e_name)
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 2, trim(msg))
                    call delay(0.4)
                end if
                200 continue
            end if

            ! Player status effects
            select case(pc%status)
            case(STATUS_BURN)
                burn_dmg = max(1, pc%max_hp / 16)
                p_atk_mult = 0.67
                pc%hp = pc%hp - burn_dmg
                write(msg, '("화상 데미지! -", I3, " HP")') burn_dmg
                call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                call delay(0.4)
                if (pc%hp <= 0) exit
            case(STATUS_POISON)
                p_atk_mult = 1.0
                poison_dmg = max(1, pc%max_hp / 12)
                pc%hp = pc%hp - poison_dmg
                write(msg, '("독 데미지! -", I3, " HP")') poison_dmg
                call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                call delay(0.4)
                if (pc%hp <= 0) exit
            case(STATUS_PARA)
                p_atk_mult = 1.0
                call random_number(rr)
                if (rr < 0.25) then
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "마비로 행동할 수 없다!")
                    call delay(0.4)
                    skip_player = .true.
                end if
            case(STATUS_SLEEP)
                p_atk_mult = 1.0
                if (pc%status_turns > 0) then
                    pc%status_turns = pc%status_turns - 1
                    write(msg, '("수면 상태... 행동 불가! (", I1, "턴 남음)")') pc%status_turns
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                    call delay(0.4)
                    skip_player = .true.
                else
                    pc%status = STATUS_NORMAL
                end if
            case default
                p_atk_mult = 1.0
            end select

            if (.not. skip_player) then
                select case(cmd)
                case(1) ! 공격
                    call show_attack_submenu(pc, atk_sub, dmg_mult, acc)
                    if (atk_sub == 0) cycle

                    if (atk_sub >= 3) then
                        skill_idx = atk_sub - 2
                        if (skill_idx >= 1 .and. skill_idx <= 6) then
                            pc%mp = pc%mp - pc%skills(skill_idx)%mp_cost
                            if (pc%mp < 0) pc%mp = 0
                        end if
                    end if

                    call random_number(rr)
                    if (rr <= acc) then
                        e_mod = elem_modifier(pc%element, mon_element)
                        ! Critical hit
                        crit_chance = 6
                        if (pc%job == JOB_JJABDAM) crit_chance = 12 + min(20, pc%skill_points/3)
                        call random_number(rr)
                        if (rr * 100 < crit_chance) then
                            crit_mult = 1.5
                        else
                            crit_mult = 1.0
                        end if
                        p_dmg = max(1, int(real(pc%base_atk + pc%weapon%atk + set_atk) * dmg_mult * e_mod * p_atk_mult * crit_mult) - m_def)
                        ! JISAY passive: damage bonus
                        if (pc%job == JOB_JISAY) then
                            p_dmg = int(real(p_dmg) * (1.0 + real(min(30, (pc%skill_points/5)*3)) / 100.0))
                        end if
                        m_hp  = m_hp - p_dmg
                        if (crit_mult > 1.0) then
                            write(msg, '("급소! ", A, " 에게 ", I4, " 데미지!")') trim(e_name), p_dmg
                        else
                            write(msg, '(A, " 에게 ", I4, " 데미지! (x", F4.2, ")")') trim(e_name), p_dmg, e_mod
                        end if
                        call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 1, 0, trim(msg))
                        call delay(0.5)

                        ! Status infliction
                        if (m_status == STATUS_NORMAL) then
                            call random_number(rr)
                            select case(pc%element)
                            case(ELEM_FIRE)
                                if (rr < 0.10) m_status = STATUS_BURN
                            case(ELEM_EARTH)
                                if (rr < 0.15) m_status = STATUS_POISON
                            case(ELEM_AIR)
                                if (rr < 0.15) m_status = STATUS_PARA
                            case(ELEM_ETHER)
                                if (rr < 0.20) then
                                    m_status = STATUS_SLEEP
                                    m_status_turns = 1 + int(rr * 3)
                                end if
                            case(ELEM_WATER)
                                if (rr < 0.20) m_status = STATUS_CONF
                            end select
                            if (m_status /= STATUS_NORMAL) then
                                write(msg, '(A, " 에게 ", A, " 상태이상 부여!")') trim(e_name), trim(status_name(m_status))
                                call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 1, 0, trim(msg))
                                call delay(0.4)
                            end if
                        end if

                        ! Pet auto-attack
                        if (pc%pet%active .and. pc%pet%hp > 0 .and. m_hp > 0) then
                            pet_mod = elem_modifier(pc%pet%element, mon_element)
                            pet_dmg = max(1, int(pc%pet%atk * pet_mod))
                            m_hp = m_hp - pet_dmg
                            write(msg, '("펫 ", A, " 공격! -", I3, " (x", F4.2, ")")') &
                                trim(pc%pet%name), pet_dmg, pet_mod
                            call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 1, 0, trim(msg), 1)
                            call delay(0.4)
                        end if

                        if (m_hp <= 0) then
                            call draw_combat_scene(pc, e_name, 0, m_max_hp, mon_id, 1, 1, trim(e_name)//" 처치!")
                            call delay(0.5)
                            exit
                        end if
                    else
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 1, 0, "공격이 빗나갔다!")
                        call delay(0.5)
                    end if

                case(2) ! 도망
                    call random_number(rr)
                    if (rr < 0.45 + pc%evasion * 0.01) then
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "도망에 성공했다!")
                        call delay(0.5)
                        fled = .true.
                        result = 2
                    else
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "도망에 실패했다!")
                        call delay(0.5)
                    end if

                case(3) ! 아이템
                    write(*,'(A)')"  (1) HP포션  (2) MP포션  (3) 치료 아이템 사용"
                    call safe_read(cmd)
                    if (cmd == 1) then
                        if (pc%hp_potions > 0) then
                            pc%hp_potions = pc%hp_potions - 1
                            pc%hp = min(pc%hp + 80, pc%max_hp)
                            pc%status = STATUS_NORMAL
                            pc%status_turns = 0
                            write(msg, '("HP 포션 사용! HP +80 상태이상 해소  (남은: ", I2, ")")') pc%hp_potions
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                            call delay(0.5)
                        else
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "HP포션이 없다!")
                            call delay(0.5)
                        end if
                    else if (cmd == 2) then
                        if (pc%mp_potions > 0) then
                            pc%mp_potions = pc%mp_potions - 1
                            pc%mp = min(pc%mp + 60, pc%max_mp)
                            write(msg, '("MP 포션 사용! MP +60  (남은: ", I2, ")")') pc%mp_potions
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                            call delay(0.5)
                        else
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "MP포션이 없다!")
                            call delay(0.5)
                        end if
                    else if (cmd == 3) then
                        ! Scan inventory for first TYPE_ITEM
                        skill_idx = 0
                        do atk_sub = 1, INV_SIZE
                            if (pc%inventory(atk_sub)%itype == TYPE_ITEM .and. &
                                trim(pc%inventory(atk_sub)%name) /= "---") then
                                skill_idx = atk_sub
                                exit
                            end if
                        end do
                        if (skill_idx == 0) then
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, "치료 아이템이 없다!")
                            call delay(0.5)
                        else
                            select case(trim(pc%inventory(skill_idx)%name))
                            case("해독제")
                                if (pc%status == STATUS_POISON) then
                                    pc%status = STATUS_NORMAL; pc%status_turns = 0
                                    write(msg,'("해독제 사용! 독 상태 해소!")')
                                else
                                    write(msg,'("해독제 사용! (독 상태 아님)")')
                                end if
                            case("각성제")
                                if (pc%status == STATUS_SLEEP) then
                                    pc%status = STATUS_NORMAL; pc%status_turns = 0
                                    write(msg,'("각성제 사용! 수면 상태 해소!")')
                                else
                                    write(msg,'("각성제 사용! (수면 상태 아님)")')
                                end if
                            case("화상치료제")
                                if (pc%status == STATUS_BURN) then
                                    pc%status = STATUS_NORMAL; pc%status_turns = 0
                                    write(msg,'("화상치료제 사용! 화상 상태 해소!")')
                                else
                                    write(msg,'("화상치료제 사용! (화상 상태 아님)")')
                                end if
                            case("만능치료제")
                                pc%status = STATUS_NORMAL; pc%status_turns = 0
                                write(msg,'("만능치료제 사용! 모든 상태이상 해소!")')
                            case default
                                write(msg,'("아이템 사용!")')
                            end select
                            ! Remove item
                            pc%inventory(skill_idx)%name  = "---"
                            pc%inventory(skill_idx)%itype = 0
                            pc%inventory(skill_idx)%value = 0
                            pc%inventory(skill_idx)%grade = 0
                            pc%inventory(skill_idx)%price = 0
                            pc%inventory(skill_idx)%count = 0
                            pc%inv_count = pc%inv_count - 1
                            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                            call delay(0.5)
                        end if
                    end if

                case(4) ! 대화하기
                    call show_talk_menu(e_name, mon_id, pc, talk_result, atk_mult)
                    if (talk_result == 1) then
                        result = 2
                        fled = .true.
                    else if (talk_result == 2) then
                        cur_m_atk = int(cur_m_atk * atk_mult)
                        write(msg, '(A, " 이(가) 분노했다! 공격력 상승!")') trim(e_name)
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.5)
                    end if

                end select
            end if

            if (m_hp <= 0 .or. fled) exit

            if (.not. monster_goes_first) then
                ! Monster status
                select case(m_status)
                case(STATUS_BURN)
                    m_burn_dmg = max(1, m_max_hp / 16)
                    m_hp = m_hp - m_burn_dmg
                    write(msg, '(A, " 화상 데미지! -", I3)') trim(e_name), m_burn_dmg
                    call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                    call delay(0.4)
                    if (m_hp <= 0) exit
                case(STATUS_POISON)
                    m_poison_dmg = max(1, m_max_hp / 12)
                    m_hp = m_hp - m_poison_dmg
                    write(msg, '(A, " 독 데미지! -", I3)') trim(e_name), m_poison_dmg
                    call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                    call delay(0.4)
                    if (m_hp <= 0) exit
                case(STATUS_PARA)
                    call random_number(rr)
                    if (rr < 0.25) then
                        write(msg, '(A, " 마비로 행동 불가!")') trim(e_name)
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        cycle
                    end if
                case(STATUS_SLEEP)
                    if (m_status_turns > 0) then
                        m_status_turns = m_status_turns - 1
                        write(msg, '(A, " 수면 중...")') trim(e_name)
                        call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        cycle
                    else
                        m_status = STATUS_NORMAL
                    end if
                case(STATUS_CONF)
                    call random_number(rr)
                    if (rr < 0.33) then
                        conf_dmg = max(1, cur_m_atk / 3)
                        m_hp = m_hp - conf_dmg
                        write(msg, '(A, " 혼란으로 자해! -", I3)') trim(e_name), conf_dmg
                        call draw_combat_scene(pc, e_name, max(0,m_hp), m_max_hp, mon_id, 0, 0, trim(msg))
                        call delay(0.4)
                        if (m_hp <= 0) exit
                        cycle
                    end if
                end select

                ! Monster attacks
                call random_number(rr)
                if (rr * 100 > pc%evasion) then
                    e_mod = elem_modifier(mon_element, pc%element)
                    if (pc%job == JOB_HOPPANG) then
                        m_dmg = max(1, int(real(cur_m_atk) * e_mod) - (pc%base_def + pc%armor%def + set_def + (pc%skill_points/3)*2))
                    else
                        m_dmg = max(1, int(real(cur_m_atk) * e_mod) - (pc%base_def + pc%armor%def + set_def))
                    end if
                    call random_number(rr2)
                    if (pc%pet%active .and. pc%pet%hp > 0 .and. rr2 < 0.5) then
                        pc%pet%hp = pc%pet%hp - m_dmg
                        if (pc%pet%hp < 0) pc%pet%hp = 0
                        write(msg, '("펫이 대신 맞았다! 펫 HP -", I3, " (남은: ", I3, ")")') m_dmg, pc%pet%hp
                        if (pc%pet%hp == 0) then
                            pc%pet%active = .false.
                            write(msg, '(A, " 의 공격! 펫이 쓰러졌다!")') trim(e_name)
                        end if
                    else
                        pc%hp = pc%hp - m_dmg
                        write(msg, '(A, " 의 공격! ", I4, " 데미지!")') trim(e_name), m_dmg
                    end if
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 2, 2, trim(msg), 2)
                    call delay(0.5)
                else
                    write(msg, '(A, " 의 공격을 회피했다!")') trim(e_name)
                    call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 0, 2, trim(msg))
                    call delay(0.4)
                end if
            end if
        end do

        if (fled) return

        if (m_hp <= 0) then
            pc%gold = pc%gold + m_gold
            pc%xp   = pc%xp + m_xp
            if (pc%job == JOB_MANY) pc%gold = pc%gold + m_gold / 2
            write(msg, '("승리! Gold +", I4, "  EXP +", I3)') m_gold, m_xp
            call draw_combat_scene(pc, e_name, 0, m_max_hp, mon_id, 0, 1, trim(msg))
            call delay(0.5)
            call wait_for_enter()
            call check_level_up(pc)
            ! Record monster kill in encyclopedia
            if (mon_id >= 1 .and. mon_id <= 24) then
                pc%mon_seen(mon_id) = 1
            end if
            ! Check encyclopedia completion
            if (sum(pc%mon_seen) >= 24) then
                call show_dialogue_box("도감 완성!", "모든 몬스터를 처치했습니다! 보상: Gold +5000G", "")
                pc%gold = pc%gold + 5000
                pc%mon_seen = 0
                call wait_for_enter()
            end if
            ! Pet gains XP
            if (pc%pet%active) then
                pc%pet%xp = pc%pet%xp + m_xp / 5
                call check_pet_level_up(pc)
            end if
            ! Check NG+ (final boss of final region)
            if (pc%current_region == MAX_REGION .and. present(is_boss)) then
                if (is_boss) call check_ng_plus(pc)
            end if
            result = 1
        else if (pc%hp <= 0) then
            pc%hp = 1
            pc%status = STATUS_NORMAL
            pc%status_turns = 0
            call draw_combat_scene(pc, e_name, m_hp, m_max_hp, mon_id, 2, 0, "쓰러졌다... HP 1로 회복 후 귀환합니다.")
            call delay(0.8)
            call wait_for_enter()
            result = 0
        end if
    end subroutine event_combat

    subroutine scene_explore_choice(pc)
        type(character_t), intent(inout) :: pc
        character(len=30) :: e_name
        integer :: m_max_hp, m_atk, m_def, m_xp, m_gold
        integer :: tier, mon_id, mon_element, mon_speed, result, cont_choice, evt_choice
        integer :: region_choice, i, merch_choice
        logical :: is_boss, do_combat
        real :: rr

        ! Region selection
        call clear_screen()
        write(*,'(A)')"  지역을 선택하세요:"
        do i = 1, pc%unlocked_region
            write(*,'("  (", I2, ") 지역 ", I2, " - [티어", I1, "]")') i, i, (i-1)/4+1
        end do
        call safe_read(region_choice)
        if (region_choice < 1 .or. region_choice > pc%unlocked_region) region_choice = pc%current_region
        pc%current_region = region_choice

        tier = (pc%current_region - 1) / 4 + 1

        call show_stage_story(pc%current_region, pc%current_stage, .false.)

        do
            is_boss = (mod(pc%current_stage, 5) == 0)

            if (pc%current_stage == 3 .or. is_boss) then
                call show_stage_story(pc%current_region, pc%current_stage, is_boss)
            end if

            do_combat = .true.

            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
            write(*, '("  ║  탐험 중 - 지역 ", I2, " 스테이지 ", I2, T55, "║")') pc%current_region, pc%current_stage
            write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
            write(*,'(A)')"  ║  앞에 세 갈래 길이 펼쳐진다...                       ║"
            write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"

            if (tier <= 2) then
                write(*,'(A)')"  [길1: 숲길]   [길2: 폐허]   [길3: 냇물]   [길4: 상인]   [길5: 야영]"
                write(*,'(A)')"    .  .  .       _______        ~~~~~         @@@@@          /\"
                write(*,'(A)')"   /|\  /|\      |  ___  |       ~~~~~        @  .  @        /  \"
                write(*,'(A)')"   /|\  /|\      | |_  | |    ~~~_____~~~    @   .   @      / /\ \"
                write(*,'(A)')"  ~~~~  ~~~~     |_______|   ~~~/ fish\~~~   @@@@@@@      /~~~~~~\"
                write(*,'(A)')""
                write(*,'(A)')"  (1) 울창한 숲길   - 일반 전투 (안전, XP/Gold 표준)"
                write(*,'(A)')"  (2) 폐허 건물     - 함정 위험 but 보물/아이템 확률UP"
                write(*,'(A)')"  (3) 냇물 따라가기 - 전투 없이 HP+MP 회복 가능"
                write(*,'(A)')"  (4) 행상인 만남   - 50G로 랜덤 아이템 or 무료 통과"
                write(*,'(A)')"  (5) 야영지 발견   - HP 30% 회복 + 상태이상 치료"
                write(*,'(A)')"  (9) 지도 보기  (0) 메인으로 돌아가기"
                call safe_read(evt_choice)
                if (evt_choice == 9) then
                    call draw_text_map(pc)
                    call wait_for_enter()
                    cycle
                end if
                if (evt_choice == 0) return
                select case(evt_choice)
                case(1)
                    call show_dialogue_box("숲길", "울창한 숲 속으로 발을 내딛는다...", "적의 소리가 들린다!")
                    call wait_for_enter()
                case(2)
                    call random_number(rr)
                    if (rr < 0.2) then
                        call show_dialogue_box("함정!", "함정 발동! 적이 강화되어 나타났다! HP -15%", "")
                        pc%hp = max(1, pc%hp - pc%max_hp * 15 / 100)
                        call wait_for_enter()
                        ! combat with boosted m_atk handled after get_monster_data
                        call get_monster_data(pc%current_region, pc%current_stage, &
                            e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, ng_plus=pc%ng_plus)
                        m_atk = m_atk * 120 / 100
                        call event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result)
                        if (result == 0) then
                            call show_dialogue_box("패배", "쓰러졌습니다. 거점으로 귀환합니다.", "")
                            call wait_for_enter(); return
                        else if (result == 2) then
                            call show_dialogue_box("도주", "전장에서 벗어났습니다.", "")
                            call wait_for_enter(); return
                        end if
                        do_combat = .false.
                    else if (rr < 0.5) then
                        call show_dialogue_box("보물 발견!", "폐허에서 골드를 발견했다! +100G", "")
                        pc%gold = pc%gold + 100
                        call wait_for_enter()
                        do_combat = .false.
                    else if (rr < 0.75) then
                        call show_dialogue_box("유물 발견!", "폐허에서 희귀 유물을 발견했다!", "")
                        call add_to_inventory(pc, "폐허 유물", 35, TYPE_WEAPON, GRADE_RARE, 300)
                        call wait_for_enter()
                        do_combat = .false.
                    else
                        call show_dialogue_box("폐허", "폐허를 탐색하다 적을 만났다!", "")
                        call wait_for_enter()
                    end if
                case(3)
                    call random_number(rr)
                    if (rr < 0.4) then
                        pc%hp = min(pc%max_hp, pc%hp + pc%max_hp * 30 / 100)
                        pc%mp = pc%max_mp
                        call show_dialogue_box("냇물 휴식", "냇물가에서 쉬며 HP+30% MP 완전 회복!", "")
                        call wait_for_enter()
                        do_combat = .false.
                    else if (rr < 0.7) then
                        pc%mp = pc%max_mp
                        call show_dialogue_box("냇물 휴식", "냇물가에서 쉬며 MP 완전 회복!", "")
                        call wait_for_enter()
                        do_combat = .false.
                    else
                        call show_dialogue_box("냇물 전투", "냇물에서 적을 만났다! 지형 보너스: 회피+10%", "")
                        call wait_for_enter()
                        pc%evasion = pc%evasion + 10
                        call get_monster_data(pc%current_region, pc%current_stage, &
                            e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, ng_plus=pc%ng_plus)
                        call event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result)
                        pc%evasion = pc%evasion - 10
                        if (result == 0) then
                            call show_dialogue_box("패배", "쓰러졌습니다. 거점으로 귀환합니다.", "")
                            call wait_for_enter(); return
                        else if (result == 2) then
                            call show_dialogue_box("도주", "전장에서 벗어났습니다.", "")
                            call wait_for_enter(); return
                        end if
                        do_combat = .false.
                    end if
                case(4)
                    write(*,'(A)')"  행상인이 아이템을 팔고 있다!"
                    write(*,'(A)')"  (1) 50G 지불하여 아이템 구매  (2) 그냥 지나가기"
                    call safe_read(merch_choice)
                    if (merch_choice == 1) then
                        if (pc%gold >= 50) then
                            pc%gold = pc%gold - 50
                            call add_to_inventory(pc, "행상인 아이템", 40, TYPE_WEAPON, GRADE_RARE, 250)
                            call show_dialogue_box("구매 완료", "행상인에게서 아이템을 구매했다! -50G", "")
                            call wait_for_enter()
                        else
                            call show_dialogue_box("골드 부족!", "골드가 부족하다! 행상인이 화가 났다!", "전투 발생!")
                            call wait_for_enter()
                            ! fall through to combat
                            call show_dialogue_box("전투", "화가 난 행상인과 싸운다!", "")
                            call wait_for_enter()
                        end if
                    else
                        call show_dialogue_box("통과", "행상인 옆을 그냥 지나갔다.", "")
                        call wait_for_enter()
                        do_combat = .false.
                    end if
                case(5)
                    pc%hp = min(pc%max_hp, pc%hp + pc%max_hp * 30 / 100)
                    pc%status = STATUS_NORMAL
                    pc%status_turns = 0
                    call show_dialogue_box("야영지", "야영지에서 HP 30% 회복! 상태이상 치료!", "EXP 페널티 적용 (이 전투 EXP -20%)")
                    call wait_for_enter()
                    do_combat = .false.
                case default
                    call show_dialogue_box("숲길", "숲 속으로 발을 내딛는다...", "")
                    call wait_for_enter()
                end select

            else if (tier <= 4) then
                write(*,'(A)')"  [길1: 해안]  [길2: 난파선]  [길3: 어부]  [길4: 동굴]  [길5: 등대]"
                write(*,'(A)')"   ~  ~  ~      /\___/\        __|__        /\            |*|"
                write(*,'(A)')"  ~~ocean~~    / SHIP  \       / . \       /  \           |*|"
                write(*,'(A)')"   ~  ~  ~    /________\      (_____)     / /\ \         _|_|_"
                write(*,'(A)')"  ~~~~~~~~~~  |        |      |___|_|    /_/  \_\        |   |"
                write(*,'(A)')""
                write(*,'(A)')"  (1) 해안을 따라 이동  - 일반 전투"
                write(*,'(A)')"  (2) 난파선 조사       - 아이템 발견 or 강적 등장"
                write(*,'(A)')"  (3) 마을 어부와 대화  - HP 회복 + 힌트"
                write(*,'(A)')"  (4) 해안 동굴 탐험    - 고위험 고보상"
                write(*,'(A)')"  (5) 등대에서 휴식     - HP+MP 50% 회복, 상태이상 치료"
                write(*,'(A)')"  (9) 지도 보기  (0) 메인으로 돌아가기"
                call safe_read(evt_choice)
                if (evt_choice == 9) then
                    call draw_text_map(pc)
                    call wait_for_enter()
                    cycle
                end if
                if (evt_choice == 0) return
                select case(evt_choice)
                case(1)
                    call show_dialogue_box("해안", "해안을 따라 이동 중 적을 만났다!", "")
                    call wait_for_enter()
                case(2)
                    call random_number(rr)
                    if (rr < 0.35) then
                        call show_dialogue_box("보물!", "난파선에서 보물을 발견했다!", "")
                        call add_to_inventory(pc, "난파선 보물", 30, TYPE_WEAPON, GRADE_RARE, 200)
                        call wait_for_enter()
                        do_combat = .false.
                    else
                        call show_dialogue_box("강적!", "난파선에서 강한 적이 나타났다! 공격력 +50%", "")
                        call wait_for_enter()
                        call get_monster_data(pc%current_region, pc%current_stage, &
                            e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, ng_plus=pc%ng_plus)
                        m_atk = m_atk * 150 / 100
                        call event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result)
                        if (result == 0) then
                            call show_dialogue_box("패배", "쓰러졌습니다. 거점으로 귀환합니다.", "")
                            call wait_for_enter(); return
                        else if (result == 2) then
                            call show_dialogue_box("도주", "전장에서 벗어났습니다.", "")
                            call wait_for_enter(); return
                        end if
                        do_combat = .false.
                    end if
                case(3)
                    pc%hp = min(pc%max_hp, pc%hp + 20)
                    call show_dialogue_box("어부 힌트", "어부가 HP를 회복시켜 주었다. HP+20", "이 지역 몬스터는 물 속성이다!")
                    call wait_for_enter()
                    do_combat = .false.
                case(4)
                    call show_dialogue_box("동굴!", "해안 동굴에서 강력한 적이 나타났다! 보상 +200G!", "")
                    call wait_for_enter()
                    call get_monster_data(pc%current_region, pc%current_stage, &
                        e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, ng_plus=pc%ng_plus)
                    m_max_hp = m_max_hp * 2
                    m_atk = m_atk * 3 / 2
                    call event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result)
                    if (result == 1) then
                        pc%gold = pc%gold + 200
                        call show_dialogue_box("보상!", "동굴 탐험 성공! Gold +200G!", "")
                        call wait_for_enter()
                    else if (result == 0) then
                        call show_dialogue_box("패배", "쓰러졌습니다. 거점으로 귀환합니다.", "")
                        call wait_for_enter(); return
                    else if (result == 2) then
                        call show_dialogue_box("도주", "전장에서 벗어났습니다.", "")
                        call wait_for_enter(); return
                    end if
                    do_combat = .false.
                case(5)
                    pc%hp  = min(pc%max_hp, pc%hp  + pc%max_hp / 2)
                    pc%mp  = min(pc%max_mp, pc%mp  + pc%max_mp / 2)
                    pc%status = STATUS_NORMAL
                    pc%status_turns = 0
                    call show_dialogue_box("등대 휴식", "등대에서 HP+MP 50% 회복! 상태이상 치료!", "")
                    call wait_for_enter()
                    do_combat = .false.
                case default
                    call show_dialogue_box("해안", "해안을 따라 이동한다...", "")
                    call wait_for_enter()
                end select

            else
                write(*,'(A)')"  [길1: 어둠]  [길2: 신전]   [길3: 영혼]  [길4: 결계]  [길5: 오아시스]"
                write(*,'(A)')"  ########     /\     /\     .  *  .      ###===###     *  *  *"
                write(*,'(A)')"  # dark #    /  \   /  \   * ghost *     # ~~~ #      * oasis*"
                write(*,'(A)')"  ########   / /\ \ / /\ \   .  *  .     ###===###     *  *  *"
                write(*,'(A)')"  ########  /_/  \_X_/  \_\  .  .  .     |     |      ~~water~~"
                write(*,'(A)')""
                write(*,'(A)')"  (1) 어둠 속으로       - 일반 전투 (어둠 속성 몬스터)"
                write(*,'(A)')"  (2) 고대 신전 탐험    - 상태이상 위험, 보물 보상"
                write(*,'(A)')"  (3) 영혼과 대화       - 힌트/이야기 or 특수 전투"
                write(*,'(A)')"  (4) 마법 결계 통과    - MP 50 소모 or 강제 전투"
                write(*,'(A)')"  (5) 심연의 오아시스   - HP+MP 완전 회복, 상태이상 치료"
                write(*,'(A)')"  (9) 지도 보기  (0) 메인으로 돌아가기"
                call safe_read(evt_choice)
                if (evt_choice == 9) then
                    call draw_text_map(pc)
                    call wait_for_enter()
                    cycle
                end if
                if (evt_choice == 0) return
                select case(evt_choice)
                case(1)
                    call show_dialogue_box("어둠", "어둠 속에서 적이 나타났다!", "")
                    call wait_for_enter()
                case(2)
                    call random_number(rr)
                    if (rr < 0.3) then
                        call show_dialogue_box("보물!", "신전에서 Gold +150G + 에픽 아이템 발견!", "")
                        pc%gold = pc%gold + 150
                        call add_to_inventory(pc, "신전 유물", 60, TYPE_WEAPON, GRADE_EPIC, 800)
                        call wait_for_enter()
                        do_combat = .false.
                    else if (rr < 0.6) then
                        pc%status = STATUS_POISON
                        call show_dialogue_box("함정!", "신전 함정! 독 상태이상 부여! 전투 발생!", "")
                        call wait_for_enter()
                    else
                        call show_dialogue_box("신전", "신전에서 적을 만났다!", "")
                        call wait_for_enter()
                    end if
                case(3)
                    call random_number(rr)
                    if (rr < 0.5) then
                        call show_dialogue_box("영혼의 말", "영혼이 귀중한 정보를 알려주었다.", "다음 지역의 보스는 에테르 속성이다!")
                        call wait_for_enter()
                        do_combat = .false.
                    else
                        call show_dialogue_box("영혼 전투!", "영혼이 적대적으로 변했다! 전투 발생!", "")
                        call wait_for_enter()
                    end if
                case(4)
                    if (pc%mp >= 50) then
                        pc%mp = pc%mp - 50
                        call show_dialogue_box("결계 통과", "MP 50을 소모하여 결계를 통과했다!", "")
                        call wait_for_enter()
                        do_combat = .false.
                    else
                        call show_dialogue_box("MP 부족!", "MP가 부족하여 결계를 통과할 수 없다!", "강제 전투 발생!")
                        call wait_for_enter()
                    end if
                case(5)
                    pc%hp = pc%max_hp
                    pc%mp = pc%max_mp
                    pc%status = STATUS_NORMAL
                    pc%status_turns = 0
                    call show_dialogue_box("오아시스", "심연의 오아시스에서 HP+MP 완전 회복!", "상태이상도 치료되었다!")
                    call wait_for_enter()
                    do_combat = .false.
                case default
                    call show_dialogue_box("어둠", "어둠 속으로 발을 내딛는다...", "")
                    call wait_for_enter()
                end select
            end if

            if (.not. do_combat) then
                ! No combat this cycle - just advance stage
                pc%current_stage = pc%current_stage + 1
                if (mod(pc%current_stage, 3) == 1 .and. pc%current_stage > 1) then
                    call clear_screen()
                    call show_main_status_ui(pc)
                    call show_dialogue_box("탐험 중", "잠시 숨을 돌립니다. 계속 진행하시겠습니까?", "(1) 계속 탐험    (2) 거점으로 귀환")
                    call safe_read(cont_choice)
                    if (cont_choice == 2) return
                end if
                cycle
            end if

            ! 15% chance of random NPC event before combat
            call random_number(rr)
            if (rr < 0.15) then
                call scene_random_npc(pc)
            end if
            call get_monster_data(pc%current_region, pc%current_stage, &
                                  e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, is_boss, mon_id, mon_element, mon_speed, &
                                  ng_plus=pc%ng_plus)
            call event_combat(pc, e_name, m_max_hp, m_atk, m_def, m_xp, m_gold, mon_id, mon_element, mon_speed, result, is_boss=is_boss)

            if (result == 0) then
                call show_dialogue_box("패배", "쓰러졌습니다. 거점으로 귀환합니다.", "체력을 회복하고 다시 도전하세요!")
                call wait_for_enter()
                return
            else if (result == 2) then
                call show_dialogue_box("도주", "전장에서 벗어났습니다.", "")
                call wait_for_enter()
                return
            end if

            if (is_boss) then
                call show_victory_story(pc%current_region, pc%current_stage, .true., pc)
                pc%unlocked_region = max(pc%unlocked_region, pc%current_region + 1)
                pc%current_region  = pc%current_region + 1
                pc%current_stage   = 1
                tier = (pc%current_region - 1) / 4 + 1
                call show_dialogue_box("지역 클리어!", "새로운 지역이 열렸습니다!", "계속 탐험하시겠습니까?")
                call wait_for_enter()
                return
            else
                pc%current_stage = pc%current_stage + 1
            end if

            if (mod(pc%current_stage, 3) == 1 .and. pc%current_stage > 1) then
                call clear_screen()
                call show_main_status_ui(pc)
                call show_dialogue_box("탐험 중", "잠시 숨을 돌립니다. 계속 진행하시겠습니까?", "(1) 계속 탐험    (2) 거점으로 귀환")
                call safe_read(cont_choice)
                if (cont_choice == 2) return
            end if
        end do
    end subroutine scene_explore_choice

    subroutine scene_explore(pc)
        type(character_t), intent(inout) :: pc
        call scene_explore_choice(pc)
    end subroutine scene_explore

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 5: Set Bonus
    ! ─────────────────────────────────────────────────────────────
    subroutine get_set_bonus(pc, bonus_atk, bonus_def, bonus_hp)
        type(character_t), intent(in) :: pc
        integer, intent(out) :: bonus_atk, bonus_def, bonus_hp
        bonus_atk = 0; bonus_def = 0; bonus_hp = 0
        if (pc%weapon%grade == pc%armor%grade) then
            select case(pc%weapon%grade)
            case(GRADE_COMMON);    bonus_atk=2;  bonus_def=2;  bonus_hp=10
            case(GRADE_RARE);      bonus_atk=5;  bonus_def=5;  bonus_hp=25
            case(GRADE_EPIC);      bonus_atk=12; bonus_def=10; bonus_hp=60
            case(GRADE_LEGENDARY); bonus_atk=25; bonus_def=20; bonus_hp=120
            case(GRADE_MYTHIC);    bonus_atk=50; bonus_def=40; bonus_hp=250
            end select
        end if
    end subroutine get_set_bonus

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 2: Pet Level Up / Evolution
    ! ─────────────────────────────────────────────────────────────
    subroutine pet_evolve(pc, stage)
        type(character_t), intent(inout) :: pc
        integer, intent(in) :: stage
        character(len=20) :: new_name
        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════╗"
        write(*,'(A)')"  ║  !!! 펫이 진화했습니다 !!!            ║"
        write(*,'(A)')"  ╠══════════════════════════════════════╣"
        if (stage == 1) then
            select case(trim(pc%pet%name))
            case("앉아있는작은새"); new_name = "날아오른작은새"
            case("새헤이만");       new_name = "헤이만새"
            case("윤현식");         new_name = "강화된윤현식"
            case("닭헤이만");       new_name = "전투닭헤이만"
            case("전틍");           new_name = "초월전틍"
            case default;           new_name = pc%pet%name
            end select
        else
            select case(trim(pc%pet%name))
            case("날아오른작은새"); new_name = "신성한수호새"
            case("헤이만새");       new_name = "전설헤이만새"
            case("강화된윤현식");   new_name = "최강윤현식"
            case("전투닭헤이만");   new_name = "불사조닭헤이만"
            case("초월전틍");       new_name = "신화전틍"
            case default;           new_name = pc%pet%name
            end select
        end if
        write(*, '("  ║  ", A15, " -> ", A15)') trim(pc%pet%name), trim(new_name)
        pc%pet%name = new_name
        pc%pet%max_hp = pc%pet%max_hp + 30
        pc%pet%hp = pc%pet%max_hp
        pc%pet%atk = pc%pet%atk + 20
        write(*,'(A)')"  ║  MAX_HP +30  ATK +20  전진형 진화!   ║"
        write(*,'(A)')"  ╚══════════════════════════════════════╝"
    end subroutine pet_evolve

    subroutine check_pet_level_up(pc)
        type(character_t), intent(inout) :: pc
        do while (pc%pet%active .and. pc%pet%xp >= pc%pet%next_xp)
            pc%pet%xp = pc%pet%xp - pc%pet%next_xp
            pc%pet%level = pc%pet%level + 1
            pc%pet%next_xp = int(pc%pet%next_xp * 1.4) + 30
            pc%pet%max_hp = pc%pet%max_hp + 15
            pc%pet%hp = pc%pet%max_hp
            pc%pet%atk = pc%pet%atk + 8
            call clear_screen()
            write(*,'(A)')"  ╔══════════════════════════════════════╗"
            write(*,'(A)')"  ║  ★  펫 레벨업!  ★                   ║"
            write(*,'(A)')"  ╠══════════════════════════════════════╣"
            write(*, '("  ║  ", A15, " Lv.", I2, " -> Lv.", I2)') &
                trim(pc%pet%name), pc%pet%level-1, pc%pet%level
            write(*,'(A)')"  ║  MAX_HP +15  ATK +8  HP 완전 회복!  ║"
            write(*,'(A)')"  ╚══════════════════════════════════════╝"
            if (pc%pet%level == 5) then
                call pet_evolve(pc, 1)
            else if (pc%pet%level == 10) then
                call pet_evolve(pc, 2)
            end if
            call wait_for_enter()
        end do
    end subroutine check_pet_level_up

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 3: Item Crafting
    ! ─────────────────────────────────────────────────────────────
    subroutine scene_crafting(pc)
        type(character_t), intent(inout) :: pc
        integer :: slot1, slot2, i
        character(len=30) :: iname
        integer :: ival, idef, igrade, iprice, itype

        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║         아이템 합성                                   ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║  같은 종류 + 같은 등급 아이템 2개 -> 상위 등급!      ║"
        write(*,'(A)')"  ║  신화 등급은 합성 불가.                               ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║  인벤토리:                                            ║"
        do i = 1, INV_SIZE
            if (trim(pc%inventory(i)%name) /= "---") then
                write(*, '("  ║  [", I2, "] ", A18, " 등급:", I1, " 종류:", I1)') &
                    i, trim(pc%inventory(i)%name), pc%inventory(i)%grade, pc%inventory(i)%itype
            end if
        end do
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*,'(A)')"  첫 번째 아이템 번호 (0=취소):"
        call safe_read(slot1)
        if (slot1 == 0) return
        if (slot1 < 1 .or. slot1 > INV_SIZE) return
        if (trim(pc%inventory(slot1)%name) == "---") then
            write(*,'(A)')"  [!] 빈 슬롯입니다."; call wait_for_enter(); return
        end if
        if (pc%inventory(slot1)%grade >= GRADE_MYTHIC) then
            write(*,'(A)')"  [!] 신화 등급은 합성 불가."; call wait_for_enter(); return
        end if
        write(*,'(A)')"  두 번째 아이템 번호 (0=취소):"
        call safe_read(slot2)
        if (slot2 == 0) return
        if (slot2 < 1 .or. slot2 > INV_SIZE .or. slot2 == slot1) return
        if (trim(pc%inventory(slot2)%name) == "---") then
            write(*,'(A)')"  [!] 빈 슬롯입니다."; call wait_for_enter(); return
        end if
        if (pc%inventory(slot1)%itype /= pc%inventory(slot2)%itype .or. &
            pc%inventory(slot1)%grade /= pc%inventory(slot2)%grade) then
            write(*,'(A)')"  [!] 같은 종류 + 같은 등급 아이템만 합성 가능합니다."
            call wait_for_enter(); return
        end if
        itype  = pc%inventory(slot1)%itype
        igrade = pc%inventory(slot1)%grade + 1
        if (itype == TYPE_WEAPON) then
            call get_weapon_by_idx((igrade-1)*6+1, iname, ival, igrade, iprice)
        else
            call get_armor_by_idx((igrade-1)*6+1, iname, ival, idef, igrade, iprice)
        end if
        pc%inventory(slot1)%name="---"; pc%inventory(slot1)%itype=0
        pc%inventory(slot1)%value=0; pc%inventory(slot1)%grade=0
        pc%inventory(slot1)%price=0; pc%inventory(slot1)%count=0
        pc%inventory(slot2)%name="---"; pc%inventory(slot2)%itype=0
        pc%inventory(slot2)%value=0; pc%inventory(slot2)%grade=0
        pc%inventory(slot2)%price=0; pc%inventory(slot2)%count=0
        pc%inv_count = pc%inv_count - 2
        call add_to_inventory(pc, iname, ival, itype, igrade, iprice)
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║  합성 성공!                                           ║"
        write(*, '("  ║  -> ", A25, " (등급:", I1, ")")') trim(iname), igrade
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
        call wait_for_enter()
    end subroutine scene_crafting

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 4: Random NPC Events
    ! ─────────────────────────────────────────────────────────────
    subroutine scene_random_npc(pc)
        type(character_t), intent(inout) :: pc
        real :: rr
        integer :: npc_type, opt
        call random_number(rr)
        npc_type = int(rr * 3) + 1

        call clear_screen()
        select case(npc_type)
        case(1)
            write(*,'(A)')"  ┌──────────────────────────────────────────────┐"
            write(*,'(A)')"  │  [이벤트] 지친 여행자를 만났다!               │"
            write(*,'(A)')"  │                                               │"
            write(*,'(A)')"  │   (o_o)  여행자: 이 길은 위험하오...         │"
            write(*,'(A)')"  │   /||\   포션 하나를 드리리다.                │"
            write(*,'(A)')"  │   / \                                         │"
            write(*,'(A)')"  │  (1) 감사히 받는다.  (2) 괜찮다고 한다.      │"
            write(*,'(A)')"  └──────────────────────────────────────────────┘"
            call safe_read(opt)
            if (opt == 1) then
                pc%hp_potions = pc%hp_potions + 1
                call show_dialogue_box("여행자", "HP 포션을 받았다! (+1)", "")
            else
                call show_dialogue_box("여행자", "여행자가 고개를 끄덕이며 떠났다.", "")
            end if
        case(2)
            write(*,'(A)')"  ┌──────────────────────────────────────────────┐"
            write(*,'(A)')"  │  [이벤트] 수상한 행상인을 만났다!             │"
            write(*,'(A)')"  │                                               │"
            write(*,'(A)')"  │   ($.$)  상인: 특별한 물건이 있소이다...     │"
            write(*,'(A)')"  │  /[bag]\  (1) 30G에 랜덤 아이템 구매          │"
            write(*,'(A)')"  │           (2) 그냥 지나친다.                  │"
            write(*,'(A)')"  └──────────────────────────────────────────────┘"
            call safe_read(opt)
            if (opt == 1) then
                if (pc%gold >= 30) then
                    pc%gold = pc%gold - 30
                    call add_to_inventory(pc, "상인의 보따리", 25, TYPE_WEAPON, GRADE_RARE, 150)
                    call show_dialogue_box("행상인", "거래 완료! 아이템을 인벤토리에 넣었다.", "")
                else
                    call show_dialogue_box("행상인", "골드가 부족하다! 상인이 실망하며 떠났다.", "")
                end if
            end if
        case default
            write(*,'(A)')"  ┌──────────────────────────────────────────────┐"
            write(*,'(A)')"  │  [이벤트] 수수께끼 노인을 만났다!             │"
            write(*,'(A)')"  │                                               │"
            write(*,'(A)')"  │   (-.-)  노인: 자네에게 힘을 나눠주겠네.     │"
            write(*,'(A)')"  │   /||\   고난 앞에서 포기하지 말게나.        │"
            write(*,'(A)')"  │  (1) 배움을 청한다. (skill_points +1)        │"
            write(*,'(A)')"  │  (2) 힘을 빌린다.   (HP+MP 완전 회복)        │"
            write(*,'(A)')"  └──────────────────────────────────────────────┘"
            call safe_read(opt)
            select case(opt)
            case(1)
                pc%skill_points = pc%skill_points + 1
                call show_dialogue_box("수수께끼 노인", "스킬 포인트 +1! 지혜를 얻었다.", "")
            case(2)
                pc%hp = pc%max_hp; pc%mp = pc%max_mp
                call show_dialogue_box("수수께끼 노인", "HP와 MP가 완전 회복되었다!", "")
            end select
        end select
        call wait_for_enter()
    end subroutine scene_random_npc

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 7: NG+ Check
    ! ─────────────────────────────────────────────────────────────
    subroutine check_ng_plus(pc)
        type(character_t), intent(inout) :: pc
        integer :: opt
        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║          ★★★  게임 클리어!!!  ★★★                               ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════════════════╣"
        write(*,'(A)')"  ║  카오스를 물리치고 세계를 구했습니다!                             ║"
        write(*,'(A)')"  ║                                                                  ║"
        write(*,'(A)')"  ║  [NG+ 모드]  더 강해진 적들과 함께 다시 도전하시겠습니까?       ║"
        write(*,'(A)')"  ║  레벨, 아이템, 골드는 유지됩니다.                                ║"
        write(*,'(A)')"  ║                                                                  ║"
        write(*,'(A)')"  ║  (1) NG+ 시작  (2) 일반 모드 계속                               ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════════════════╝"
        call safe_read(opt)
        if (opt == 1) then
            pc%ng_plus = pc%ng_plus + 1
            pc%current_region = 1
            pc%current_stage  = 1
            pc%unlocked_region = 1
            write(*,'(A)')"  [NG+] 세계가 다시 위기에 빠졌습니다..."
            write(*, '("  [NG+", I1, "] 몬스터 능력치 ", I3, "% 강화!")') &
                pc%ng_plus, 20 * pc%ng_plus
            call wait_for_enter()
        end if
    end subroutine check_ng_plus

    ! ─────────────────────────────────────────────────────────────
    ! SYSTEM 9: Special Stock
    ! ─────────────────────────────────────────────────────────────
    subroutine scene_special_stock(pc)
        type(character_t), intent(inout) :: pc
        integer :: tier, idx1, idx3, choice
        integer :: w_atk, w_grade, w_price, a_hp, a_def, a_grade, a_price
        character(len=30) :: w_name, a_name
        tier = (pc%current_region - 1) / 4 + 1
        idx1 = tier * 4 - 1
        idx3 = tier * 4 - 1
        if (idx1 > 30) idx1 = 30
        if (idx3 > 30) idx3 = 30
        call get_weapon_by_idx(idx1, w_name, w_atk, w_grade, w_price)
        call get_armor_by_idx(idx3, a_name, a_hp, a_def, a_grade, a_price)
        w_price = int(w_price * 1.2)
        a_price = int(a_price * 1.2)

        call clear_screen()
        write(*,'(A)')"  ╔══════════════════════════════════════════════════════╗"
        write(*,'(A)')"  ║         특별 재고  (지역 한정)                        ║"
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*, '("  ║  현재 지역: ", I2, "  티어: ", I1)') pc%current_region, tier
        write(*,'(A)')"  ╠══════════════════════════════════════════════════════╣"
        write(*, '("  ║  (1) 무기: ", A20, " ATK+", I4)') trim(w_name), w_atk
        write(*, '("  ║      가격: ", I6, "G")') w_price
        write(*,'(A)')"  ║  ─────────────────────────────────────────────────  ║"
        write(*, '("  ║  (2) 방어구: ", A20, " HP+", I4)') trim(a_name), a_hp
        write(*, '("  ║      가격: ", I6, "G")') a_price
        write(*,'(A)')"  ║  (0) 나가기                                          ║"
        write(*,'(A)')"  ╚══════════════════════════════════════════════════════╝"
        call safe_read(choice)
        select case(choice)
        case(1)
            if (pc%gold >= w_price) then
                pc%gold = pc%gold - w_price
                call add_to_inventory(pc, w_name, w_atk, TYPE_WEAPON, w_grade, w_price)
                write(*,'(A)')"  [+] 구매 완료!"
            else
                write(*,'(A)')"  [!] 골드가 부족합니다."
            end if
            call wait_for_enter()
        case(2)
            if (pc%gold >= a_price) then
                pc%gold = pc%gold - a_price
                call add_to_inventory(pc, a_name, a_hp, TYPE_ARMOR, a_grade, a_price)
                write(*,'(A)')"  [+] 구매 완료!"
            else
                write(*,'(A)')"  [!] 골드가 부족합니다."
            end if
            call wait_for_enter()
        end select
    end subroutine scene_special_stock

end module game_logic
