module game_types
    implicit none
    ! --- 수정 가능 상수 ---
    integer, parameter :: INV_SIZE = 15
    integer, parameter :: MAX_REGION = 24
    
    integer, parameter :: JOB_MANY = 1, JOB_HOPPANG = 2, JOB_MILK = 3, JOB_JJABDAM = 4, JOB_JISAY = 5
    integer, parameter :: TYPE_WEAPON = 1, TYPE_ARMOR = 2
    integer, parameter :: GRADE_COMMON = 1, GRADE_RARE = 2, GRADE_EPIC = 3, GRADE_LEGENDARY = 4, GRADE_MYTHIC = 5

    type :: weapon_t
        character(len=30) :: name; integer :: atk, grade, price
    end type weapon_t

    type :: armor_t
        character(len=30) :: name; integer :: hp_bonus, grade, price
    end type armor_t

    type :: item_t
        character(len=30) :: name; integer :: type, value, grade, price, count
    end type item_t

    type :: character_t
        character(len=20) :: name; integer :: job, level, xp, next_xp, hp, max_hp, gold, base_atk, evasion, potions
        type(weapon_t) :: weapon; type(armor_t) :: armor; type(item_t) :: inventory(INV_SIZE)
        integer :: inv_count, current_region, current_stage, unlocked_region, inn_usage
    end type character_t
end module game_types
