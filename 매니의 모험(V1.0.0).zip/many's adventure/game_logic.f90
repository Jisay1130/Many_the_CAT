module game_logic
    use game_types
    use game_utils
    use game_graphics
    use game_items
    implicit none

    contains

    subroutine show_dialogue(speaker, text_msg)
        character(len=*), intent(in) :: speaker, text_msg
        call clear_screen()
        print *, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '(" ┃  ", A15, T70, "┃")') speaker
        print *, "┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫"
        write(*, '(" ┃  """, A60, """  ┃")') text_msg
        print *, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
        call wait_for_enter()
    end subroutine show_dialogue

    subroutine scene_shop(pc)
        type(character_t), intent(inout) :: pc
        integer :: choice, sub, roll, i, it, iv, ig, ip
        character(len=30) :: in
        do
            call clear_screen()
            print *, "┏━━━━━━━━━━━━━━━━━━━━━ V I L L A G E   S H O P ━━━━━━━━━━━━━━━━━━━━━┓"
            print *, "┃                                                                   ┃"
            print *, "┃  (1) 아이템 뽑기 (Gacha) - 100G                                   ┃"
            print *, "┃  (2) 아이템 판매 (Sell)                                           ┃"
            print *, "┃  (3) 아이템 강화 (Enhance) - 200G                                 ┃"
            print *, "┃  (4) 아이템 도감 (Encyclopedia)                                   ┃"
            print *, "┃  (5) 나가기 (Exit)                                                ┃"
            print *, "┃                                                                   ┃"
            print *, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
            write(*, '(" 선택: ")', advance='no'); read *, choice
            if (choice == 5) exit

            select case (choice)
            case (1) ! 가차 로직
                if (pc%gold < 100) then; call show_dialogue("Shop", "골드가 부족합니다."); cycle; end if
                pc%gold = pc%gold - 100
                call random_number(roll_r); roll = int(roll_r * 100)
                if (roll < 1) then; ig=5; else if (roll < 5) then; ig=4; else if (roll < 15) then; ig=3; else if (roll < 40) then; ig=2; else; ig=1; end if
                call random_number(roll_r); i = int(roll_r * 10) + 1
                call random_number(roll_r); call get_item_data(roll_r > 0.5, i, in, iv, ig, ip)
                call add_to_inventory(pc, in, iv, roll_r > 0.5, ip)
                call show_dialogue("Shop", trim(in) // "을(를) 획득했습니다!")
            case (4) ! 도감
                call scene_encyclopedia()
            end select
        end do
        contains
            real :: roll_r
    end subroutine scene_shop

    subroutine scene_encyclopedia()
        integer :: i, v, g, p; character(len=30) :: n
        do i = 1, 10
            call clear_screen()
            print *, "--- 아이템 도감 (무기 ", i, "/10) ---"
            call get_item_data(.true., i, n, v, g, p)
            call draw_item_art(n)
            write(*, '(" 이름: ", A20, " | 공격력: ", I3, " | 등급: ", I1)') n, v, g
            call wait_for_enter()
        end do
    end subroutine scene_encyclopedia

    subroutine show_inventory_box(pc)
        type(character_t), intent(in) :: pc; integer :: i
        call clear_screen()
        print *, "┏━━━━━━━━━━━━━━━━━━━━━ I N V E N T O R Y ━━━━━━━━━━━━━━━━━━━━━┓"
        do i = 1, INV_SIZE
            if (trim(pc%inventory(i)%name) == "---") then
                write(*, '(" ┃ [", I2, "] ( 비어 있음 )", T69, "┃")') i
            else
                write(*, '(" ┃ [", I2, "] ", A20, " (VAL:", I3, ")", T69, "┃")') i, pc%inventory(i)%name, pc%inventory(i)%value
            end if
        end do
        print *, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
        call wait_for_enter()
    end subroutine show_inventory_box

    subroutine add_to_inventory(pc, n, v, is_w, p)
        type(character_t), intent(inout) :: pc; character(len=*), intent(in) :: n; integer, intent(in) :: v, p; logical, intent(in) :: is_w
        integer :: i; do i = 1, INV_SIZE
            if (pc%inventory(i)%name == "---") then
                pc%inventory(i)%name = n; pc%inventory(i)%value = v; pc%inventory(i)%price = p
                if (is_w) then; pc%inventory(i)%type = 1; else; pc%inventory(i)%type = 2; end if
                return
            end if
        end do
    end subroutine add_to_inventory
end module game_logic
