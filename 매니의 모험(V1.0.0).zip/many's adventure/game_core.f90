module game_types
    implicit none
    integer, parameter :: JOB_MANY = 1, JOB_MILK = 2, JOB_HOPPANG = 3, JOB_JJABDAM = 4, JOB_JISAY = 5
    integer, parameter :: GRADE_COMMON = 1, GRADE_RARE = 2, GRADE_EPIC = 3, GRADE_LEGENDARY = 4
    integer, parameter :: ITEM_MISC = 1, ITEM_POTION = 2
    type :: weapon_t
        character(len=30) :: name
        integer :: atk, grade, level, req_level, price
    end type weapon_t
    type :: armor_t
        character(len=30) :: name
        integer :: hp_bonus, eva_bonus, grade, req_level, price
    end type armor_t
    type :: item_t
        character(len=30) :: name
        integer :: type, value, count, price
    end type item_t
    type :: character_t
        character(len=20) :: name
        integer :: job, level, xp, next_xp, hp, max_hp, gold, base_atk, evasion, potions
        type(weapon_t) :: weapon
        type(armor_t) :: armor
        type(item_t) :: inventory(10)
        integer :: inv_count, current_region, current_stage, unlocked_region, inn_usage
        logical :: gems(3), visited(24)
    end type character_t
end module game_types

module game_utils
    implicit none
    contains
    subroutine clear_screen()
        write(*, '(A)', advance='no') char(27)//'[H'//char(27)//'[2J'//char(27)//'[3J'
        call flush(6)
    end subroutine clear_screen
    subroutine delay(sec)
        real, intent(in) :: sec; character(len=20) :: cmd; write(cmd, '("sleep ", F4.2)') sec; call execute_command_line(cmd)
    end subroutine delay
    subroutine wait_for_enter()
        character(len=1) :: temp; print *, "  [ Enter to proceed ]"; read(*, '(A)') temp
    end subroutine wait_for_enter
end module game_utils

module game_items
    use game_types
    implicit none
    contains
    subroutine get_weapon_data(grade, lv, w)
        integer, intent(in) :: grade, lv; type(weapon_t), intent(out) :: w
        select case (grade)
        case (GRADE_COMMON); w = weapon_t("무딘 철검", 30+lv*5, 1, 0, lv, 100)
        case (GRADE_RARE);   w = weapon_t("강철 롱소드", 70+lv*8, 2, 0, lv, 300)
        case (GRADE_EPIC);   w = weapon_t("암흑 파괴자", 150+lv*15, 3, 0, lv, 800)
        case (GRADE_LEGENDARY); w = weapon_t("신성한 엑스칼리버", 300+lv*30, 4, 0, lv, 2000)
        end select
    end subroutine get_weapon_data
    subroutine get_item_desc(name, desc)
        character(len=*), intent(in) :: name; character(len=100), intent(out) :: desc
        select case (trim(name))
        case ("무딘 철검"); desc = "녹슨 흔적이 가득한 평범한 철검입니다."
        case ("강철 롱소드"); desc = "제련된 강철검입니다. 튼튼합니다."
        case ("암흑 파괴자"); desc = "심연의 힘이 깃든 무시무시한 검입니다."
        case ("신성한 엑스칼리버"); desc = "전설적인 성검입니다. 빛이 뿜어져 나옵니다."
        case default; desc = "평범한 아이템입니다."
        end select
    end subroutine get_item_desc
end module game_items

module game_graphics
    use game_types
    use game_utils
    implicit none
    contains
    subroutine draw_item_icon(name)
        character(len=*), intent(in) :: name
        print *, "      _________"
        print *, "     /         \"
        print *, "     |  [ITEM]  |"
        print *, "     \_________/"
    end subroutine draw_item_icon
    subroutine draw_enemy_art(region, stage, frame)
        integer, intent(in) :: region, stage, frame; character(len=10) :: off
        if (mod(frame, 2) == 0) then; off = "    "; else; off = ""; end if
        write(*, '(A, T50, A, I2, A)') trim(off), "   [[ MEGA MONSTER LV.", stage, " ]]"
        write(*, '(A, T50, A)') trim(off), "        .___________.          "
        write(*, '(A, T50, A)') trim(off), "     /###################\      "
        write(*, '(A, T50, A)') trim(off), "    |###   ( @ )   ( @ )   ###| "
        write(*, '(A, T50, A)') trim(off), "     \###      _____      ###/  "
        write(*, '(A, T50, A)') trim(off), "       \###_____________###/   "
    end subroutine draw_enemy_art
    subroutine draw_player_art(pc, action, frame)
        type(character_t), intent(in) :: pc; integer, intent(in) :: action, frame; character(len=10) :: b_o, b_c, off
        if (mod(frame, 2) == 0) then; off = ""; else; off = "  "; end if
        select case (pc%armor%name); case ("미스릴 갑옷"); b_o="<["; b_c="]>"; case default; b_o="("; b_c=")"; end select
        if (action == 0) then; print *, trim(off), " (o o) ", b_o, "|", b_c, "===>"
        else; print *, " (O O) 💥SLASH!! ", b_o, "|", b_c, "-------===>"; end if
    end subroutine draw_player_art
    subroutine draw_battle_frame(pc, e_name, m_hp, frame, action)
        type(character_t), intent(in) :: pc; character(len=*), intent(in) :: e_name; integer, intent(in) :: m_hp, frame, action
        call clear_screen()
        print *, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━ STATS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
        write(*, '(" ┃ HP: ", I4, "/", I4, " | ATK: ", I3, " | G: ", I5, " ┃")') pc%hp, pc%max_hp, pc%base_atk + pc%weapon%atk, pc%gold
        print *, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
        write(*, '(" ", T50, "      [[ ", A15, " ]]")') e_name
        write(*, '(" ", T50, "      HEALTH: ", I4)') m_hp
        call draw_enemy_art((pc%current_region-1)/4, pc%current_stage, frame)
        print *, ""; print *, "      [ ", trim(pc%name), " ]"
        call draw_player_art(pc, action, frame)
        if (action == 0) then
            print *, "╔━━━━━━━━━━━━━━━━ ACTION ━━━━━━━━━━━━━━━━╗"
            print *, "┃ (1)공격 (2)도망 (3)포션 (4)대화 ┃"
            print *, "╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝"
        end if
    end subroutine draw_battle_frame
end module game_graphics

module game_logic
    use game_types; use game_utils; use game_items; use game_graphics
    implicit none
    contains
    subroutine check_level_up(pc)
        type(character_t), intent(inout) :: pc
        do while (pc%xp >= pc%next_xp)
            pc%level = pc%level + 1; pc%xp = pc%xp - pc%next_xp; pc%next_xp = int(pc%next_xp * 1.25) + 100
            pc%base_atk = pc%base_atk + 20; pc%max_hp = pc%max_hp + 30; pc%hp = pc%max_hp
        end do
    end subroutine check_level_up
    subroutine post_combat_story(pc, e_name)
        type(character_t), intent(inout) :: pc; character(len=*), intent(in) :: e_name; character(len=100) :: msg
        select case (pc%current_stage); case (1); msg = "이제 시작이야. 적을 해치웠어."; case (10); msg = "지역 보스를 격파했다!"; case default; msg = "전투 승리!"; end select
        call show_dialogue("전투 종료", msg)
    end subroutine post_combat_story
    subroutine event_combat(pc, e_name, is_boss)
        type(character_t), intent(inout) :: pc; character(len=*), intent(in) :: e_name; logical, intent(in) :: is_boss
        integer :: m_hp, m_atk, cmd, ios, frame; real :: r; logical :: escaped
        m_hp = 50 + (pc%current_region * 15); if (is_boss) m_hp = m_hp * 3; m_atk = 10 + (pc%current_region * 4); escaped = .false.; frame = 0
        do while (m_hp > 0 .and. pc%hp > 0 .and. .not. escaped)
            frame = frame + 1; call draw_battle_frame(pc, e_name, m_hp, frame, 0)
            write(*, '(" 선택: ")', advance='no'); read (*, *, iostat=ios) cmd
            if (ios /= 0) cycle
            if (cmd == 1) then; call draw_battle_frame(pc, e_name, m_hp, frame, 1); m_hp = m_hp - (pc%base_atk + pc%weapon%atk); call delay(0.4)
            else if (cmd == 2) then; escaped = .true.
            else if (cmd == 3 .and. pc%potions > 0) then; pc%potions = pc%potions - 1; pc%hp = min(pc%hp + 50, pc%max_hp)
            end if
            if (m_hp > 0 .and. .not. escaped) then; call random_number(r); if (r * 100 > pc%evasion) pc%hp = pc%hp - m_atk; end if; end do
        if (pc%hp > 0 .and. .not. escaped) then; pc%gold = pc%gold + 50; pc%xp = pc%xp + 60; call post_combat_story(pc, e_name)
            if (is_boss) then; pc%unlocked_region = max(pc%unlocked_region, pc%current_region+1); pc%current_stage = 1; pc%inn_usage = 0
            else; pc%current_stage = pc%current_stage + 1; end if; end if
    end subroutine event_combat
    subroutine create_character(pc)
        type(character_t), intent(out) :: pc; integer :: i, choice; do; call clear_screen()
            print *, " (1)매니 (2)우유 (3)호빵 (4)짭담이 (5)JISAY"
            write(*, '(" 직업 선택: ")', advance='no'); read *, choice; if (choice >= 1 .and. choice <= 5) exit; end do
        pc%job = choice; write(*, '(" 이름: ")', advance='no'); read *, pc%name
        pc%level = 1; pc%xp = 0; pc%next_xp = 100; pc%gold = 200; pc%potions = 3; pc%current_region = 1; pc%current_stage = 1; pc%unlocked_region = 1; pc%inn_usage = 0
        do i = 1, 10; pc%inventory(i)%name = "---"; end do
        select case (pc%job); case (1); pc%max_hp = 100; pc%base_atk = 50; case (2); pc%max_hp = 80; pc%base_atk = 95; case (3); pc%max_hp = 150; pc%base_atk = 35
        case (4); pc%max_hp = 90; pc%base_atk = 60; case (5); pc%max_hp = 200; pc%base_atk = 180; end select
        pc%hp = pc%max_hp; pc%weapon = weapon_t("낡은 검", 15, 1, 0, 1, 50); pc%armor = armor_t("천 옷", 20, 2, 1, 1, 30)
    end subroutine create_character
    subroutine open_inventory_with_graphics(pc)
        type(character_t), intent(in) :: pc; integer :: choice; character(len=100) :: desc
        do; call clear_screen(); print *, "--- INVENTORY ---"; do choice = 1, pc%inv_count; print *, "[", choice, "] ", pc%inventory(choice)%name; end do
            write(*, '(" 번호 (0:나가기): ")', advance='no'); read *, choice; if (choice == 0) exit
            if (choice > 0 .and. choice <= pc%inv_count) then; call draw_item_icon(pc%inventory(choice)%name); call get_item_desc(pc%inventory(choice)%name, desc); print *, trim(desc); call wait_for_enter(); end if; end do
    end subroutine open_inventory_with_graphics
    subroutine scene_village(pc)
        type(character_t), intent(inout) :: pc; integer :: choice, sub, roll; real :: r; type(weapon_t) :: w; character(len=100) :: desc
        do; call clear_screen(); print *, "--- 마을 --- (1)뽑기 (2)판매 (3)여관 (4)나가기"
            write(*, '(" 선택: ")', advance='no'); read *, choice
            if (choice == 1) then; write(*, '(" 뽑으시겠습니까? (1)네: ")', advance='no'); read *, sub
                if (sub == 1 .and. pc%gold >= 100) then; pc%gold = pc%gold - 100; call random_number(r); roll = int(r * 100)
                    if (roll < 5) then; call get_weapon_data(GRADE_LEGENDARY, pc%level, w)
                    else; call get_weapon_data(GRADE_COMMON, pc%level, w); end if; pc%weapon = w
                    call draw_item_icon(w%name); call get_item_desc(w%name, desc); print *, trim(desc); call wait_for_enter(); end if
            else if (choice == 3) then; if (pc%inn_usage < 5) then; pc%hp = pc%max_hp; pc%inn_usage = pc%inn_usage + 1; print *, "회복 완료"; end if
            else if (choice == 4) then; exit; end if; call delay(1.0); end do
    end subroutine scene_village
    subroutine show_dialogue(speaker, msg)
        character(len=*), intent(in) :: speaker, msg; print *, "[", trim(speaker), "] ", trim(msg); call wait_for_enter()
    end subroutine show_dialogue
end module game_logic

module game_data
    use game_types
    implicit none
    contains
    subroutine init_locations(area_names)
        character(len=30), intent(out) :: area_names(24)
        area_names(1)="햇살 숲"; area_names(2)="가시 덤불"; area_names(3)="속삭임 숲"; area_names(4)="고대 소나무"
        area_names(5)="산호 해변"; area_names(6)="난파선"; area_names(7)="늪지대"; area_names(8)="북쪽 호수"
        area_names(9)="고대 탑"; area_names(10)="모래 사막"; area_names(11)="화산 산길"; area_names(12)="하늘 섬"
        area_names(13)="요정 마을"; area_names(14)="연금술사 집"; area_names(15)="정령 샘터"; area_names(16)="용병 야영지"
        area_names(17)="거인 절벽"; area_names(18)="영혼 계곡"; area_names(19)="공허 틈새"; area_names(20)="보스 화산"
        area_names(21)="심연의 동굴"; area_names(22)="얼어붙은 툰드라"; area_names(23)="드래곤의 둥지"; area_names(24)="신비의 정원"
    end subroutine init_locations
    subroutine save_game(pc)
        type(character_t), intent(in) :: pc; open(10, file="save_data.txt"); write(10, '(A)') pc%name; write(10, *) pc%job, pc%level, pc%xp, pc%gold, pc%current_region, pc%unlocked_region, pc%inn_usage; close(10)
    end subroutine save_game
    subroutine load_game(pc, success)
        type(character_t), intent(out) :: pc; logical, intent(out) :: success; logical :: exists; inquire(file="save_data.txt", exist=exists)
        if (exists) then; open(10, file="save_data.txt"); read(10, '(A)') pc%name; read(10, *) pc%job, pc%level, pc%xp, pc%gold, pc%current_region, pc%unlocked_region, pc%inn_usage; close(10); success = .true.; else; success = .false.; end if
    end subroutine load_game
end module game_data

module game_ui
    use game_types; use game_utils
    implicit none
    contains
    subroutine show_main_menu(choice)
        integer, intent(out) :: choice; print *, "1. 새게임 2. 로드 3. 종료"; read *, choice
    end subroutine show_main_menu
    subroutine show_status(pc)
        type(character_t), intent(in) :: pc; print *, "LV:", pc%level, " HP:", pc%hp, "/", pc%max_hp, " Gold:", pc%gold
    end subroutine show_status
    subroutine show_world_map(pc, area_names)
        type(character_t), intent(in) :: pc; character(len=30), intent(in) :: area_names(24); integer :: i
        print *, "--- WORLD MAP ---"; do i = 1, pc%unlocked_region; print *, "[", i, "] ", area_names(i); end do
    end subroutine show_world_map
    subroutine show_inventory(pc)
        type(character_t), intent(in) :: pc; integer :: i; do i = 1, pc%inv_count; print *, i, ". ", pc%inventory(i)%name; end do
    end subroutine show_inventory
    subroutine draw_intro_animation(); print *, "WELCOME TO MANY ADVENTURE"; end subroutine draw_intro_animation
    subroutine draw_village_banner(); print *, "--- VILLAGE ---"; end subroutine draw_village_banner
    subroutine show_explore_menu(choice); print *, "1. 계속탐험 2. 마을"; read *, choice; end subroutine show_explore_menu
end module game_ui
